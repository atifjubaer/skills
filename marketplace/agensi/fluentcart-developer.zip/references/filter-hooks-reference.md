# FluentCart Filter Hooks — Complete Reference

# Filter Hooks: Cart & Checkout

All filters related to the shopping flow from Cart to checkout.

---

## Cart Items & Validation

### `cart/item_modify`
`fluent_cart/cart/item_modify` — Modify cart item variation before adding

* **When it runs:** Applied when a product variation is being added to the cart or when an existing cart item is updated. Allows you to modify the variation object before processing, or return `null` to block the item.
* **Source:** `api/Resource/FrontendResource/CartResource.php` (lines 44, 307)

#### Parameters:
* `$variation` *(\FluentCart\App\Models\ProductVariation|null)* — The product variation model instance
* `$data` *(array)* — Context data (`['item_id' => 42, 'quantity' => 1]`)
* **Returns:** *(\FluentCart\App\Models\ProductVariation|null)* — The modified variation, or `null` to prevent adding

#### Usage Example:
```php
// Filter product variation before adding to cart or updating quantity
add_filter('fluent_cart/cart/item_modify', function ($variation, $data) {
    if (!$variation) {
        return $variation;
    }

    // Block a specific variation ID from being added to cart
    if ($variation->id === 99) {
        return null;
    }

    return $variation;
}, 10, 2);
```

---

### `item_max_quantity`
`fluent_cart/item_max_quantity` — Limit the maximum quantity for a cart item

* **When it runs:** Applied immediately after the variation is resolved, before adding to cart. Allows capping or adjusting the requested quantity.
* **Source:** `api/Resource/FrontendResource/CartResource.php` (line 54)

#### Parameters:
* `$quantity` *(int)* — The requested quantity
* `$data` *(array)* — Context data (`['variation' => ProductVariation, 'product' => Product]`)
* **Returns:** *(int)* — The (possibly capped) quantity

#### Usage Example:
```php
// Filter maximum allowed purchase quantity for a cart item
add_filter('fluent_cart/item_max_quantity', function ($quantity, $data) {
    // Extract variation model from context
    $variation = $data['variation'];

    // Limit subscription products to maximum quantity of 1
    if ($variation->payment_type === 'subscription') {
        return 1;
    }

    // Cap all item quantities at maximum of 10
    return min($quantity, 10);
}, 10, 2);
```

---

### `cart/custom_item_quantity_changed`
`fluent_cart/cart/custom_item_quantity_changed` — Handle custom item quantity changes

* **When it runs:** Fires when the quantity of a custom (externally-managed) item already in the cart is changed. Recalculates pricing or validates quantity.
* **Source:** `api/Resource/FrontendResource/CartResource.php` (line 269)

#### Parameters:
* `$existingItem` *(object)* — The existing cart item object
* `$data` *(array)* — Context data (`['old_quantity' => 2, 'new_quantity' => 3, 'is_custom' => true]`)
* **Returns:** *(object)* — The modified item object with updated quantity and totals

#### Usage Example:
```php
// Filter quantity change for custom externally-managed cart item
add_filter('fluent_cart/cart/custom_item_quantity_changed', function ($variation, $data) {
    if (empty($data['is_custom'])) {
        return $variation;
    }

    // Recalculate line total based on new quantity input
    $variation->quantity = $data['new_quantity'];
    $variation->line_total = $variation->price * $data['new_quantity'];

    return $variation;
}, 10, 2);
```

---

### `cart/validate_custom_item`
`fluent_cart/cart/validate_custom_item` — Validate a custom or externally-managed cart item

* **When it runs:** Fires when a custom (non-FluentCart) item is being added to the cart. Used to validate and construct the item object stored in the cart.
* **Source:** `api/Resource/FrontendResource/CartResource.php` (line 289), `app/Http/Routes/WebRoutes.php` (line 99)

#### Parameters:
* `$existingItem` *(object|null)* — The existing item object, or `null` for new items
* `$data` *(array)* — Context data (`['item_id' => string, 'quantity' => int, 'is_custom' => true]`)
* **Returns:** *(object)* — A variation-like object with required cart item properties

#### Usage Example:
```php
// Validate and construct custom item object for cart
add_filter('fluent_cart/cart/validate_custom_item', function ($variation, $data) {
    if (!(bool) $data['is_custom']) {
        return $variation;
    }

    // Build custom item object with required cart item properties
    return (object) [
        'item_id'      => absint($data['item_id']),
        'object_id'    => absint($data['item_id']),
        'title'        => 'Custom Product',
        'price'        => 2500, // $25.00 in cents
        'quantity'     => (int) $data['quantity'],
        'payment_type' => 'one_time',
        'is_custom'    => true,
    ];
}, 10, 2);
```

---

### `cart_item_product_variation`
`fluent_cart/cart_item_product_variation` — Provide a fallback product variation for a cart item

* **When it runs:** Fires when a product variation cannot be found in the database during cart operations. Serves as fallback mechanism.
* **Source:** `api/Resource/FrontendResource/CartResource.php` (line 631)

#### Parameters:
* `$productVariation` *(\FluentCart\App\Models\ProductVariation|null)* — Always `null` at this point
* `$itemId` *(int)* — The variation/item ID being looked up
* `$incrementBy` *(int)* — The quantity increment value
* `$existingItemsArray` *(array)* — The current cart items array
* **Returns:** *(\FluentCart\App\Models\ProductVariation|null)* — A variation model instance, or `null`

#### Usage Example:
```php
// Provide fallback product variation when variation is not found in DB
add_filter('fluent_cart/cart_item_product_variation', function ($variation, $itemId, $incrementBy, $existingItems) {
    if (!$variation && $itemId > 10000) {
        // Resolve variation object from external service
        return MyExternalService::getVariation($itemId);
    }
    return $variation;
}, 10, 4);
```

---

### `cart/can_purchase`
`fluent_cart/cart/can_purchase` — Determine whether a variation can be added to the cart

* **When it runs:** Fires after the built-in `canPurchase()` check on the variation model, inside `Cart::addItem()`.
* **Source:** `app/Models/Cart.php` (line 333)

#### Parameters:
* `$canPurchase` *(true|\WP_Error)* — Result of built-in purchase validation
* `$data` *(array)* — Context data (`['cart' => Cart, 'variation' => ProductVariation, 'quantity' => int]`)
* **Returns:** *(true|\WP_Error)* — Return `true` to allow purchase, or `WP_Error` to block

#### Usage Example:
```php
// Filter whether product variation can be added to cart
add_filter('fluent_cart/cart/can_purchase', function ($canPurchase, $data) {
    if (is_wp_error($canPurchase)) {
        return $canPurchase;
    }

    $cart = $data['cart'];
    $variation = $data['variation'];

    // Limit cart to maximum of 5 unique items
    $existingItems = $cart->getItems();
    if (count($existingItems) >= 5 && !isset($existingItems[$variation->id])) {
        return new \WP_Error(
            'cart_limit',
            __('You can only have up to 5 different items in your cart.', 'fluent-cart')
        );
    }

    return true;
}, 10, 2);
```

---

### `cart/estimated_total`
`fluent_cart/cart/estimated_total` — Filter the cart estimated total

* **When it runs:** Applied when calculating cart estimated total in `Cart::getEstimatedTotal()` and web checkout handler.
* **Source:** `app/Models/Cart.php` (line 766), `app/Hooks/Cart/WebCheckoutHandler.php` (line 358)

#### Parameters:
* `$total` *(int)* — The cart total in cents
* `$data` *(array)* — Context data (`['cart' => Cart]`)
* **Returns:** *(int)* — The modified cart total in cents

#### Usage Example:
```php
// Filter cart estimated total calculation amount
add_filter('fluent_cart/cart/estimated_total', function ($total, $data) {
    // Extract cart model instance from context
    $cart = $data['cart'];

    // Add flat processing fee of $2.00 in cents
    $processingFee = 200;
    return $total + $processingFee;
}, 10, 2);
```

---

### `cart_cookie_minutes`
`fluent_cart/cart_cookie_minutes` — Control cart cookie expiration time

* **When it runs:** Fires when setting the cart hash cookie. The default value is a Unix timestamp (time() + 30 days).
* **Source:** `api/Cookie/Cookie.php` (line 22)

#### Parameters:
* `$expireTime` *(int)* — Unix timestamp for cookie expiration
* **Returns:** *(int)* — The Unix timestamp when cookie expires

#### Usage Example:
```php
// Filter cart cookie expiration Unix timestamp
add_filter('fluent_cart/cart_cookie_minutes', function ($expireTime) {
    // Set cart cookie expiration to 7 days from now
    return time() + (7 * DAY_IN_SECONDS);
});
```

---

### `variation/can_purchase_bundle`
`fluent_cart/variation/can_purchase_bundle` — Validate whether a bundle product can be purchased

* **When it runs:** Fires during `canPurchase()` on a `ProductVariation` when product is a bundle.
* **Source:** `app/Models/ProductVariation.php` (line 265)

#### Parameters:
* `$result` *(null)* — Always `null` initially
* `$data` *(array)* — Context data (`['variation' => ProductVariation, 'quantity' => int]`)
* **Returns:** *(null|true|false|\WP_Error)* — `null`/`true` to allow, `false` for generic error, `WP_Error` to block with custom message

#### Usage Example:
```php
// Validate stock for bundled child items during bundle purchase
add_filter('fluent_cart/variation/can_purchase_bundle', function ($result, $data) {
    $variation = $data['variation'];
    $quantity = (int) $data['quantity'];

    // Iterate through bundle children to verify sufficient stock
    $children = $variation->bundleChildren()->get();
    foreach ($children as $child) {
        if ($child->available < ($child->pivot->quantity * $quantity)) {
            return new \WP_Error(
                'bundle_stock',
                sprintf(__('%s does not have enough stock.', 'fluent-cart'), $child->title)
            );
        }
    }

    return $result;
}, 10, 2);
```

---

## Checkout Validation

### `checkout/validate_before_process`
`fluent_cart/checkout/validate_before_process` — Pre-validate the checkout before processing

* **When it runs:** Fires early in `placeOrder()` flow before field or product validation. First chance to reject checkout attempt.
* **Source:** `api/Checkout/CheckoutApi.php` (line 83)

#### Parameters:
* `$validation` *(true)* — Always `true` initially
* `$data` *(array)* — Full checkout submission data (billing address, payment method, form fields, etc.)
* **Returns:** *(true|\WP_Error)* — `true` to continue, `WP_Error` to abort checkout

#### Usage Example:
```php
// Pre-validate checkout submission before processing order
add_filter('fluent_cart/checkout/validate_before_process', function ($validation, $data) {
    // Query cart model instance using submitted cart hash
    $cart = \FluentCart\App\Models\Cart::query()
        ->where('cart_hash', $data['cart_hash'])
        ->first();

    // Enforce minimum order total requirement of $5.00
    if ($cart && $cart->getEstimatedTotal() < 500) {
        return new \WP_Error(
            'min_order',
            __('Minimum order amount is $5.00.', 'fluent-cart')
        );
    }

    return $validation;
}, 10, 2);
```

---

### `cart/tax_behavior`
`fluent_cart/cart/tax_behavior` — Filter tax behavior amount for the cart

* **When it runs:** Fires during order creation in `CheckoutApi::placeOrder()`. Determines tax behavior value for order total.
* **Source:** `api/Checkout/CheckoutApi.php` (line 171)

#### Parameters:
* `$behavior` *(int)* — Default tax behavior value (`0`)
* `$data` *(array)* — Context data (`['cart' => Cart]`)
* **Returns:** *(int)* — Tax behavior value (`0` for exclusive, `1` for inclusive)

#### Usage Example:
```php
// Filter tax behavior value for cart order total calculation
add_filter('fluent_cart/cart/tax_behavior', function ($behavior, $data) {
    $cart = $data['cart'];

    // Force tax-inclusive behavior for specific European countries
    $country = $cart->checkout_data['billing_address']['country'] ?? '';
    if (in_array($country, ['DE', 'FR', 'GB'])) {
        return 1; // Tax-inclusive
    }

    return $behavior;
}, 10, 2);
```

---

### `checkout/validate_data`
`fluent_cart/checkout/validate_data` — Add or modify checkout validation errors

* **When it runs:** Fires after core field, shipping, and terms validation has run, before order creation.
* **Source:** `api/Checkout/CheckoutApi.php` (line 890)

#### Parameters:
* `$errors` *(array)* — Associative array of validation errors keyed by field name
* `$data` *(array)* — Context data (`['data' => submittedData, 'cart' => Cart]`)
* **Returns:** *(array)* — Modified errors array (empty array means validation passes)

#### Usage Example:
```php
// Append custom field validation errors to checkout submission
add_filter('fluent_cart/checkout/validate_data', function ($errors, $data) {
    $formData = $data['data'];

    // Require billing phone number for physical products requiring shipping
    $cart = $data['cart'];
    if ($cart->requireShipping() && empty($formData['billing_address']['phone'])) {
        $errors['billing_phone'] = [
            'required' => __('Phone number is required for physical products.', 'fluent-cart'),
        ];
    }

    return $errors;
}, 10, 2);
```

---

## Checkout Page Rendering

### `checkout_page_css_classes`
`fluent_cart/checkout_page_css_classes` — Modify checkout page CSS classes

* **When it runs:** Fires when rendering the checkout page container wrapper element.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php` (line 144)

#### Parameters:
* `$classNames` *(array)* — Array of CSS class strings
* `$data` *(array)* — Context data (`['cart' => Cart]`)
* **Returns:** *(array)* — Modified array of CSS class strings

#### Usage Example:
```php
// Filter checkout page wrapper container CSS classes
add_filter('fluent_cart/checkout_page_css_classes', function ($classes, $data) {
    $cart = $data['cart'];

    // Add custom class when cart contains subscription items
    if ($cart->hasSubscription()) {
        $classes[] = 'has-subscription-items';
    }

    return $classes;
}, 10, 2);
```

---

### `checkout_page_notices`
`fluent_cart/checkout_page_notices` — Add custom notices to checkout page

* **When it runs:** Fires during checkout page rendering to inject notices displayed at the top of checkout form.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php` (line 170)

#### Parameters:
* `$notices` *(array)* — Array of notice items (empty by default)
* `$data` *(array)* — Context data (`['cart' => Cart]`)
* **Returns:** *(array)* — Array of notice items to display

#### Usage Example:
```php
// Inject custom notice messages onto top of checkout page
add_filter('fluent_cart/checkout_page_notices', function ($notices, $data) {
    $cart = $data['cart'];

    // Display free shipping qualification threshold notice
    $total = $cart->getEstimatedTotal();
    if ($total < 5000 && $cart->requireShipping()) {
        $notices[] = [
            'type'    => 'info',
            'message' => sprintf(
                __('Add %s more to qualify for free shipping!', 'fluent-cart'),
                '$' . number_format((5000 - $total) / 100, 2)
            ),
        ];
    }

    return $notices;
}, 10, 2);
```

---

### `checkout_renderer/billing_fields`
`fluent_cart/checkout_renderer/billing_fields` — Modify rendered billing fields on checkout page

* **When it runs:** Fires after billing address fields have been assembled and rearranged in checkout renderer.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php` (line 448)

#### Parameters:
* `$billingFields` *(array)* — Array of billing field definitions with rendered state
* `$data` *(array)* — Context data (`['checkout_renderer' => renderer, 'cart' => Cart]`)
* **Returns:** *(array)* — Modified billing fields array

#### Usage Example:
```php
// Filter rendered billing field schema definitions on checkout page
add_filter('fluent_cart/checkout_renderer/billing_fields', function ($fields, $data) {
    // Remove company field from rendered billing fields schema
    foreach ($fields as $sectionKey => &$section) {
        if (isset($section['schema']) && is_array($section['schema'])) {
            unset($section['schema']['billing_company']);
        }
    }

    return $fields;
}, 10, 2);
```

---

### `checkout_renderer/shipping_fields`
`fluent_cart/checkout_renderer/shipping_fields` — Modify rendered shipping fields on checkout page

* **When it runs:** Fires after shipping address fields have been assembled and validated in checkout renderer.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php` (line 521)

#### Parameters:
* `$shippingFields` *(array)* — Array of shipping field definitions
* `$data` *(array)* — Context data (`['checkout_renderer' => renderer, 'cart' => Cart]`)
* **Returns:** *(array)* — Modified shipping fields array

#### Usage Example:
```php
// Filter rendered shipping field schema definitions on checkout page
add_filter('fluent_cart/checkout_renderer/shipping_fields', function ($fields, $data) {
    // Mark shipping address line 2 as a required field
    foreach ($fields as &$field) {
        if (isset($field['name']) && $field['name'] === 'shipping_address_2') {
            $field['required'] = 'yes';
        }
    }

    return $fields;
}, 10, 2);
```

---

### `disable_order_notes_for_digital_products`
`fluent_cart/disable_order_notes_for_digital_products` — Control order notes visibility for digital products

* **When it runs:** Fires when checkout renderer decides whether to show order notes textarea.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php` (line 560)

#### Parameters:
* `$disable` *(bool)* — Whether to hide order notes for digital-only carts (default: `true`)
* `$data` *(array)* — Context data (`['cart' => Cart]`)
* **Returns:** *(bool)* — `true` to hide order notes for digital products, `false` to show

#### Usage Example:
```php
// Filter order notes textarea visibility for digital-only carts
add_filter('fluent_cart/disable_order_notes_for_digital_products', function ($disable, $data) {
    // Always render order notes field even for digital products
    return false;
}, 10, 2);
```

---

### `checkout_active_payment_methods`
`fluent_cart/checkout_active_payment_methods` — Filter active payment methods on checkout page

* **When it runs:** Fires when listing available payment methods on standard and modal checkout renderers.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php` (line 652), `app/Services/Renderer/ModalCheckoutRenderer.php` (line 450)

#### Parameters:
* `$activePaymentMethods` *(array)* — Array of payment method instances
* `$data` *(array)* — Context data (`['cart' => Cart]`)
* **Returns:** *(array)* — Modified array of payment method instances

#### Usage Example:
```php
// Filter active payment method gateway instances on checkout page
add_filter('fluent_cart/checkout_active_payment_methods', function ($methods, $data) {
    $cart = $data['cart'];

    // Exclude Cash on Delivery payment option for orders over $500
    if ($cart->getEstimatedTotal() > 50000) {
        $methods = array_filter($methods, function ($method) {
            return $method->getMeta('route') !== 'cod';
        });
    }

    return array_values($methods);
}, 10, 2);
```

---

### `checkout_page_order_button_text`
`fluent_cart/checkout_page_order_button_text` — Customize place order button text

* **When it runs:** Fires when checkout submit button is being rendered to change its label.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php` (line 705)

#### Parameters:
* `$text` *(string)* — Button text (default: `'Place order'`)
* **Returns:** *(string)* — Modified button text

#### Usage Example:
```php
// Customize place order submit button text on checkout page
add_filter('fluent_cart/checkout_page_order_button_text', function ($text) {
    // Change Place Order button label to Complete Purchase
    return __('Complete Purchase', 'fluent-cart');
});
```

---

### `payment_method_list_class`
`fluent_cart_payment_method_list_class` — Add CSS classes to a payment method wrapper

* **When it runs:** Fires when rendering each payment method option in standard and modal checkout. Note legacy prefix (`fluent_cart_`).
* **Source:** `app/Services/Renderer/CheckoutRenderer.php` (line 797), `app/Services/Renderer/ModalCheckoutRenderer.php` (line 569)

#### Parameters:
* `$class` *(string)* — CSS class string (default: `''`)
* `$data` *(array)* — Context data (`['route' => string, 'method_title' => string, 'method_style' => string]`)
* **Returns:** *(string)* — Modified CSS class string

#### Usage Example:
```php
// Filter CSS class string for payment method container wrapper (legacy prefix)
add_filter('fluent_cart_payment_method_list_class', function ($class, $data) {
    // Add highlight class for Cash on Delivery payment option
    if ($data['route'] === 'cod') {
        return $class . ' payment-method-highlighted';
    }
    return $class;
}, 10, 2);
```

---

### `modal_checkout/filter_active_payment_methods`
`fluent_cart/modal_checkout/filter_active_payment_methods` — Restrict payment methods in modal checkout

* **When it runs:** Fires during modal checkout rendering after active payment methods are resolved.
* **Source:** `app/Services/Renderer/ModalCheckoutRenderer.php` (line 455)

#### Parameters:
* `$selectedMethods` *(array)* — Empty array by default
* **Returns:** *(array)* — Array of payment method route slugs to show (`['stripe', 'paypal']`)

#### Usage Example:
```php
// Filter active payment method route slugs shown in modal checkout
add_filter('fluent_cart/modal_checkout/filter_active_payment_methods', function ($methods) {
    // Restrict modal checkout to show only Stripe payment method
    return ['stripe'];
});
```

---

### `enable_modal_checkout`
`fluent_cart/enable_modal_checkout` — Enable or disable modal checkout

* **When it runs:** Fires when checking whether modal popup checkout is enabled (default: `false`).
* **Source:** `app/Helpers/Helper.php` (line 1710)

#### Parameters:
* `$enabled` *(bool)* — Whether modal checkout is enabled (default: `false`)
* **Returns:** *(bool)* — `true` to enable modal checkout, `false` for standard page

#### Usage Example:
```php
// Filter whether modal popup checkout mode is enabled
add_filter('fluent_cart/enable_modal_checkout', function ($enabled) {
    // Enable modal checkout feature
    return true;
});
```

---

## Checkout Data & Session

### `checkout/checkout_data_changed`
`fluent_cart/checkout/checkout_data_changed` — Modify checkout data after a change is detected

* **When it runs:** Fires after checkout session data is saved to modify response data returned to browser.
* **Source:** `app/Hooks/Cart/WebCheckoutHandler.php` (lines 495, 1115)

#### Parameters:
* `$checkoutData` *(array)* — Checkout change response data (`message`, `fragments`, `estimated_total`, etc.)
* `$data` *(array)* — Context data (`['cart' => Cart]`)
* **Returns:** *(array)* — Modified checkout response data

#### Usage Example:
```php
// Filter response data payload returned after checkout session data change
add_filter('fluent_cart/checkout/checkout_data_changed', function ($checkoutData, $data) {
    // Append custom notice string to checkout change response payload
    $checkoutData['custom_notice'] = __('Your order qualifies for a bonus!', 'fluent-cart');
    return $checkoutData;
}, 10, 2);
```

---

### `checkout/cart_updated`
`fluent_cart/checkout/cart_updated` — Filter the cart update response data

* **When it runs:** Fires when cart is updated during checkout session (e.g. items added or removed).
* **Source:** `app/Hooks/Cart/WebCheckoutHandler.php` (line 683)

#### Parameters:
* `$data` *(array)* — Response data (`['cart' => Cart]`)
* **Returns:** *(array)* — Modified response data array

#### Usage Example:
```php
// Filter cart update response payload during checkout session
add_filter('fluent_cart/checkout/cart_updated', function ($data) {
    // Append item count and free shipping eligibility flags
    $cart = $data['cart'];
    $data['item_count'] = count($cart->getItems());
    $data['free_shipping_eligible'] = $cart->getEstimatedTotal() >= 5000;
    return $data;
});
```

---

### `checkout/before_patch_checkout_data`
`fluent_cart/checkout/before_patch_checkout_data` — Modify fill data before patching checkout session

* **When it runs:** Fires before checkout session data is persisted to database.
* **Source:** `app/Hooks/Cart/WebCheckoutHandler.php` (lines 791, 967)

#### Parameters:
* `$fillData` *(array)* — Data to merge into cart checkout session (`checkout_data`, `cart_data`, `hook_changes`)
* `$data` *(array)* — Context data (`['cart' => Cart, 'prev_data' => array, 'changes' => array, 'all_data' => array]`)
* **Returns:** *(array)* — Modified fill data

#### Usage Example:
```php
// Filter fill data merged into checkout session before persisting to DB
add_filter('fluent_cart/checkout/before_patch_checkout_data', function ($fillData, $data) {
    $cart = $data['cart'];
    $changes = $data['changes'];

    // Recalculate custom surcharge when billing country changes
    if (isset($changes['billing_country'])) {
        $surcharge = MyModule::calculateSurcharge($changes['billing_country']);
        $fillData['checkout_data']['custom_surcharge'] = $surcharge;
        $fillData['hook_changes']['custom'] = true;
    }

    return $fillData;
}, 10, 2);
```

---

### `checkout/after_patch_checkout_data_fragments`
`fluent_cart/checkout/after_patch_checkout_data_fragments` — Modify HTML fragments returned after patching checkout data

* **When it runs:** Fires after checkout session is patched and HTML fragments for AJAX response are generated.
* **Source:** `app/Hooks/Cart/WebCheckoutHandler.php` (line 901)

#### Parameters:
* `$fragments` *(array)* — Associative array of HTML fragment selectors and content
* `$data` *(array)* — Context data (`['cart' => Cart, 'changes' => array]`)
* **Returns:** *(array)* — Modified fragments array

#### Usage Example:
```php
// Filter HTML response fragments swapped into checkout page via AJAX
add_filter('fluent_cart/checkout/after_patch_checkout_data_fragments', function ($fragments, $data) {
    // Extract cart model instance
    $cart = $data['cart'];

    // Inject custom surcharge display HTML fragment selector
    $fragments['.custom-surcharge-display'] = [
        'content' => '<span class="custom-surcharge">' . esc_html('$5.00') . '</span>',
        'type'    => 'replace',
    ];

    return $fragments;
}, 10, 2);
```

---

### `apply_order_bump`
`fluent_cart/apply_order_bump` — Handle order bump application on checkout page

* **When it runs:** Fires when customer toggles order bump on checkout page.
* **Source:** `app/Hooks/Cart/WebCheckoutHandler.php` (line 1144)

#### Parameters:
* `$response` *(\WP_Error)* — Default error response
* `$data` *(array)* — Context data (`['bump_id' => int, 'cart' => Cart, 'request_data' => array]`)
* **Returns:** *(array|\WP_Error)* — Return array with success data to apply bump, or `WP_Error` to reject

#### Usage Example:
```php
// Handle order bump application request on checkout page
add_filter('fluent_cart/apply_order_bump', function ($response, $data) {
    $bumpId = $data['bump_id'];
    $cart = $data['cart'];

    // Look up order bump definition model
    $bump = MyOrderBumpModule::find($bumpId);
    if (!$bump) {
        return $response;
    }

    // Add bump variation item to cart
    $cart->addItem($bump->variation_id, 1);

    return [
        'message' => __('Order bump applied!', 'fluent-cart'),
        'cart'    => $cart,
    ];
}, 10, 2);
```

---

## Checkout Field Schema

### `checkout_address_fields`
`fluent_cart/checkout_address_fields` — Modify address field definitions

* **When it runs:** Fires when address field schema is built in `CartCheckoutHelper`. Controls fields in billing/shipping address sections.
* **Source:** `app/Helpers/CartCheckoutHelper.php` (line 692)

#### Parameters:
* `$fields` *(array)* — Associative array of address field definitions
* **Returns:** *(array)* — Modified fields array

#### Usage Example:
```php
// Modify address field definitions for both billing and shipping
add_filter('fluent_cart/checkout_address_fields', function ($fields) {
    // Add custom company name address field definition
    $fields['company'] = [
        'label'    => __('Company Name', 'fluent-cart'),
        'type'     => 'text',
        'required' => false,
    ];

    return $fields;
});
```

---

### `checkout_billing_fields`
`fluent_cart/checkout_billing_fields` — Modify billing address field schema

* **When it runs:** Fires when billing fields are being assembled in `CartCheckoutHelper`.
* **Source:** `app/Helpers/CartCheckoutHelper.php` (line 730)

#### Parameters:
* `$fields` *(array)* — Billing field definitions organized in sections
* `$data` *(array)* — Context data (`['viewData' => array, 'customer' => Customer, 'labels' => array, 'has_subscription' => bool]`)
* **Returns:** *(array)* — Modified billing fields array

#### Usage Example:
```php
// Modify billing address section field schema definitions
add_filter('fluent_cart/checkout_billing_fields', function ($fields, $data) {
    // Enforce required phone field for subscription carts
    if ($data['has_subscription']) {
        if (isset($fields['address_section']['schema']['billing_phone'])) {
            $fields['address_section']['schema']['billing_phone']['required'] = 'yes';
        }
    }

    return $fields;
}, 10, 2);
```

---

### `checkout_shipping_fields`
`fluent_cart/checkout_shipping_fields` — Modify shipping address field schema

* **When it runs:** Fires when shipping address fields are assembled in `CartCheckoutHelper`.
* **Source:** `app/Helpers/CartCheckoutHelper.php` (line 771)

#### Parameters:
* `$fields` *(array)* — Shipping field definitions organized in sections
* `$data` *(array)* — Context data (`['viewData' => array, 'labels' => array]`)
* **Returns:** *(array)* — Modified shipping fields array

#### Usage Example:
```php
// Modify shipping address section field schema definitions
add_filter('fluent_cart/checkout_shipping_fields', function ($fields, $data) {
    // Remove shipping address line 2 field from schema
    if (isset($fields['address_section']['schema']['shipping_address_2'])) {
        unset($fields['address_section']['schema']['shipping_address_2']);
    }

    return $fields;
}, 10, 2);
```

---

### `checkout_signup_fields`
`fluent_cart/checkout_signup_fields` — Modify account signup form fields

* **When it runs:** Fires when guest checkout signup form fields (username, email, password) are assembled.
* **Source:** `app/Helpers/CartCheckoutHelper.php` (line 846)

#### Parameters:
* `$fields` *(array)* — Associative array of signup field definitions (`user_login`, `user_pass`)
* **Returns:** *(array)* — Modified signup fields array

#### Usage Example:
```php
// Modify guest checkout registration signup form field schema
add_filter('fluent_cart/checkout_signup_fields', function ($fields) {
    // Enforce required password field during signup
    if (isset($fields['user_pass'])) {
        $fields['user_pass']['required'] = 'yes';
    }

    return $fields;
});
```

---

### `checkout_login_fields`
`fluent_cart/checkout_login_fields` — Modify checkout login form fields

* **When it runs:** Fires when login form fields (username, password) are assembled for checkout page.
* **Source:** `app/Helpers/CartCheckoutHelper.php` (line 872)

#### Parameters:
* `$fields` *(array)* — Associative array of login field definitions (`user_login`, `user_pass`)
* **Returns:** *(array)* — Modified login fields array

#### Usage Example:
```php
// Modify returning customer login form field schema on checkout
add_filter('fluent_cart/checkout_login_fields', function ($fields) {
    // Update username field label and placeholder text
    if (isset($fields['user_login'])) {
        $fields['user_login']['label'] = __('Email Address', 'fluent-cart');
        $fields['user_login']['placeholder'] = __('Enter your email', 'fluent-cart');
    }

    return $fields;
});
```

---

### `checkout_coupon_fields`
`fluent_cart/checkout_coupon_fields` — Modify coupon input fields

* **When it runs:** Fires when coupon code input fields are assembled for checkout page.
* **Source:** `app/Helpers/CartCheckoutHelper.php` (line 925)

#### Parameters:
* `$fields` *(array)* — Associative array of coupon field definitions
* **Returns:** *(array)* — Modified coupon fields array

#### Usage Example:
```php
// Modify coupon input form fields schema on checkout page
add_filter('fluent_cart/checkout_coupon_fields', function ($fields) {
    // Customize coupon code input field placeholder string
    if (isset($fields['coupon_code'])) {
        $fields['coupon_code']['placeholder'] = __('Got a discount code?', 'fluent-cart');
    }

    return $fields;
});
```

---

### `checkout_page_name_fields_schema`
`fluent_cart/checkout_page_name_fields_schema` — Modify name fields on checkout page

* **When it runs:** Fires when checkout name fields schema (first name, last name, email, company) is being built.
* **Source:** `app/Services/Renderer/CheckoutFieldsSchema.php` (line 86)

#### Parameters:
* `$nameFields` *(array)* — Associative array of name/email field definitions
* `$data` *(array)* — Context data (`['cart' => Cart, 'scope' => 'billing'|'shipping']`)
* **Returns:** *(array)* — Modified name fields array

#### Usage Example:
```php
// Modify checkout page name and email fields schema
add_filter('fluent_cart/checkout_page_name_fields_schema', function ($fields, $data) {
    // Pre-fill email field for logged-in user
    if ($userId = get_current_user_id()) {
        $user = get_userdata($userId);
        if (!empty($fields['billing_email']) && empty($fields['billing_email']['value'])) {
            $fields['billing_email']['value'] = $user->user_email;
        }
    }

    return $fields;
}, 10, 2);
```

---

### `fields/address_base_fields`
`fluent_cart/fields/address_base_fields` — Modify base address field definitions

* **When it runs:** Fires when low-level address field definitions are assembled in `CheckoutFieldsSchema`.
* **Source:** `app/Services/Renderer/CheckoutFieldsSchema.php` (line 320)

#### Parameters:
* `$fields` *(array)* — Array of base address field definitions
* `$data` *(array)* — Context data (`['config' => array, 'scope' => 'billing'|'shipping', 'requirements' => array]`)
* **Returns:** *(array)* — Modified base address fields array

#### Usage Example:
```php
// Modify low-level base address field definitions
add_filter('fluent_cart/fields/address_base_fields', function ($fields, $data) {
    // Make billing city field optional
    if ($data['scope'] === 'billing') {
        foreach ($fields as &$field) {
            if (isset($field['name']) && $field['name'] === 'billing_city') {
                unset($field['required']);
            }
        }
    }

    return $fields;
}, 10, 2);
```

---

### `default_billing_country_for_checkout`
`fluent_cart/default_billing_country_for_checkout` — Set default billing country

* **When it runs:** Fires when determining default billing country for checkout form. Default uses Cloudflare IP geo-detection.
* **Source:** `app/Helpers/AddressHelper.php` (line 639)

#### Parameters:
* `$countryCode` *(string)* — Detected country code (ISO 3166-1 alpha-2)
* **Returns:** *(string)* — Valid ISO 3166-1 alpha-2 country code

#### Usage Example:
```php
// Filter default billing country code for checkout form
add_filter('fluent_cart/default_billing_country_for_checkout', function ($countryCode) {
    // Default to US if geo-detection yields empty country code
    if (empty($countryCode)) {
        return 'US';
    }

    return $countryCode;
});
```

---

## Checkout Localization

### `checkout/localize_data`
`fluent_cart/checkout/localize_data` — Modify checkout JavaScript localized data

* **When it runs:** Fires when checkout page assets are enqueued to pass data to JS via `wp_localize_script()`.
* **Source:** `app/Modules/Templating/AssetLoader.php` (line 497)

#### Parameters:
* `$data` *(array)* — Localized data array (`fluentcart_checkout_vars`)
* `$cart` *(\FluentCart\App\Models\Cart)* — Cart model instance
* **Returns:** *(array)* — Modified localized data array

#### Usage Example:
```php
// Modify localized data passed to checkout JavaScript frontend
add_filter('fluent_cart/checkout/localize_data', function ($data, $cart) {
    // Add custom module config payload to checkout JS variables
    $data['fluentcart_checkout_vars']['my_module'] = [
        'enabled'  => true,
        'endpoint' => rest_url('my-module/v1/validate'),
    ];

    return $data;
}, 10, 2);
```

---

### `payment_methods_with_custom_checkout_buttons`
`fluent_cart/payment_methods_with_custom_checkout_buttons` — Register payment methods with custom buttons

* **When it runs:** Fires when building checkout localized data to identify gateways rendering custom submit buttons (e.g. PayPal smart buttons).
* **Source:** `app/Modules/Templating/AssetLoader.php` (line 465)

#### Parameters:
* `$methods` *(array)* — Array of payment method route slugs with custom buttons (default: `[]`)
* **Returns:** *(array)* — Modified array of payment method route slugs

#### Usage Example:
```php
// Register payment gateway route slugs that render custom buttons
add_filter('fluent_cart/payment_methods_with_custom_checkout_buttons', function ($methods) {
    // Append custom payment gateway route slug to list
    $methods[] = 'my_custom_gateway';
    return $methods;
});
```

---

### `instant_checkout/allowed_redirect_hosts`
`fluent_cart/instant_checkout/allowed_redirect_hosts` — Control allowed redirect hosts for instant checkout

* **When it runs:** Fires during instant URL checkout when `redirect_to` parameter is provided.
* **Source:** `app/Http/Routes/WebRoutes.php` (line 155)

#### Parameters:
* `$allowedHosts` *(array)* — Array of allowed hostnames (default: current site host)
* `$data` *(array)* — Context data (`['allowed_hosts' => array]`)
* **Returns:** *(array)* — Array of allowed redirect hostnames

#### Usage Example:
```php
// Filter allowed redirect hostnames for instant URL checkout
add_filter('fluent_cart/instant_checkout/allowed_redirect_hosts', function ($hosts) {
    // Allow instant checkout redirects to subdomains
    $hosts[] = 'shop.example.com';
    $hosts[] = 'members.example.com';
    return $hosts;
});
```

---

## Tax & VAT

### `checkout/is_business`
`fluent_cart/checkout/is_business` — Filter whether checkout is a business (B2B) purchase

* **When it runs:** Applied in `TaxModule::storeBusinessInfoOnOrder()` right after order is placed to decide whether to persist business info.
* **Source:** `app/Modules/Tax/TaxModule.php` (line 1047)

#### Parameters:
* `$isBusinessCheckout` *(bool)* — Whether checkout is treated as business purchase
* `$data` *(array)* — Context data (`['checkout_data' => array, 'order' => Order]`)
* **Returns:** *(bool)* — `true` to treat as business purchase

#### Usage Example:
```php
// Filter whether checkout is treated as a business (B2B) purchase
add_filter('fluent_cart/checkout/is_business', function ($isBusiness, $data) {
    // Treat checkout as B2B if company name is provided
    $company = $data['checkout_data']['form_data']['company_name'] ?? '';

    return $isBusiness || $company !== '';
}, 10, 2);
```

---

### `tax/reverse_charge_line_adjustment`
`fluent_cart/tax/reverse_charge_line_adjustment` — Filter per-line price adjustment when reverse charge is applied

* **When it runs:** Applied in `TaxModule::calculateCartTax()` while applying EU VAT reverse charge to tax-inclusive product lines.
* **Source:** `app/Modules/Tax/TaxModule.php` (line 689)

#### Parameters:
* `$adjustment` *(int)* — Amount in cents to deduct from line unit price
* `$data` *(array)* — Context data (`['line' => array, 'rc_mode' => string]`)
* **Returns:** *(int)* — Adjustment amount in cents

#### Usage Example:
```php
// Filter price deduction amount when EU VAT reverse charge is applied
add_filter('fluent_cart/tax/reverse_charge_line_adjustment', function ($adjustment, $data) {
    // Keep gross price without deduction for target product post ID 123
    if (($data['line']['post_id'] ?? 0) === 123) {
        return 0;
    }

    return $adjustment;
}, 10, 2);
```

---

### `tax/reverse_charge_notice_text`
`fluent_cart/tax/reverse_charge_notice_text` — Filter reverse charge notice on receipts and invoices

* **When it runs:** Applied in `TaxModule::getReverseChargeNoticeText()` whenever reverse charge notice is rendered on receipts, emails, or PDFs.
* **Source:** `app/Modules/Tax/TaxModule.php` (line 1688)

#### Parameters:
* `$text` *(string)* — Notice text (default: `'Reverse charge — Article 196, Council Directive 2006/112/EC. Customer is liable for VAT.'`)
* **Returns:** *(string)* — Notice text to display

#### Usage Example:
```php
// Filter reverse charge notice text shown on receipts and invoices
add_filter('fluent_cart/tax/reverse_charge_notice_text', function ($text) {
    // Apply intra-EU supply of goods reverse charge notice wording
    return __('Reverse charge — Article 138, Council Directive 2006/112/EC. Customer is liable for VAT.', 'my-plugin');
}, 10, 1);
```

---

### `tax/validate_eu_vat_number`
`fluent_cart/tax/validate_eu_vat_number` — Short-circuit EU VAT number validation with custom validator

* **When it runs:** Applied in `TaxModule::validateEuVatNumber()` before contacting EU VIES SOAP service. Returning non-null short-circuits remote call.
* **Source:** `app/Modules/Tax/TaxModule.php` (line 1430)

#### Parameters:
* `$result` *(null)* — Always `null` by default
* `$data` *(array)* — Context data (`['country_code' => string, 'vat_number' => string]`)
* **Returns:** *(null|array|\WP_Error)* — `null` for default VIES call, `array` for successful result, `WP_Error` for error

#### Usage Example:
```php
// Short-circuit EU VAT number validation with custom API validator
add_filter('fluent_cart/tax/validate_eu_vat_number', function ($result, $data) {
    // Perform remote lookup via custom VAT API validator
    $response = my_vat_api_check($data['country_code'], $data['vat_number']);

    if (!$response['ok']) {
        return new \WP_Error('invalid_vat', __('The VAT number could not be validated.', 'my-plugin'));
    }

    return [
        'country'    => $data['country_code'],
        'vat_number' => $data['vat_number'],
        'valid'      => true,
        'name'       => $response['company_name'],
        'address'    => $response['address'],
    ];
}, 10, 2);
```

---

# Filter Hooks: Customers & Subscriptions

All filters related to Customer management, the customer portal, Subscription lifecycle, billing configuration, and automated reminders.

---

## Customer Data & Portal

### `customer/view`
`fluent_cart/customer/view` — Filter admin single customer view data

* **When it runs:** Applied when preparing a single customer's data for display in the admin panel.
* **Source:** `app/Http/Controllers/CustomerController.php` (line 74)

#### Parameters:
* `$customer` *(\FluentCart\App\Models\Customer)* — Customer model instance with loaded relations (`id`, `email`, `total_spent`, etc.)
* `$requestData` *(array)* — Full request data from `$request->all()`
* **Returns:** *(\FluentCart\App\Models\Customer)* — The modified customer data

#### Usage Example:
```php
// Filter single customer view data payload in admin panel
add_filter('fluent_cart/customer/view', function($customer, $requestData) {
    // Inject loyalty points user meta into customer view data
    $customer['loyalty_points'] = get_user_meta($customer['user_id'], 'loyalty_points', true);
    return $customer;
}, 10, 2);
```

---

### `widgets/single_customer`
`fluent_cart/widgets/single_customer` — Filter single customer admin widgets

* **When it runs:** Applied when loading widget data for a single customer's admin view, allowing custom widget section injection.
* **Source:** `app/Http/Controllers/CustomerController.php` (line 177)

#### Parameters:
* `$widgets` *(array)* — Array of widget definitions (default: `[]`)
* `$customer` *(\FluentCart\App\Models\Customer)* — Customer model instance
* **Returns:** *(array)* — The modified widgets array

#### Usage Example:
```php
// Filter admin widgets loaded on single customer detail view page
add_filter('fluent_cart/widgets/single_customer', function($widgets, $customer) {
    // Append custom CRM notes widget definition for customer
    $widgets[] = [
        'title' => 'CRM Notes',
        'content' => get_user_meta($customer->user_id, 'crm_notes', true)
    ];
    return $widgets;
}, 10, 2);
```

---

### `customer_dashboard_data`
`fluent_cart/customer_dashboard_data` — Filter customer dashboard data

* **When it runs:** Applied when preparing customer portal dashboard data, including recent orders list and section parts. Runs both when a customer exists and when no customer is found.
* **Source:** `app/Http/Controllers/FrontendControllers/CustomerProfileController.php` (lines 58, 114)

#### Parameters:
* `$data` *(array)* — Dashboard response data (`message`, `dashboard_data`, `sections_parts`)
* `$context` *(array)* — Context data containing customer (`['customer' => Customer|null]`)
* **Returns:** *(array)* — The modified dashboard data

#### Usage Example:
```php
// Filter customer portal dashboard response data payload
add_filter('fluent_cart/customer_dashboard_data', function($data, $context) {
    // Extract customer model instance from context
    $customer = $context['customer'];
    if ($customer) {
        // Inject welcome banner HTML above customer orders table
        $data['sections_parts']['before_orders_table'] = '<div class="welcome-banner">Welcome back!</div>';
    }
    return $data;
}, 10, 2);
```

---

### `global_customer_menu_items`
`fluent_cart/global_customer_menu_items` — Filter customer portal menu items

* **When it runs:** Applied when building customer portal sidebar navigation menu, after built-in items have been conditionally removed.
* **Source:** `app/Hooks/Handlers/ShortCodes/CustomerProfileHandler.php` (line 266)

#### Parameters:
* `$menuItems` *(array)* — Associative array of menu items keyed by slug (`orders`, `subscriptions`, `licenses`, `downloads`, `profile`)
* `$context` *(array)* — Context data (`['base_url' => string]`)
* **Returns:** *(array)* — The modified menu items array

#### Usage Example:
```php
// Filter customer portal sidebar navigation menu items
add_filter('fluent_cart/global_customer_menu_items', function($menuItems, $context) {
    // Inject custom Support menu item into customer portal navigation
    $baseUrl = $context['base_url'];
    $menuItems['support'] = [
        'label' => 'Support',
        'css_class' => 'fct_route',
        'link' => $baseUrl . 'support',
        'icon_svg' => '<svg>...</svg>'
    ];
    return $menuItems;
}, 10, 2);
```

---

### `customer_portal/active_tab`
`fluent_cart/customer_portal/active_tab` — Filter active tab in customer portal

* **When it runs:** Applied when rendering customer portal to determine which tab should be visually active by default.
* **Source:** `app/Hooks/Handlers/ShortCodes/CustomerProfileHandler.php` (line 117)

#### Parameters:
* `$activeTab` *(string)* — Active tab identifier (default: `''`)
* **Returns:** *(string)* — Modified active tab slug

#### Usage Example:
```php
// Filter default active tab slug in customer portal view
add_filter('fluent_cart/customer_portal/active_tab', function($activeTab) {
    // Set default active tab to subscriptions
    return 'subscriptions';
}, 10, 1);
```

---

### `customer_portal/custom_endpoints`
`fluent_cart/customer_portal/custom_endpoints` — Filter custom portal endpoints

* **When it runs:** Applied when routing customer portal requests to check for registered custom endpoint paths.
* **Source:** `app/Hooks/Handlers/ShortCodes/CustomerProfileHandler.php` (line 141)

#### Parameters:
* `$endpoints` *(array)* — Associative array of custom endpoints (default: `[]`)
* **Returns:** *(array)* — Modified endpoints array

#### Usage Example:
```php
// Register custom endpoint page handlers in customer portal
add_filter('fluent_cart/customer_portal/custom_endpoints', function($endpoints) {
    // Add custom warranty page rendering callback to portal endpoints
    $endpoints['warranty'] = [
        'render_callback' => function() {
            echo '<div class="warranty-page">Warranty info here</div>';
        }
    ];
    return $endpoints;
}, 10, 1);
```

> [!TIP]
> Consider using the `FluentCartGeneralApi::addCustomerPortalEndpoint()` helper method instead, which registers both the menu item and the endpoint in one call.

---

### `customer_portal/subscription_data`
`fluent_cart/customer_portal/subscription_data` — Filter customer portal subscription data

* **When it runs:** Applied when preparing a single subscription's data for display in customer portal, after transactions are loaded.
* **Source:** `app/Http/Controllers/FrontendControllers/CustomerSubscriptionController.php` (line 157)

#### Parameters:
* `$formattedData` *(array)* — Formatted subscription data including transactions
* `$context` *(array)* — Context data (`['subscription' => Subscription, 'customer' => Customer]`)
* **Returns:** *(array)* — Modified subscription data

#### Usage Example:
```php
// Filter subscription data structure formatted for customer portal
add_filter('fluent_cart/customer_portal/subscription_data', function($formattedData, $context) {
    // Extract subscription model instance from context
    $subscription = $context['subscription'];
    // Inject next invoice preview array into subscription details
    $formattedData['next_invoice_preview'] = [
        'amount' => $subscription->recurring_amount,
        'date' => $subscription->expiration_at
    ];
    return $formattedData;
}, 10, 2);
```

---

### `payment_methods/stripe_pub_key`
`fluent_cart/payment_methods/stripe_pub_key` — Filter Stripe public key for customer portal

* **When it runs:** Applied when localizing JavaScript data for customer portal, providing Stripe publishable key.
* **Source:** `app/Hooks/Handlers/ShortCodes/CustomerProfileHandler.php` (line 356)

#### Parameters:
* `$pubKey` *(string)* — Stripe publishable key (default: `''`)
* **Returns:** *(string)* — Modified Stripe public key

#### Usage Example:
```php
// Filter Stripe publishable key passed to customer portal JS
add_filter('fluent_cart/payment_methods/stripe_pub_key', function($pubKey) {
    // Override Stripe publishable key in test environment
    if (defined('STRIPE_TEST_MODE') && STRIPE_TEST_MODE) {
        return 'pk_test_xxxxxxxxxxxx';
    }
    return $pubKey;
}, 10, 1);
```

---

### `payment_methods/paypal_client_id`
`fluent_cart/payment_methods/paypal_client_id` — Filter PayPal client ID for customer portal

* **When it runs:** Applied when localizing JavaScript data for customer portal, providing PayPal client ID.
* **Source:** `app/Hooks/Handlers/ShortCodes/CustomerProfileHandler.php` (line 357)

#### Parameters:
* `$clientId` *(string)* — PayPal client ID (default: `''`)
* `$context` *(array)* — Additional context data (default: `[]`)
* **Returns:** *(string)* — Modified PayPal client ID

#### Usage Example:
```php
// Filter PayPal client ID passed to customer portal JS
add_filter('fluent_cart/payment_methods/paypal_client_id', function($clientId, $context) {
    // Provide sandbox PayPal client ID for client-side JS SDK
    return 'AYourPayPalClientId';
}, 10, 2);
```

---

## Customer Statuses & Auth

### `editable_customer_statuses` (legacy)
`fluent-cart/editable_customer_statuses` — Filter editable customer statuses

* **When it runs:** Applied when retrieving list of customer statuses that can be set in admin panel. Note hyphenated prefix (`fluent-cart/`).
* **Source:** `app/Helpers/Helper.php` (line 162), `app/Helpers/Status.php` (line 350)

#### Parameters:
* `$statuses` *(array)* — Associative array of status key => label (`'active' => 'Active'`, `'inactive' => 'Inactive'`)
* `$context` *(array)* — Additional context data (default: `[]`)
* **Returns:** *(array)* — Modified statuses array

#### Usage Example:
```php
// Filter editable customer statuses in admin panel (legacy hyphenated hook)
add_filter('fluent-cart/editable_customer_statuses', function($statuses, $context) {
    // Add custom "Suspended" status to editable customer statuses
    $statuses['suspended'] = __('Suspended', 'my-plugin');
    return $statuses;
}, 10, 2);
```

---

### `user/after_register/skip_hooks`
`fluent_cart/user/after_register/skip_hooks` — Skip post-registration hooks

* **When it runs:** Applied after a new WP user is created during checkout registration. When true, standard WP hooks like `register_new_user` are skipped.
* **Source:** `app/Services/AuthService.php` (line 122)

#### Parameters:
* `$skip` *(bool)* — Whether to skip hooks (default: `false`)
* `$user_id` *(int)* — Newly created WP user ID
* **Returns:** *(bool)* — Whether to skip post-registration hooks

#### Usage Example:
```php
// Control skipping post-registration hooks during checkout user creation
add_filter('fluent_cart/user/after_register/skip_hooks', function($skip, $userId) {
    // Skip default WP registration hooks to prevent welcome email dispatch
    return true;
}, 10, 2);
```

---

## Subscription Statuses & Configuration

### `subscription_statuses`
`fluent_cart/subscription_statuses` — Filter subscription statuses

* **When it runs:** Applied when retrieving list of all available subscription statuses throughout system.
* **Source:** `app/Helpers/Status.php` (line 253)

#### Parameters:
* `$statuses` *(array)* — Associative array of status key => label (`pending`, `active`, `failing`, `paused`, `expired`, `expiring`, `canceled`, `trialing`, `intended`, `past_due`, `completed`)
* `$context` *(array)* — Additional context data (default: `[]`)
* **Returns:** *(array)* — Modified subscription statuses array

#### Usage Example:
```php
// Filter available subscription statuses array across system
add_filter('fluent_cart/subscription_statuses', function($statuses, $context) {
    // Add custom "On Hold" subscription status
    $statuses['on_hold'] = __('On Hold', 'my-plugin');
    return $statuses;
}, 10, 2);
```

---

### `validable_subscription_statuses`
`fluent_cart/validable_subscription_statuses` — Filter valid (active) subscription statuses

* **When it runs:** Applied when determining which subscription statuses are considered "valid" for granting access (licenses, downloads, etc.).
* **Source:** `app/Helpers/Status.php` (line 271)

#### Parameters:
* `$statuses` *(array)* — Array of status keys considered valid (default: `['active', 'trialing']`)
* `$context` *(array)* — Additional context data (default: `[]`)
* **Returns:** *(array)* — Modified list of valid statuses

#### Usage Example:
```php
// Filter subscription statuses considered valid for access control
add_filter('fluent_cart/validable_subscription_statuses', function($statuses, $context) {
    // Include "expiring" status in list of valid subscription statuses
    $statuses[] = 'expiring';
    return $statuses;
}, 10, 2);
```

---

### `subscription/view`
`fluent_cart/subscription/view` — Filter admin subscription view data

* **When it runs:** Applied when preparing a single subscription's data for display in admin panel.
* **Source:** `app/Modules/Subscriptions/Http/Controllers/SubscriptionController.php` (line 63)

#### Parameters:
* `$subscription` *(\FluentCart\App\Models\Subscription)* — Subscription model with loaded relations
* `$context` *(array)* — Additional context data (default: `[]`)
* **Returns:** *(array)* — Modified subscription data

#### Usage Example:
```php
// Filter single subscription view data structure in admin panel
add_filter('fluent_cart/subscription/view', function($subscription, $context) {
    // Append external Stripe dashboard link to subscription data payload
    $subscription['external_url'] = 'https://dashboard.example.com/subscriptions/' . $subscription['vendor_subscription_id'];
    return $subscription;
}, 10, 2);
```

---

### `subscription/url_{$payment_method}`
`fluent_cart/subscription/url_{$payment_method}` — Filter vendor dashboard URL for a subscription

* **When it runs:** Applied when generating external vendor dashboard URL for subscription. Dynamic hook name with `{$payment_method}` replaced by gateway slug (`stripe`, `paypal`).
* **Source:** `app/Models/Subscription.php` (line 158)

#### Parameters:
* `$url` *(string)* — Vendor dashboard URL (default: `''`)
* `$context` *(array)* — Context data (`['vendor_subscription_id' => string, 'payment_mode' => 'live'|'test', 'subscription' => Subscription]`)
* **Returns:** *(string)* — Modified vendor dashboard URL

#### Usage Example:
```php
// Filter vendor dashboard URL attribute for Stripe subscriptions
add_filter('fluent_cart/subscription/url_stripe', function($url, $context) {
    // Extract vendor subscription ID and payment mode
    $subId = $context['vendor_subscription_id'];
    $mode = $context['payment_mode'];
    $base = ($mode === 'test')
        ? 'https://dashboard.example.com/test'
        : 'https://dashboard.example.com';
    return $base . '/subscriptions/' . $subId;
}, 10, 2);
```

---

### `subscription/can_reactivate`
`fluent_cart/subscription/can_reactivate` — Filter whether subscription can be reactivated

* **When it runs:** Applied when checking if a canceled, failing, expired, paused, expiring, or past-due subscription is eligible for reactivation.
* **Source:** `app/Models/Subscription.php` (line 427)

#### Parameters:
* `$canReactivate` *(bool)* — Whether subscription can be reactivated based on status
* `$context` *(array)* — Context data (`['subscription' => Subscription]`)
* **Returns:** *(bool)* — Modified reactivation eligibility

#### Usage Example:
```php
// Filter whether subscription is eligible for reactivation
add_filter('fluent_cart/subscription/can_reactivate', function($canReactivate, $context) {
    $subscription = $context['subscription'];

    // Prevent reactivation for subscriptions canceled more than 90 days ago
    if ($subscription->status === 'canceled') {
        $canceledAt = strtotime($subscription->updated_at);
        if ((time() - $canceledAt) > (90 * DAY_IN_SECONDS)) {
            return false;
        }
    }
    return $canReactivate;
}, 10, 2);
```

---

### `available_subscription_interval_options`
`fluent_cart/available_subscription_interval_options` — Filter subscription interval options

* **When it runs:** Applied when retrieving list of available subscription billing interval options for product configuration.
* **Source:** `app/Helpers/Helper.php` (line 1531)

#### Parameters:
* `$intervals` *(array)* — Array of interval option objects (`yearly`, `half_yearly`, `quarterly`, `monthly`, `weekly`, `daily`)
* **Returns:** *(array)* — Modified intervals array

#### Usage Example:
```php
// Filter available subscription billing interval options
add_filter('fluent_cart/available_subscription_interval_options', function($intervals) {
    // Add custom "Every 10th Day" billing interval option
    $intervals[] = [
        'label' => __('Every 10th Day', 'my-plugin'),
        'value' => 'every_tenth_day',
        'map_value' => '10th Day'
    ];
    return $intervals;
});
```

> [!TIP]
> When adding custom intervals, you must also implement `fluent_cart/subscription_interval_in_days` and `fluent_cart/subscription_billing_period` filters.

---

### `subscription_interval_in_days`
`fluent_cart/subscription_interval_in_days` — Filter number of days for custom subscription interval

* **When it runs:** Applied when converting subscription interval to day count. Built-in intervals calculate automatically; fires for custom/unknown intervals.
* **Source:** `app/Helpers/Helper.php` (line 1592), `app/Services/Payments/PaymentHelper.php` (line 236)

#### Parameters:
* `$days` *(int)* — Number of days for interval (default: `0` for custom)
* `$context` *(array)* — Context data (`['interval' => string]`)
* **Returns:** *(int)* — Number of days in interval

#### Usage Example:
```php
// Filter day count for custom subscription billing interval
add_filter('fluent_cart/subscription_interval_in_days', function($days, $args) {
    $interval = $args['interval'];

    // Return 10 days for custom every_tenth_day interval
    if ($interval === 'every_tenth_day') {
        return 10;
    }

    // Return 14 days for custom biweekly interval
    if ($interval === 'biweekly') {
        return 14;
    }

    return $days;
}, 10, 2);
```

---

### `max_trial_days_allowed`
`fluent_cart/max_trial_days_allowed` — Filter maximum trial days allowed

* **When it runs:** Applied when calculating adjusted trial days for subscription interval. Ensures trial does not exceed maximum.
* **Source:** `app/Helpers/Helper.php` (line 1566)

#### Parameters:
* `$maxDays` *(int)* — Maximum trial days allowed (default: `365`)
* `$context` *(array)* — Context data (`['existing_trial_days' => int, 'repeat_interval' => string, 'interval_in_days' => int]`)
* **Returns:** *(int)* — Modified maximum trial days

#### Usage Example:
```php
// Filter maximum trial days allowed for subscription intervals
add_filter('fluent_cart/max_trial_days_allowed', function($maxDays, $args) {
    // Cap trial duration at 30 days for monthly subscriptions
    if ($args['repeat_interval'] === 'monthly') {
        return 30;
    }
    return $maxDays;
}, 10, 2);
```

---

### `trial_info`
`fluent_cart/trial_info` — Filter trial info display text

* **When it runs:** Applied when generating human-readable trial information text shown to customers (e.g. "Free Trial: 14 days").
* **Source:** `app/Helpers/Helper.php` (line 1133)

#### Parameters:
* `$trialInfo` *(string)* — Generated trial info text
* `$otherInfo` *(array)* — Product/variant pricing metadata (`trial_days`, `signup_fee`, etc.)
* **Returns:** *(string)* — Modified trial info text

#### Usage Example:
```php
// Filter human-readable trial information display text string
add_filter('fluent_cart/trial_info', function($trialInfo, $otherInfo) {
    // Extract trial days from product pricing metadata
    $days = $otherInfo['trial_days'] ?? 0;
    if ($days > 0) {
        return sprintf('Try free for %d days - no credit card required!', $days);
    }
    return $trialInfo;
}, 10, 2);
```

---

## Subscription Billing

### `subscription_billing_period`
`fluent_cart/subscription_billing_period` — Filter billing period for payment gateways

* **When it runs:** Applied when translating subscription interval into payment gateway billing period format (Stripe Plans, PayPal billing cycles).
* **Source:** `app/Modules/PaymentMethods/StripeGateway/Plan.php` (line 58), `app/Modules/PaymentMethods/PayPalGateway/PayPalHelper.php` (line 243)

#### Parameters:
* `$billingPeriod` *(array)* — Gateway billing period (`['interval_unit' => 'month', 'interval_frequency' => 1]`)
* `$context` *(array)* — Context data (`['subscription_interval' => string, 'payment_method' => 'stripe'|'paypal']`)
* **Returns:** *(array)* — Modified billing period array

#### Usage Example:
```php
// Filter gateway billing period mapping for custom subscription intervals
add_filter('fluent_cart/subscription_billing_period', function($billingPeriod, $args) {
    $interval = $args['subscription_interval'];
    $method = $args['payment_method'];

    // Map custom every_tenth_day interval for Stripe and PayPal gateways
    if ($interval === 'every_tenth_day') {
        if ($method === 'stripe') {
            return [
                'interval_unit' => 'day',
                'interval_frequency' => 10
            ];
        }
        if ($method === 'paypal') {
            return [
                'interval_unit' => 'DAY',
                'interval_frequency' => 10
            ];
        }
    }

    return $billingPeriod;
}, 10, 2);
```

---

### `subscription/grace_period_days`
`fluent_cart/subscription/grace_period_days` — Filter grace period days per billing interval

* **When it runs:** Applied when retrieving grace period (extra days after payment fails before subscription marks expired) for each interval.
* **Source:** `app/Services/Payments/SubscriptionHelper.php` (line 159)

#### Parameters:
* `$gracePeriods` *(array)* — Associative array of interval => days (`daily => 1`, `weekly => 3`, `monthly => 7`, `yearly => 15`)
* **Returns:** *(array)* — Modified grace period days array

#### Usage Example:
```php
// Filter grace period days mapping per subscription billing interval
add_filter('fluent_cart/subscription/grace_period_days', function($gracePeriods) {
    // Extend yearly subscription grace period to 30 days
    $gracePeriods['yearly'] = 30;

    // Define 5-day grace period for custom interval
    $gracePeriods['every_tenth_day'] = 5;

    return $gracePeriods;
});
```

---

## Reminders

### `reminders/scan_batch_size`
`fluent_cart/reminders/scan_batch_size` — Filter reminder scan batch size

* **When it runs:** Applied when automated reminder system scans for subscriptions/invoices needing reminders (default: `100`).
* **Source:** `app/Services/Reminders/ReminderService.php` (line 75)

#### Parameters:
* `$batchSize` *(int)* — Number of records per scan batch (min: `10`, max: `500`)
* **Returns:** *(int)* — Modified batch size

#### Usage Example:
```php
// Filter scan batch size for automated reminder processing
add_filter('fluent_cart/reminders/scan_batch_size', function($batchSize) {
    // Increase scan batch size to 250 records for high-volume processing
    return 250;
});
```

---

### `reminders/invoice_due_days`
`fluent_cart/reminders/invoice_due_days` — Filter invoice due reminder days

* **When it runs:** Applied when determining how many days before an invoice is due to send a reminder notification.
* **Source:** `app/Services/Reminders/InvoiceReminderService.php` (line 288)

#### Parameters:
* `$days` *(int)* — Number of days before due date to send reminder
* **Returns:** *(int)* — Modified number of days

#### Usage Example:
```php
// Filter advance days count for invoice due reminder notifications
add_filter('fluent_cart/reminders/invoice_due_days', function($days) {
    // Dispatch invoice due reminder 3 days prior to due date
    return 3;
});
```

---

### `reminders/invoice_overdue_days`
`fluent_cart/reminders/invoice_overdue_days` — Filter overdue invoice reminder intervals

* **When it runs:** Applied when determining day intervals after invoice becomes overdue to send follow-up reminders (default: `[1, 3, 7]`).
* **Source:** `app/Services/Reminders/InvoiceReminderService.php` (line 299)

#### Parameters:
* `$days` *(array)* — Array of day intervals for overdue reminders
* **Returns:** *(array)* — Modified array of day intervals

#### Usage Example:
```php
// Filter day interval schedule for overdue invoice reminders
add_filter('fluent_cart/reminders/invoice_overdue_days', function($days) {
    // Send overdue follow-up reminders at 1, 3, 7, and 14 days overdue
    return [1, 3, 7, 14];
});
```

---

### `reminders/billing_cycle`
`fluent_cart/reminders/billing_cycle` — Filter billing cycle name for reminder processing

* **When it runs:** Applied when mapping subscription billing interval to cycle identifier used by reminder system.
* **Source:** `app/Services/Reminders/SubscriptionReminderService.php` (line 502)

#### Parameters:
* `$cycle` *(string)* — Billing cycle name (`monthly`, `yearly`, `unsupported`)
* `$subscription` *(\FluentCart\App\Models\Subscription)* — Subscription model instance
* **Returns:** *(string)* — Modified billing cycle name

#### Usage Example:
```php
// Filter billing cycle name mapping for subscription reminder logic
add_filter('fluent_cart/reminders/billing_cycle', function($cycle, $subscription) {
    // Map custom every_tenth_day interval to daily reminder logic
    if ($subscription->billing_interval === 'every_tenth_day') {
        return 'daily';
    }
    return $cycle;
}, 10, 2);
```

---

### `reminders/yearly_before_days`
`fluent_cart/reminders/yearly_before_days` — Filter days before yearly renewal reminder

* **When it runs:** Applied when determining day intervals before yearly subscription renewal to send reminders (default: `[30]`).
* **Source:** `app/Services/Reminders/SubscriptionReminderService.php` (line 534)

#### Parameters:
* `$days` *(array)* — Array of day intervals before renewal
* **Returns:** *(array)* — Modified array of day intervals

#### Usage Example:
```php
// Filter reminder day intervals prior to yearly subscription renewal
add_filter('fluent_cart/reminders/yearly_before_days', function($days) {
    // Dispatch yearly renewal reminders at 60, 30, and 7 days prior
    return [60, 30, 7];
});
```

---

### `reminders/monthly_before_days`
`fluent_cart/reminders/monthly_before_days` — Filter days before monthly renewal reminder

* **When it runs:** Applied when determining day intervals before monthly subscription renewal to send reminders (default: `[7]`).
* **Source:** `app/Services/Reminders/SubscriptionReminderService.php` (line 546)

#### Parameters:
* `$days` *(array)* — Array of day intervals before renewal
* **Returns:** *(array)* — Modified array of day intervals

#### Usage Example:
```php
// Filter reminder day intervals prior to monthly subscription renewal
add_filter('fluent_cart/reminders/monthly_before_days', function($days) {
    // Dispatch monthly renewal reminders at 7 and 3 days prior
    return [7, 3];
});
```

---

### `reminders/quarterly_before_days`
`fluent_cart/reminders/quarterly_before_days` — Filter days before quarterly renewal reminder

* **When it runs:** Applied when determining day intervals before quarterly subscription renewal to send reminders (default: `[14]`).
* **Source:** `app/Services/Reminders/SubscriptionReminderService.php` (line 558)

#### Parameters:
* `$days` *(array)* — Array of day intervals before renewal
* **Returns:** *(array)* — Modified array of day intervals

#### Usage Example:
```php
// Filter reminder day intervals prior to quarterly subscription renewal
add_filter('fluent_cart/reminders/quarterly_before_days', function($days) {
    // Dispatch quarterly renewal reminders at 21 and 7 days prior
    return [21, 7];
});
```

---

### `reminders/half_yearly_before_days`
`fluent_cart/reminders/half_yearly_before_days` — Filter days before half-yearly renewal reminder

* **When it runs:** Applied when determining day intervals before half-yearly subscription renewal to send reminders (default: `[21]`).
* **Source:** `app/Services/Reminders/SubscriptionReminderService.php` (line 570)

#### Parameters:
* `$days` *(array)* — Array of day intervals before renewal
* **Returns:** *(array)* — Modified array of day intervals

#### Usage Example:
```php
// Filter reminder day intervals prior to half-yearly subscription renewal
add_filter('fluent_cart/reminders/half_yearly_before_days', function($days) {
    // Dispatch half-yearly renewal reminders at 30 and 7 days prior
    return [30, 7];
});
```

---

### `reminders/trial_end_days`
`fluent_cart/reminders/trial_end_days` — Filter days before trial end reminder

* **When it runs:** Applied when determining day intervals before trial period ends to send reminders (default: `[3]`).
* **Source:** `app/Services/Reminders/SubscriptionReminderService.php` (line 582)

#### Parameters:
* `$days` *(array)* — Array of day intervals before trial ends
* **Returns:** *(array)* — Modified array of day intervals

#### Usage Example:
```php
// Filter reminder day intervals prior to trial expiration
add_filter('fluent_cart/reminders/trial_end_days', function($days) {
    // Dispatch trial end reminders at 7, 3, and 1 day before expiration
    return [7, 3, 1];
});
```

---

## Pro: Early Payments & Reactivation

### `subscription/early_payment_enabled` (Pro)
`fluent_cart/subscription/early_payment_enabled` — Filter whether early installment payments are enabled

* **When it runs:** Applied when checking if early payment feature for installment subscriptions is globally enabled. Requires Pro plugin.
* **Source:** `app/Modules/Subscriptions/Services/EarlyPaymentFeature.php` (line 14)

#### Parameters:
* `$isEnabled` *(bool)* — Whether early payments are enabled from store settings
* **Returns:** *(bool)* — Modified enabled state

#### Usage Example:
```php
// Filter global enabled state for early installment payments (Pro)
add_filter('fluent_cart/subscription/early_payment_enabled', function($isEnabled) {
    // Disable early payments during December promotion window
    if (current_time('Y-m') === '2026-12') {
        return false;
    }
    return $isEnabled;
});
```

---

### `subscription/can_early_pay` (Pro)
`fluent_cart/subscription/can_early_pay` — Filter whether a specific subscription can make an early payment

* **When it runs:** Applied when checking if a specific installment subscription is eligible for early payment. Requires Pro plugin.
* **Source:** `app/Modules/Subscriptions/Services/EarlyPaymentFeature.php` (line 26)

#### Parameters:
* `$canPay` *(bool)* — Whether subscription can make early payment
* `$context` *(array)* — Context data (`['subscription' => Subscription]`)
* **Returns:** *(bool)* — Modified eligibility

#### Usage Example:
```php
// Filter early installment payment eligibility for a subscription (Pro)
add_filter('fluent_cart/subscription/can_early_pay', function($canPay, $context) {
    $subscription = $context['subscription'];

    // Require more than 2 remaining installments for early payment
    $remaining = $subscription->bill_times - $subscription->bill_count;
    if ($remaining <= 2) {
        return false;
    }

    return $canPay;
}, 10, 2);
```

---

### `subscription/reactivation_same_price_days_limit` (Pro)
`fluent_cart/subscription/reactivation_same_price_days_limit` — Filter days limit for same-price reactivation

* **When it runs:** Applied when customer reactivates canceled/expired subscription at original price without new checkout (default: `60` days). Requires Pro.
* **Source:** `fluent-cart-pro/.../SubscriptionRenewalHandler.php` (line 234)

#### Parameters:
* `$daysLimit` *(int)* — Number of days within which same-price reactivation is allowed (default: `60`)
* `$context` *(array)* — Context data (`['subscription' => Subscription]`)
* **Returns:** *(int)* — Modified days limit

#### Usage Example:
```php
// Filter maximum days limit allowed for same-price subscription reactivation (Pro)
add_filter('fluent_cart/subscription/reactivation_same_price_days_limit', function($daysLimit, $context) {
    $subscription = $context['subscription'];

    // Allow 180 days (6 months) same-price reactivation for yearly subscriptions
    if ($subscription->billing_interval === 'yearly') {
        return 180;
    }

    return $daysLimit;
}, 10, 2);
```

---

## Pro: License Customer Portal

### `customer/license_details_section_parts` (Pro)
`fluent_cart/customer/license_details_section_parts` — Filter license details section parts in customer portal

* **When it runs:** Applied when rendering license details page in customer portal, allowing HTML section injection. Requires Pro plugin.
* **Source:** `fluent-cart-pro/.../CustomerProfileController.php` (line 97)

#### Parameters:
* `$sectionParts` *(array)* — Associative array of injectable HTML sections (`before_summary`, `after_summary`, `end_of_details`, `additional_actions`)
* `$context` *(array)* — Context data (`['license' => License, 'formattedData' => array]`)
* **Returns:** *(array)* — Modified section parts array

#### Usage Example:
```php
// Filter injectable HTML section parts on customer license details page (Pro)
add_filter('fluent_cart/customer/license_details_section_parts', function($parts, $context) {
    $license = $context['license'];

    // Inject activation guide HTML section after license summary
    $parts['after_summary'] = '<div class="activation-guide">'
        . '<h4>How to Activate</h4>'
        . '<p>Copy your license key and paste it in your plugin settings.</p>'
        . '</div>';

    // Inject custom regenerate key action button HTML
    $parts['additional_actions'] = '<button class="btn-regenerate" onclick="regenerateLicense(\'' . $license->id . '\')">Regenerate Key</button>';

    return $parts;
}, 10, 2);
```

---

# Filter Hooks: Integrations & Advanced

All filters related to external integrations, file storage, templates, License management, and advanced features.

---

## Integration Actions & Feeds

### `order_integrations`
`fluent_cart/integration/order_integrations` — Filter all registered order integrations

* **When it runs:** Applied when retrieving the list of all registered order integrations across event listeners, controllers, settings, and addons.
* **Source:** `IntegrationEventListener.php` (lines 54, 247, 386), `IntegrationController.php` (lines 96, 150), `ProductIntegrationsController.php` (lines 18, 48), `GlobalIntegrationSettings.php` (line 84)

#### Parameters:
* `$integrations` *(array)* — Array of registered integrations (`MailChimp`, `FluentCRM`, etc.)
* **Returns:** *(array)* — The modified integrations array

#### Usage Example:
```php
// Filter array of registered order integrations in FluentCart
add_filter('fluent_cart/integration/order_integrations', function ($integrations) {
    // Add custom CRM integration definition array
    $integrations['custom_crm'] = [
        'title'   => 'Custom CRM',
        'logo'    => 'https://example.com/crm-logo.png',
        'enabled' => true,
    ];
    return $integrations;
});
```

---

### `run_all_actions_on_async`
`fluent_cart/integration/run_all_actions_on_async` — Force all integration actions to run asynchronously

* **When it runs:** Controls whether integration actions should be dispatched asynchronously instead of immediately during order processing.
* **Source:** `IntegrationEventListener.php` (line 145)

#### Parameters:
* `$async` *(bool)* — Whether to force async execution (default: `false`)
* `$order` *(\FluentCart\App\Models\Order)* — The order model instance
* `$hook` *(string)* — The integration hook being fired
* **Returns:** *(bool)* — Whether to run actions asynchronously

#### Usage Example:
```php
// Force integration actions to dispatch asynchronously for large orders
add_filter('fluent_cart/integration/run_all_actions_on_async', function ($async, $order, $hook) {
    // Force async execution for orders exceeding $1,000 total
    if ($order->total > 100000) {
        return true;
    }
    return $async;
}, 10, 3);
```

---

### `global_notification_types`
`fluent_cart/integration/global_notification_types` — Filter available notification types

* **When it runs:** Applied when retrieving the list of available global notification types for integrations.
* **Source:** `GlobalIntegrationSettings.php` (line 119)

#### Parameters:
* `$types` *(array)* — Array of notification types (`email`, etc.)
* **Returns:** *(array)* — The modified notification types array

#### Usage Example:
```php
// Filter available global integration notification types array
add_filter('fluent_cart/integration/global_notification_types', function ($types) {
    // Append SMS notification type definition
    $types['sms'] = [
        'title'       => 'SMS Notification',
        'description' => 'Send SMS notifications on order events',
    ];
    return $types;
});
```

---

### `global_notification_feed_{$feed_key}`
`fluent_cart/integration/global_notification_feed_{$feed_key}` — Filter notification feed data (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving notification feed data for a specific feed key.
* **Source:** `GlobalIntegrationSettings.php` (line 151)

#### Parameters:
* `$feedData` *(array)* — The notification feed data array
* **Returns:** *(array)* — The modified feed data array

#### Usage Example:
```php
// Filter notification feed data array for email alerts feed
add_filter('fluent_cart/integration/global_notification_feed_email_alerts', function ($feedData) {
    // Append additional admin email recipient to feed data
    $feedData['recipients'][] = 'extra-admin@example.com';
    return $feedData;
});
```

---

### `get_global_integration_actions`
`fluent_cart/integration/get_global_integration_actions` — Filter global integration actions

* **When it runs:** Applied when retrieving available global integration actions triggered by order events.
* **Source:** `GlobalIntegrationActionHandler.php` (line 22)

#### Parameters:
* `$actions` *(array)* — Array of integration actions (default: `[]`)
* **Returns:** *(array)* — The modified integration actions array

#### Usage Example:
```php
// Filter available global integration actions list
add_filter('fluent_cart/integration/get_global_integration_actions', function ($actions) {
    // Append custom webhook action definition to integration actions
    $actions['custom_webhook'] = [
        'title'   => 'Fire Custom Webhook',
        'enabled' => true,
    ];
    return $actions;
});
```

---

### `notifying_async_{$feedKey}`
`fluent_cart/integration/notifying_async_{$feedKey}` — Control async notification per feed (DYNAMIC)

* **When it runs:** Dynamic filter controlling whether a specific notification feed is processed asynchronously (default: `true`).
* **Source:** `GlobalNotificationHandler.php` (line 104)

#### Parameters:
* `$async` *(bool)* — Whether to process notification asynchronously (default: `true`)
* **Returns:** *(bool)* — Whether to use async processing

#### Usage Example:
```php
// Control async notification dispatch for email alerts feed
add_filter('fluent_cart/integration/notifying_async_email_alerts', function ($async) {
    // Force synchronous processing for email alerts notification feed
    return false;
});
```

---

### `webhook/payload` (Pro)
`fluent_cart/webhook/payload` — Filter webhook payload before sending

* **When it runs:** Applied to webhook payload body after construction, before encoding and dispatching to external endpoint. Requires Pro plugin.
* **Source:** `fluent-cart-pro/.../WebhookConnect.php` (line 251)

#### Parameters:
* `$payloadBody` *(array)* — Payload body data array
* `$context` *(array)* — Context data (`['order' => Order, 'feed' => array, 'event_data' => array]`)
* **Returns:** *(array)* — The modified payload body array

#### Usage Example:
```php
// Filter webhook payload array before sending to external endpoint (Pro)
add_filter('fluent_cart/webhook/payload', function ($payloadBody, $context) {
    // Append custom tracking metadata to payload body
    $payloadBody['custom_meta'] = [
        'source'    => 'fluentcart',
        'timestamp' => gmdate('Y-m-d H:i:s')
    ];

    // Remove customer email address from webhook payload
    unset($payloadBody['customer']['email']);

    return $payloadBody;
}, 10, 2);
```

---

## Integration Settings & Configuration

### `global_integration_settings_{$key}`
`fluent_cart/integration/global_integration_settings_{$key}` — Filter integration settings (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving settings for a specific integration (e.g. `mailchimp`, `zapier`).
* **Source:** `GlobalIntegrationSettings.php` (line 24)

#### Parameters:
* `$settings` *(array)* — Integration settings array (default: `[]`)
* **Returns:** *(array)* — The modified settings array

#### Usage Example:
```php
// Filter integration settings array for MailChimp integration
add_filter('fluent_cart/integration/global_integration_settings_mailchimp', function ($settings) {
    // Override MailChimp API key from environment constant if defined
    $settings['api_key'] = defined('MAILCHIMP_API_KEY') ? MAILCHIMP_API_KEY : $settings['api_key'];
    return $settings;
});
```

---

### `global_integration_fields_{$key}`
`fluent_cart/integration/global_integration_fields_{$key}` — Filter integration field definitions (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving field definitions for an integration configuration form.
* **Source:** `GlobalIntegrationSettings.php` (line 25)

#### Parameters:
* `$fields` *(array)* — Field definitions array (default: `[]`)
* **Returns:** *(array)* — The modified field definitions array

#### Usage Example:
```php
// Filter integration configuration form fields for MailChimp
add_filter('fluent_cart/integration/global_integration_fields_mailchimp', function ($fields) {
    // Append double opt-in checkbox field definition
    $fields[] = [
        'key'   => 'double_optin',
        'label' => 'Enable Double Opt-in',
        'type'  => 'checkbox',
    ];
    return $fields;
});
```

---

### `get_integration_defaults_{$name}`
`fluent_cart/integration/get_integration_defaults_{$name}` — Filter integration defaults (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving default settings for a specific integration.
* **Source:** `GlobalIntegrationSettings.php` (lines 199, 201)

#### Parameters:
* `$defaults` *(array)* — Default settings values array
* **Returns:** *(array)* — The modified defaults array

#### Usage Example:
```php
// Filter default settings values for MailChimp integration
add_filter('fluent_cart/integration/get_integration_defaults_mailchimp', function ($defaults) {
    // Set default audience list ID and tag array
    $defaults['list_id'] = 'default_list_123';
    $defaults['tags']    = ['fluentcart-customer'];
    return $defaults;
});
```

---

### `get_integration_settings_fields_{$name}`
`fluent_cart/integration/get_integration_settings_fields_{$name}` — Filter integration settings fields (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving settings field definitions for a specific integration.
* **Source:** `GlobalIntegrationSettings.php` (lines 204, 276), `IntegrationHelper.php` (line 27)

#### Parameters:
* `$fields` *(array)* — Field definitions array (default: `[]`)
* **Returns:** *(array)* — The modified field definitions array

#### Usage Example:
```php
// Filter settings form field definitions for Zapier integration
add_filter('fluent_cart/integration/get_integration_settings_fields_zapier', function ($fields) {
    // Append webhook URL input field definition
    $fields[] = [
        'key'         => 'webhook_url',
        'label'       => 'Webhook URL',
        'type'        => 'url',
        'required'    => true,
        'placeholder' => 'https://hooks.zapier.com/...',
    ];
    return $fields;
});
```

---

### `save_integration_values_{$name}`
`fluent_cart/integration/save_integration_values_{$name}` — Filter before saving integration data (DYNAMIC)

* **When it runs:** Dynamic filter applied just before integration settings are saved to database.
* **Source:** `GlobalIntegrationSettings.php` (line 248)

#### Parameters:
* `$integration` *(\FluentCart\App\Models\Meta)* — Meta model instance containing integration data
* **Returns:** *(\FluentCart\App\Models\Meta)* — The modified Meta model instance

#### Usage Example:
```php
// Filter Meta model instance before saving MailChimp integration data
add_filter('fluent_cart/integration/save_integration_values_mailchimp', function ($integration) {
    // Encrypt API key field value before persisting to database
    $value = $integration->value;
    if (!empty($value['api_key'])) {
        $value['api_key_encrypted'] = encrypt($value['api_key']);
    }
    $integration->value = $value;
    return $integration;
});
```

---

### `get_integration_merge_fields_{$name}`
`fluent_cart/integration/get_integration_merge_fields_{$name}` — Filter integration merge/mapping fields (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving merge fields for mapping FluentCart data to external service fields.
* **Source:** `GlobalIntegrationSettings.php` (line 369)

#### Parameters:
* `$list` *(array)* — Merge fields list array
* `$listId` *(string)* — Audience or list identifier
* **Returns:** *(array)* — The modified merge fields array

#### Usage Example:
```php
// Filter integration merge mapping fields for MailChimp
add_filter('fluent_cart/integration/get_integration_merge_fields_mailchimp', function ($list, $listId) {
    // Append Company Name field to merge fields mapping list
    $list[] = [
        'key'   => 'COMPANY',
        'label' => 'Company Name',
        'type'  => 'text',
    ];
    return $list;
}, 10, 2);
```

---

### `integration_options_{$key}`
`fluent_cart/integration/integration_options_{$key}` — Filter dynamic integration options (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving option values for integration dropdown or selection fields.
* **Source:** `IntegrationController.php` (line 302)

#### Parameters:
* `$options` *(array)* — Options array (default: `[]`)
* **Returns:** *(array)* — The modified options array

#### Usage Example:
```php
// Filter dynamic dropdown option values for MailChimp lists
add_filter('fluent_cart/integration/integration_options_mailchimp_lists', function ($options) {
    // Append custom audience option definition to list
    $options[] = [
        'id'    => 'custom_list',
        'title' => 'Custom Audience',
    ];
    return $options;
});
```

---

### `integration_saving_data_{$provider}`
`fluent_cart/integration/integration_saving_data_{$provider}` — Filter integration data before validation (DYNAMIC)

* **When it runs:** Dynamic filter applied to integration data before saving validation.
* **Source:** `IntegrationHelper.php` (line 62)

#### Parameters:
* `$validatedData` *(array)* — Validated integration data array
* **Returns:** *(array)* — The modified validated data array

#### Usage Example:
```php
// Filter MailChimp integration data before saving validation
add_filter('fluent_cart/integration/integration_saving_data_mailchimp', function ($validatedData) {
    // Convert tag strings to lowercase before saving
    if (!empty($validatedData['tags'])) {
        $validatedData['tags'] = array_map('strtolower', $validatedData['tags']);
    }
    return $validatedData;
});
```

---

### `editing_integration_{$key}`
`fluent_cart/integration/editing_integration_{$key}` — Filter integration data when editing (DYNAMIC)

* **When it runs:** Dynamic filter applied when an integration is loaded for editing in admin UI.
* **Source:** `IntegrationHelper.php` (line 80)

#### Parameters:
* `$data` *(array)* — Integration data for editing
* `$args` *(array)* — Additional context arguments
* **Returns:** *(array)* — The modified integration data

#### Usage Example:
```php
// Filter integration data when loading for edit in admin UI
add_filter('fluent_cart/integration/editing_integration_mailchimp', function ($data, $args) {
    // Decrypt API key for editing interface display
    if (!empty($data['api_key_encrypted'])) {
        $data['api_key'] = decrypt($data['api_key_encrypted']);
    }
    return $data;
}, 10, 2);
```

---

## Integration Addons

### `addons`
`fluent_cart/integration/addons` — Filter the integration addons list

* **When it runs:** Applied when retrieving list of available integration addons in admin interface.
* **Source:** `AddonsController.php` (line 87)

#### Parameters:
* `$addons` *(array)* — Array of addon definitions
* **Returns:** *(array)* — The modified addons array

#### Usage Example:
```php
// Filter available integration addons list in admin panel
add_filter('fluent_cart/integration/addons', function ($addons) {
    // Register custom integration addon definition
    $addons['my_addon'] = [
        'title'       => 'My Custom Addon',
        'description' => 'Adds custom integration functionality',
        'logo'        => 'https://example.com/addon-logo.png',
        'enabled'     => true,
    ];
    return $addons;
});
```

---

### `installable_repo_plugins`
`fluent_cart/installable_repo_plugins` — Filter installable plugin recommendations

* **When it runs:** Applied when retrieving recommended plugins installable from within FluentCart admin.
* **Source:** `AddonsController.php` (line 121), `GlobalIntegrationSettings.php` (line 396)

#### Parameters:
* `$plugins` *(array)* — Array of installable plugin definitions
* **Returns:** *(array)* — The modified plugins array

#### Usage Example:
```php
// Filter recommended plugins array installable from WP admin
add_filter('fluent_cart/installable_repo_plugins', function ($plugins) {
    // Append FluentCRM plugin definition to recommended plugins list
    $plugins[] = [
        'title'       => 'FluentCRM',
        'slug'        => 'fluent-crm',
        'description' => 'Email marketing automation',
        'url'         => 'https://wordpress.org/plugins/fluent-crm/',
    ];
    return $plugins;
});
```

---

## File Storage & Downloads

### `local_file_blocked_extensions`
`fluent_cart/local_file_blocked_extensions` — Filter blocked file extensions for local storage

* **When it runs:** Applied when validating local storage file uploads to modify blocked extension list.
* **Source:** `LocalDriver.php` (line 129)

#### Parameters:
* `$blockedExts` *(array)* — Array of blocked file extensions
* `$localFilePath` *(string)* — Local file path
* `$uploadToFilePath` *(string)* — Target upload path
* `$fileInfo` *(array)* — File information array
* **Returns:** *(array)* — The modified blocked extensions array

#### Usage Example:
```php
// Filter blocked file extensions array for local storage driver uploads
add_filter('fluent_cart/local_file_blocked_extensions', function ($blockedExts, $localFilePath, $uploadToFilePath, $fileInfo) {
    // Add SVG and WebP extensions to blocked upload list
    $blockedExts[] = 'svg';
    $blockedExts[] = 'webp';
    return $blockedExts;
}, 10, 4);
```

---

### `download_expiration_minutes`
`fluent_cart/download_expiration_minutes` — Filter S3 download link expiration time

* **When it runs:** Controls how long pre-signed S3 download URLs remain valid.
* **Source:** `S3Driver.php` (lines 237, 252)

#### Parameters:
* `$expirationMinutes` *(int)* — Expiration time in minutes
* `$context` *(array)* — Context data (`['file_path' => string, 'bucket' => string, 'driver' => 's3']`)
* **Returns:** *(int)* — The modified expiration time in minutes

#### Usage Example:
```php
// Filter S3 pre-signed download link expiration time in minutes
add_filter('fluent_cart/download_expiration_minutes', function ($expirationMinutes, $context) {
    // Extend download link validity to 120 minutes for ZIP files
    if (str_ends_with($context['file_path'], '.zip')) {
        return 120;
    }
    return $expirationMinutes;
}, 10, 2);
```

---

### `download_link_validity_in_minutes`
`fluent_cart/download_link_validity_in_minutes` — Filter download link validity duration

* **When it runs:** Controls how long customer-facing download links remain valid (default: `60` minutes).
* **Source:** `Helper.php` (line 1430)

#### Parameters:
* `$minutes` *(int)* — Link validity in minutes (default: `60`)
* `$context` *(array)* — Context data (`['product_download' => Model, 'order_id' => int, 'is_admin' => bool]`)
* **Returns:** *(int)* — The modified validity in minutes

#### Usage Example:
```php
// Filter customer-facing downloadable link validity duration in minutes
add_filter('fluent_cart/download_link_validity_in_minutes', function ($minutes, $context) {
    // Grant 24-hour download link validity window for admin users
    if ($context['is_admin']) {
        return 1440;
    }
    return $minutes;
}, 10, 2);
```

---

### `product_download/can_be_downloaded`
`fluent_cart/product_download/can_be_downloaded` — Filter whether a file can be downloaded

* **When it runs:** Applied during download validation to determine download permission.
* **Source:** `FileDownloader.php` (line 95)

#### Parameters:
* `$canDownload` *(bool|\WP_Error)* — Download permission boolean or rejection `WP_Error`
* **Returns:** *(bool|\WP_Error)* — The modified download permission

#### Usage Example:
```php
// Filter whether customer is permitted to download digital file
add_filter('fluent_cart/product_download/can_be_downloaded', function ($canDownload) {
    // Block file downloads during maintenance mode
    if (get_option('fluent_cart_maintenance_mode')) {
        return new \WP_Error('maintenance', 'Downloads are temporarily disabled during maintenance.');
    }
    return $canDownload;
});
```

---

### `get_global_storage_settings_{$driver}`
`fluent_cart/storage/get_global_storage_settings_{$driver}` — Filter storage driver settings (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving settings for a specific storage driver (`s3`, `local`).
* **Source:** `api/StorageDrivers.php` (line 18)

#### Parameters:
* `$settings` *(array)* — Storage driver settings array (default: `[]`)
* **Returns:** *(array)* — The modified settings array

#### Usage Example:
```php
// Filter global S3 storage driver settings array
add_filter('fluent_cart/storage/get_global_storage_settings_s3', function ($settings) {
    // Override S3 bucket and region from environment constants if set
    $settings['bucket'] = defined('S3_BUCKET') ? S3_BUCKET : $settings['bucket'];
    $settings['region'] = defined('S3_REGION') ? S3_REGION : $settings['region'];
    return $settings;
});
```

---

### `get_global_storage_drivers`
`fluent_cart/storage/get_global_storage_drivers` — Filter all available storage drivers

* **When it runs:** Applied when retrieving list of all available storage drivers.
* **Source:** `StorageDrivers.php` (line 28)

#### Parameters:
* `$drivers` *(array)* — Array of storage driver definitions (default: `[]`)
* **Returns:** *(array)* — The modified drivers array

#### Usage Example:
```php
// Filter available file storage driver definitions array
add_filter('fluent_cart/storage/get_global_storage_drivers', function ($drivers) {
    // Register custom Backblaze B2 storage driver handler
    $drivers['backblaze'] = [
        'title'       => 'Backblaze B2',
        'description' => 'Store files on Backblaze B2',
        'handler'     => 'BackblazeDriver',
    ];
    return $drivers;
});
```

---

### `get_global_storage_driver_status_{$driver}`
`fluent_cart/storage/get_global_storage_driver_status_{$driver}` — Filter storage driver status (DYNAMIC)

* **When it runs:** Dynamic filter retrieving connection status for a specific storage driver.
* **Source:** `StorageDrivers.php` (line 65)

#### Parameters:
* `$status` *(array)* — Driver status array (default: `[]`)
* **Returns:** *(array)* — The modified status array

#### Usage Example:
```php
// Filter connection status array for S3 storage driver
add_filter('fluent_cart/storage/get_global_storage_driver_status_s3', function ($status) {
    // Set connected status and success message for S3 driver
    $status['connected'] = true;
    $status['message']   = 'Connected to S3 bucket successfully';
    return $status;
});
```

---

### `verify_driver_connect_info_{$driver}`
`fluent_cart/verify_driver_connect_info_{$driver}` — Filter driver connection verification (DYNAMIC)

* **When it runs:** Dynamic filter applied when verifying connection info for a storage driver.
* **Source:** `StorageDrivers.php` (line 79)

#### Parameters:
* `$settings` *(array)* — Driver connection settings array
* **Returns:** *(array)* — The modified settings array

#### Usage Example:
```php
// Filter S3 storage driver connection verification check
add_filter('fluent_cart/verify_driver_connect_info_s3', function ($settings) {
    // Verify AWS S3 credentials via SDK bucket listing test
    try {
        $client = new \Aws\S3\S3Client($settings);
        $client->listBuckets();
        $settings['verified'] = true;
    } catch (\Exception $e) {
        $settings['error'] = $e->getMessage();
    }
    return $settings;
});
```

---

### `storage_settings_before_update_{$slug}`
`fluent_cart/storage/storage_settings_before_update_{$slug}` — Filter storage settings before saving (DYNAMIC)

* **When it runs:** Dynamic filter applied just before storage driver settings are saved.
* **Source:** `BaseStorageDriver.php` (line 152)

#### Parameters:
* `$settings` *(array)* — New settings array
* `$oldSettings` *(array)* — Previous settings array
* **Returns:** *(array)* — The modified settings array

#### Usage Example:
```php
// Filter S3 storage driver settings before saving to database
add_filter('fluent_cart/storage/storage_settings_before_update_s3', function ($settings, $oldSettings) {
    // Preserve existing S3 secret key if omitted in update request
    if (empty($settings['secret_key']) && !empty($oldSettings['secret_key'])) {
        $settings['secret_key'] = $oldSettings['secret_key'];
    }
    return $settings;
}, 10, 2);
```

---

## Localization & Address

### `country_state_options`
`fluent_cart/country_state_options` — Filter country and state options

* **When it runs:** Applied when retrieving country and state dropdown options for address forms.
* **Source:** `LocalizationManager.php` (line 425)

#### Parameters:
* `$options` *(array)* — Country/state options array
* **Returns:** *(array)* — The modified options array

#### Usage Example:
```php
// Filter country and state dropdown options array for address forms
add_filter('fluent_cart/country_state_options', function ($options) {
    // Exclude invalid country code XX from countries dropdown list
    unset($options['countries']['XX']);
    return $options;
});
```

---

### `address/postcode/format`
`fluent_cart/address/postcode/format` — Filter postcode formatting

* **When it runs:** Applied when formatting a postcode value, typically during address validation.
* **Source:** `PostcodeVerification.php` (line 53)

#### Parameters:
* `$postcode` *(string)* — Trimmed postcode value
* `$country` *(string)* — Country code (ISO 3166-1 alpha-2)
* **Returns:** *(string)* — The formatted postcode string

#### Usage Example:
```php
// Filter formatted postcode string value during verification
add_filter('fluent_cart/address/postcode/format', function ($postcode, $country) {
    // Format UK postcode with space delimiter
    if ($country === 'GB' && strlen($postcode) > 3 && strpos($postcode, ' ') === false) {
        return substr($postcode, 0, -3) . ' ' . substr($postcode, -3);
    }
    return $postcode;
}, 10, 2);
```

---

### `address/postcode/is_valid`
`fluent_cart/address/postcode/is_valid` — Filter postcode validation result

* **When it runs:** Applied after postcode validation to enforce custom validation rules.
* **Source:** `PostcodeVerification.php` (line 154)

#### Parameters:
* `$valid` *(bool)* — Whether postcode is valid
* `$postcode` *(string)* — Postcode being validated
* `$country` *(string)* — Country code (ISO 3166-1 alpha-2)
* **Returns:** *(bool)* — The modified validation result

#### Usage Example:
```php
// Filter postcode validity verification result boolean
add_filter('fluent_cart/address/postcode/is_valid', function ($valid, $postcode, $country) {
    // Validate 5-digit numeric postcode regex for custom country XX
    if ($country === 'XX') {
        return preg_match('/^\d{5}$/', $postcode) === 1;
    }
    return $valid;
}, 10, 3);
```

---

### `util/countries` (legacy)
`fluent-cart/util/countries` — Filter the country list

* **When it runs:** Applied when retrieving full list of countries. Note hyphenated prefix (`fluent-cart/`).
* **Source:** `Helper.php` (line 1140)

#### Parameters:
* `$options` *(array)* — Array of country code => country name pairs
* **Returns:** *(array)* — The modified country list array

#### Usage Example:
```php
// Filter global country list array (legacy hyphenated hook name)
add_filter('fluent-cart/util/countries', function ($options) {
    // Restrict countries list to US, CA, GB, and AU
    return array_intersect_key($options, array_flip(['US', 'CA', 'GB', 'AU']));
});
```

---

## Templates & Frontend

### `template/disable_taxonomy_fallback`
`fluent_cart/template/disable_taxonomy_fallback` — Disable taxonomy fallback template

* **When it runs:** Controls whether taxonomy fallback template should be disabled (default: `false`).
* **Source:** `TemplateLoader.php` (line 113)

#### Parameters:
* `$disable` *(bool)* — Whether to disable taxonomy fallback
* **Returns:** *(bool)* — The modified boolean value

#### Usage Example:
```php
// Filter whether to disable taxonomy fallback template rendering
add_filter('fluent_cart/template/disable_taxonomy_fallback', function ($disable) {
    // Disable taxonomy template fallback when custom theme template is active
    return true;
});
```

---

### `has_block_template`
`fluent_cart/has_block_template` — Filter block template existence check

* **When it runs:** Applied when checking if block template exists for current page.
* **Source:** `TemplateLoader.php` (line 193)

#### Parameters:
* `$hasTemplate` *(bool)* — Whether a block template exists
* **Returns:** *(bool)* — The modified boolean result

#### Usage Example:
```php
// Filter block template existence check result for current page
add_filter('fluent_cart/has_block_template', function ($hasTemplate) {
    // Force classic template rendering by returning false
    return false;
});
```

---

### `template_loader_files`
`fluent_cart/template_loader_files` — Filter template files to load

* **When it runs:** Applied when determining which template files should be loaded for current request.
* **Source:** `TemplateLoader.php` (line 206)

#### Parameters:
* `$files` *(array)* — Array of template file paths (default: `[]`)
* **Returns:** *(array)* — The modified template files array

#### Usage Example:
```php
// Filter array of template file paths loaded for request
add_filter('fluent_cart/template_loader_files', function ($files) {
    // Append custom stylesheet theme template file path
    $files[] = get_stylesheet_directory() . '/fluent-cart/custom-template.php';
    return $files;
});
```

---

### `template_path`
`fluent_cart/template_path` — Filter theme template path

* **When it runs:** Controls directory path within a theme where FluentCart template overrides are located (default: `'fluent-cart/'`).
* **Source:** `TemplateLoader.php` (line 248)

#### Parameters:
* `$path` *(string)* — Template directory path
* **Returns:** *(string)* — The modified template path

#### Usage Example:
```php
// Filter theme directory path storing FluentCart template overrides
add_filter('fluent_cart/template_path', function ($path) {
    // Override template overrides directory path in active theme
    return 'my-store/templates/';
});
```

---

### `fluent_cart_template_part_content`
`fluent_cart_template_part_content` — Filter template part content

* **When it runs:** Applied to template part content before rendering.
* **Source:** `ProductModalTemplatePart.php` (line 245)

#### Parameters:
* `$content` *(string)* — Template part content string
* `$slug` *(string)* — Template part slug
* `$args` *(array)* — Template arguments
* **Returns:** *(string)* — The modified content string

#### Usage Example:
```php
// Filter template part content string before rendering
add_filter('fluent_cart_template_part_content', function ($content, $slug, $args) {
    // Wrap product card template part HTML in custom container div
    if ($slug === 'product-card') {
        $content = '<div class="custom-wrapper">' . $content . '</div>';
    }
    return $content;
}, 10, 3);
```

---

### `fluent_cart_template_part_content_{$slug}`
`fluent_cart_template_part_content_{$slug}` — Filter template part content by slug (DYNAMIC)

* **When it runs:** Dynamic filter applied to a specific template part's content.
* **Source:** `ProductModalTemplatePart.php` (line 246)

#### Parameters:
* `$content` *(string)* — Template part content string
* `$args` *(array)* — Template arguments
* **Returns:** *(string)* — The modified content string

#### Usage Example:
```php
// Filter product card template part content by slug
add_filter('fluent_cart_template_part_content_product-card', function ($content, $args) {
    // Append New badge HTML element to product card content
    $content .= '<span class="badge">New</span>';
    return $content;
}, 10, 2);
```

---

### `fluent_cart_template_part_output`
`fluent_cart_template_part_output` — Filter template part output

* **When it runs:** Applied to final rendered output of a template part.
* **Source:** `ProductModalTemplatePart.php` (line 252)

#### Parameters:
* `$output` *(string)* — Rendered template part output HTML
* **Returns:** *(string)* — The modified output string

#### Usage Example:
```php
// Filter final rendered output string of template part
add_filter('fluent_cart_template_part_output', function ($output) {
    // Minify rendered template part output whitespace
    return preg_replace('/\s+/', ' ', $output);
});
```

---

### `fluent_cart_template_part_output_{$slug}`
`fluent_cart_template_part_output_{$slug}` — Filter template part output by slug (DYNAMIC)

* **When it runs:** Dynamic filter applied to final rendered output of a specific template part.
* **Source:** `ProductModalTemplatePart.php` (line 253)

#### Parameters:
* `$output` *(string)* — Rendered output HTML
* **Returns:** *(string)* — The modified output string

#### Usage Example:
```php
// Filter final output string of product modal template part
add_filter('fluent_cart_template_part_output_product-modal', function ($output) {
    // Inject custom tracking data attribute into modal container div
    return str_replace('<div class="fct-modal"', '<div class="fct-modal" data-tracking="true"', $output);
});
```

---

### `buttons/enable_floating_cart_button`
`fluent_cart/buttons/enable_floating_cart_button` — Filter floating cart button visibility

* **When it runs:** Controls whether floating cart button is displayed on frontend (default: `true`).
* **Source:** `app/Hooks/Cart/CartLoader.php` (line 41)

#### Parameters:
* `$enabled` *(bool)* — Whether floating cart button is enabled
* **Returns:** *(bool)* — The modified boolean value

#### Usage Example:
```php
// Filter frontend floating cart button visibility toggle
add_filter('fluent_cart/buttons/enable_floating_cart_button', function ($enabled) {
    // Disable floating cart button on landing page
    if (is_page('landing-page')) {
        return false;
    }
    return $enabled;
});
```

---

## Widgets & Dashboard

### `{$widgetName}`
`fluent_cart/{$widgetName}` — Filter widget data by name (DYNAMIC)

* **When it runs:** Dynamic filter applied when dashboard widget retrieves its data.
* **Source:** `app/Services/Widgets/BaseWidget.php` (line 16)

#### Parameters:
* `$widgetData` *(mixed)* — Widget data array returned by `widgetData()`
* **Returns:** *(mixed)* — The modified widget data

#### Usage Example:
```php
// Filter dashboard revenue widget data array dynamically
add_filter('fluent_cart/revenue_widget', function ($widgetData) {
    // Inject calculated custom metric value into revenue widget data
    $widgetData['custom_metric'] = calculate_custom_metric();
    return $widgetData;
});
```

---

### `widgets/{$filter}`
`fluent_cart/widgets/{$filter}` — Filter widget data by filter key (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving widget data for filter key in widgets controller.
* **Source:** `WidgetsController.php` (line 36)

#### Parameters:
* `$result` *(array)* — Widget result data array (default: `[]`)
* `$data` *(array)* — Request data array
* **Returns:** *(array)* — The modified widget data array

#### Usage Example:
```php
// Filter sales overview widget chart data array dynamically
add_filter('fluent_cart/widgets/sales_overview', function ($result, $data) {
    // Attach custom chart dataset structure to sales overview widget
    $result['custom_chart'] = [
        'labels' => ['Jan', 'Feb', 'Mar'],
        'data'   => [100, 200, 150],
    ];
    return $result;
}, 10, 2);
```

---

### `promo_gateways`
`fluent_cart/promo_gateways` — Filter promotional gateways

* **When it runs:** Applied when retrieving list of promotional payment gateways shown in admin.
* **Source:** `PromoGatewaysHandler.php` (line 36)

#### Parameters:
* `$defaultGateways` *(array)* — Array of default promotional gateways
* **Returns:** *(array)* — The modified gateways array

#### Usage Example:
```php
// Filter promotional payment gateways list in admin panel
add_filter('fluent_cart/promo_gateways', function ($gateways) {
    // Remove specific example gateway from promotional gateways
    unset($gateways['example_gateway']);
    return $gateways;
});
```

---

### `addon_gateways`
`fluent_cart/addon_gateways` — Filter addon payment gateways

* **When it runs:** Applied when retrieving list of addon payment gateways.
* **Source:** `AddonGatewaysHandler.php` (line 36)

#### Parameters:
* `$defaultGateways` *(array)* — Array of default addon gateways
* **Returns:** *(array)* — The modified gateways array

#### Usage Example:
```php
// Filter addon payment gateways list array
add_filter('fluent_cart/addon_gateways', function ($gateways) {
    // Register custom payment gateway addon definition
    $gateways['custom_pay'] = [
        'title'       => 'Custom Pay',
        'description' => 'Custom payment gateway addon',
        'is_active'   => true,
    ];
    return $gateways;
});
```

---

## Advanced List Filters

### `{$filter}_list_filter_query`
`fluent_cart/{$filter}_list_filter_query` — Filter list filter query (DYNAMIC)

* **When it runs:** Dynamic filter applied when building database queries for filtered list pages (orders, customers, subscriptions, etc.).
* **Source:** `BaseFilter.php` (lines 962, 971)

#### Parameters:
* `$query` *(\FluentCart\Framework\Database\Orm\Builder)* — Eloquent query builder instance
* **Returns:** *(\FluentCart\Framework\Database\Orm\Builder)* — The modified query builder

#### Usage Example:
```php
// Filter Eloquent query builder for admin orders list view
add_filter('fluent_cart/orders_list_filter_query', function ($query) {
    // Restrict orders list query to orders created within last 30 days
    $query->where('created_at', '>=', gmdate('Y-m-d H:i:s', strtotime('-30 days')));
    return $query;
});
```

---

### `{$filterName}_filter_options`
`fluent_cart/{$filterName}_filter_options` — Filter options for list page filters (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving available filter options for admin list pages.
* **Source:** `BaseFilter.php` (line 995)

#### Parameters:
* `$options` *(array)* — Filter options array
* **Returns:** *(array)* — The modified filter options array

#### Usage Example:
```php
// Filter available filter dropdown options for orders list page
add_filter('fluent_cart/orders_filter_options', function ($options) {
    // Inject custom status dropdown filter option for orders list page
    $options['custom_status'] = [
        'label'   => 'Custom Status',
        'type'    => 'select',
        'options' => ['pending_review' => 'Pending Review'],
    ];
    return $options;
});
```

---

### `{$filterName}_table_columns`
`fluent_cart/{$filterName}_table_columns` — Filter table columns for list pages (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving table column definitions for admin list pages.
* **Source:** `BaseFilter.php` (line 1038)

#### Parameters:
* `$columns` *(array)* — Table column definitions array (default: `[]`)
* **Returns:** *(array)* — The modified columns array

#### Usage Example:
```php
// Filter table column definitions for admin orders list view
add_filter('fluent_cart/orders_table_columns', function ($columns) {
    // Append custom field column definition to orders table
    $columns['custom_field'] = [
        'label'    => 'Custom Field',
        'sortable' => true,
        'width'    => '120px',
    ];
    return $columns;
});
```

---

### `advanced_filter_options_{$dataKey}`
`fluent_cart/advanced_filter_options_{$dataKey}` — Filter advanced filter options (DYNAMIC)

* **When it runs:** Dynamic filter applied when retrieving options for advanced filter UI.
* **Source:** `AdvanceFilterController.php` (line 46)

#### Parameters:
* `$options` *(array)* — Filter options array
* **Returns:** *(array)* — The modified options array

#### Usage Example:
```php
// Filter options array for advanced filter UI payment methods
add_filter('fluent_cart/advanced_filter_options_payment_methods', function ($options) {
    // Append custom gateway option to advanced filter UI
    $options[] = [
        'value' => 'custom_gateway',
        'label' => 'Custom Gateway',
    ];
    return $options;
});
```

---

## Plugin Installer

### `outside_addon/handle_cdn_install`
`fluent_cart/outside_addon/handle_cdn_install` — Filter CDN addon installation

* **When it runs:** Applied when attempting to install an addon from a CDN source. Return non-null value to handle installation manually.
* **Source:** `BackgroundInstaller.php` (line 143)

#### Parameters:
* `$result` *(mixed)* — Installation result (default: `null`)
* **Returns:** *(mixed)* — The installation result, or `null` for default handling

#### Usage Example:
```php
// Intercept addon installation from CDN external source
add_filter('fluent_cart/outside_addon/handle_cdn_install', function ($result) {
    // Handle custom CDN addon installation logic
    if ($result === null) {
        return ['success' => true, 'message' => 'Installed from custom CDN'];
    }
    return $result;
});
```

---

### `outside_addon/handle_install`
`fluent_cart/outside_addon/handle_install` — Filter external addon installation

* **When it runs:** Applied when installing an addon from an external source. Return non-null value to handle installation manually.
* **Source:** `BackgroundInstaller.php` (line 164)

#### Parameters:
* `$result` *(mixed)* — Installation result (default: `null`)
* **Returns:** *(mixed)* — The installation result, or `null` for default handling

#### Usage Example:
```php
// Intercept external addon installation process
add_filter('fluent_cart/outside_addon/handle_install', function ($result) {
    // Return success response payload for custom external addon installer
    return ['success' => true, 'message' => 'Addon installed successfully'];
});
```

---

## Pro: E-Invoicing

### `einvoice/buyer_vat_id` (Pro)
`fluent_cart/einvoice/buyer_vat_id` — Filter buyer VAT ID written to e-invoice

* **When it runs:** Applied in `En16931InvoiceMapper` while mapping order to EN 16931 e-invoice (BT-48) XML. Requires Pro plugin.
* **Source:** `fluent-cart-pro/.../En16931InvoiceMapper.php` (line 154)

#### Parameters:
* `$buyerVatId` *(string)* — Resolved buyer VAT identifier
* `$context` *(array)* — Context data (`['order' => Order]`)
* **Returns:** *(string)* — The buyer VAT identifier string to write

#### Usage Example:
```php
// Filter buyer VAT identification string written to EN 16931 e-invoice (Pro)
add_filter('fluent_cart/einvoice/buyer_vat_id', function ($buyerVatId, $context) {
    // Prepend billing country code prefix to buyer VAT ID if omitted
    $country = $context['order']->billing_address->country ?? '';
    if ($country && strpos($buyerVatId, $country) !== 0) {
        $buyerVatId = $country . $buyerVatId;
    }

    return $buyerVatId;
}, 10, 2);
```

---

### `einvoice/tax_category` (Pro)
`fluent_cart/einvoice/tax_category` — Filter EN 16931 VAT category for e-invoice line

* **When it runs:** Applied in `En16931InvoiceMapper` after resolving EN 16931 VAT category for invoice line or shipping charge. Requires Pro plugin.
* **Source:** `fluent-cart-pro/.../En16931InvoiceMapper.php` (line 357)

#### Parameters:
* `$resolved` *(array)* — Category data (`categoryCode`, `ratePercent`, `exemptionReasonCode`, `exemptionReasonText`)
* `$context` *(array)* — Context data (`['order' => Order, 'line' => LineItem|null]`)
* **Returns:** *(array)* — The modified VAT category data array

#### Usage Example:
```php
// Filter EN 16931 VAT tax category data for e-invoice line item (Pro)
add_filter('fluent_cart/einvoice/tax_category', function ($resolved, $context) {
    // Force exempt category E for target product line post ID 123
    if ($context['line'] && ($context['line']->post_id ?? 0) === 123) {
        $resolved['categoryCode']        = 'E';
        $resolved['ratePercent']         = 0.0;
        $resolved['exemptionReasonCode'] = 'VATEX-EU-O';
        $resolved['exemptionReasonText'] = 'Exempt supply';
    }

    return $resolved;
}, 10, 2);
```

---

## Pro: Licensing API

### `license/checking_error` (Pro)
`fluent_cart/license/checking_error` — Filter license check error response

* **When it runs:** Applied when license check encounters an error to customize error response payload. Requires Pro plugin.
* **Source:** `LicenseApiHandler.php` (lines 45, 56)

#### Parameters:
* `$error` *(array)* — Error response array
* **Returns:** *(array)* — Modified error response array

#### Usage Example:
```php
// Filter license verification error response array (Pro)
add_filter('fluent_cart/license/checking_error', function ($error) {
    // Override license check error message string
    $error['message'] = 'Please contact support for license verification.';
    return $error;
});
```

---

### `license/check_item_id` (Pro)
`fluent_cart/license/check_item_id` — Filter item ID validation during license check

* **When it runs:** Controls whether item ID should be validated during license check API request (default: `true`). Requires Pro plugin.
* **Source:** `LicenseApiHandler.php` (line 54)

#### Parameters:
* `$checkItemId` *(bool)* — Whether to check item ID
* **Returns:** *(bool)* — Modified boolean value

#### Usage Example:
```php
// Filter whether item ID is validated during license check API call (Pro)
add_filter('fluent_cart/license/check_item_id', function ($checkItemId) {
    // Skip item ID check during license check API request
    return false;
});
```

---

### `license/check_license_response` (Pro)
`fluent_cart/license/check_license_response` — Filter license check API response

* **When it runs:** Applied to license check API response before returning to client. Requires Pro plugin.
* **Source:** `LicenseApiHandler.php` (line 83)

#### Parameters:
* `$returnData` *(array)* — License check response data array
* **Returns:** *(array)* — Modified response data array

#### Usage Example:
```php
// Filter license check API response payload before returning to client (Pro)
add_filter('fluent_cart/license/check_license_response', function ($returnData) {
    // Append custom support URL string to license check API response
    $returnData['support_url'] = 'https://example.com/support';
    return $returnData;
});
```

---

### `license/activate_license_response` (Pro)
`fluent_cart/license/activate_license_response` — Filter license activation API response

* **When it runs:** Applied to license activation API response before returning to client. Requires Pro plugin.
* **Source:** `LicenseApiHandler.php` (lines 170, 274)

#### Parameters:
* `$returnData` *(array)* — Activation response data array
* **Returns:** *(array)* — Modified response data array

#### Usage Example:
```php
// Filter license activation API response payload (Pro)
add_filter('fluent_cart/license/activate_license_response', function ($returnData) {
    // Append activated_at timestamp string to license activation response
    $returnData['activated_at'] = gmdate('Y-m-d H:i:s');
    return $returnData;
});
```

---

### `license/deactivate_license_response` (Pro)
`fluent_cart/license/deactivate_license_response` — Filter license deactivation API response

* **When it runs:** Applied to license deactivation API response before returning to client. Requires Pro plugin.
* **Source:** `LicenseApiHandler.php` (line 356)

#### Parameters:
* `$returnData` *(array)* — Deactivation response data array
* **Returns:** *(array)* — Modified response data array

#### Usage Example:
```php
// Filter license deactivation API response payload (Pro)
add_filter('fluent_cart/license/deactivate_license_response', function ($returnData) {
    // Append deactivation notice text string to response
    $returnData['notice'] = 'License deactivated. You can reactivate on another site.';
    return $returnData;
});
```

---

### `license/get_version_response` (Pro)
`fluent_cart/license/get_version_response` — Filter version check API response

* **When it runs:** Applied to version check API response to modify changelog or update information. Requires Pro plugin.
* **Source:** `LicenseApiHandler.php` (line 463)

#### Parameters:
* `$changeLogData` *(array)* — Version and changelog response data array
* **Returns:** *(array)* — Modified response data array

#### Usage Example:
```php
// Filter software update version check API response payload (Pro)
add_filter('fluent_cart/license/get_version_response', function ($changeLogData) {
    // Append custom patch entry string to changelog section
    $changeLogData['sections']['changelog'] .= "\n* Custom patch applied";
    return $changeLogData;
});
```

---

### `license/santized_url` (Pro)
`fluent_cart/license/santized_url` — Filter sanitized URL for license validation

* **When it runs:** Applied when sanitizing site URL during license activation or validation. Requires Pro plugin.
* **Source:** `LicenseHelper.php` (line 36)

#### Parameters:
* `$url` *(string)* — Sanitized URL string
* `$originalUrl` *(string)* — Original URL before sanitization
* **Returns:** *(string)* — Modified sanitized URL string

#### Usage Example:
```php
// Filter sanitized URL string used during license validation (Pro)
add_filter('fluent_cart/license/santized_url', function ($url, $originalUrl) {
    // Strip www subdomain prefix from sanitized site URL
    return str_replace('://www.', '://', $url);
}, 10, 2);
```

---

## Pro: License Validation & Staging

### `fluent_cart_sl/is_local_site` (Pro)
`fluent_cart_sl/is_local_site` — Filter local/staging site detection

* **When it runs:** Applied when determining if current site is local or staging for licensing purposes. Requires Pro plugin.
* **Source:** `fluent-cart-pro/.../LicenseSite.php` (line 69)

#### Parameters:
* `$isLocal` *(bool)* — Whether site is detected as local
* `$context` *(array)* — Context data (`['url' => string, 'site' => string]`)
* **Returns:** *(bool)* — Modified detection result boolean

#### Usage Example:
```php
// Filter local or staging site detection boolean for licensing (Pro)
add_filter('fluent_cart_sl/is_local_site', function ($isLocal, $context) {
    // Mark URLs containing .staging. as local staging sites
    if (str_contains($context['url'], '.staging.')) {
        return true;
    }
    return $isLocal;
}, 10, 2);
```

---

### `license/staging_subdomain_patterns` (Pro)
`fluent_cart/license/staging_subdomain_patterns` — Filter staging subdomain patterns

* **When it runs:** Applied when checking if URL matches known staging subdomain patterns. Requires Pro plugin.
* **Source:** `LicenseHelper.php` (line 619)

#### Parameters:
* `$patterns` *(array)* — Array of subdomain patterns indicating staging sites
* **Returns:** *(array)* — Modified patterns array

#### Usage Example:
```php
// Filter staging subdomain regex patterns array for licensing (Pro)
add_filter('fluent_cart/license/staging_subdomain_patterns', function ($patterns) {
    // Append dev- and test- subdomain prefixes to staging patterns list
    $patterns[] = 'dev-';
    $patterns[] = 'test-';
    return $patterns;
});
```

---

### `license/staging_subfolder_patterns` (Pro)
`fluent_cart/license/staging_subfolder_patterns` — Filter staging subfolder patterns

* **When it runs:** Applied when checking if URL matches known staging subfolder patterns. Requires Pro plugin.
* **Source:** `LicenseHelper.php` (line 620)

#### Parameters:
* `$patterns` *(array)* — Array of subfolder patterns indicating staging sites
* **Returns:** *(array)* — Modified patterns array

#### Usage Example:
```php
// Filter staging subfolder path patterns array for licensing (Pro)
add_filter('fluent_cart/license/staging_subfolder_patterns', function ($patterns) {
    // Append /staging/ and /test-site/ subfolders to staging patterns
    $patterns[] = '/staging/';
    $patterns[] = '/test-site/';
    return $patterns;
});
```

---

### `license/staging_domains` (Pro)
`fluent_cart/license/staging_domains` — Filter hosting provider staging domains

* **When it runs:** Applied when checking if URL belongs to known hosting provider staging domain. Requires Pro plugin.
* **Source:** `LicenseHelper.php` (line 621)

#### Parameters:
* `$domains` *(array)* — Array of hosting provider staging domain patterns
* **Returns:** *(array)* — Modified domains array

#### Usage Example:
```php
// Filter hosting provider staging domain patterns array (Pro)
add_filter('fluent_cart/license/staging_domains', function ($domains) {
    // Append custom hosting provider staging domain patterns
    $domains[] = 'mystaginghost.com';
    $domains[] = 'preview.myhost.io';
    return $domains;
});
```

---

### `license/is_staging_site_result` (Pro)
`fluent_cart/license/is_staging_site_result` — Filter final staging site detection result

* **When it runs:** Applied after all staging detection checks to provide final boolean result (default: `false`). Requires Pro plugin.
* **Source:** `LicenseHelper.php` (line 657)

#### Parameters:
* `$isStaging` *(bool)* — Whether site is detected as staging
* `$url` *(string)* — Site URL being checked
* **Returns:** *(bool)* — Modified staging detection result

#### Usage Example:
```php
// Filter final staging site detection boolean result (Pro)
add_filter('fluent_cart/license/is_staging_site_result', function ($isStaging, $url) {
    // Override staging detection for specific target domain string
    if (str_contains($url, 'mycompany-staging.com')) {
        return true;
    }
    return $isStaging;
}, 10, 2);
```

---

## Pro: License Configuration

### `license/validity_by_variation` (Pro)
`fluent_cart/license/validity_by_variation` — Filter license validity per variation

* **When it runs:** Applied when determining license validity settings for a specific product variation. Requires Pro plugin.
* **Source:** `ProductLicenseController.php` (line 74)

#### Parameters:
* `$validity` *(array)* — Validity settings array (`duration`, `unit`)
* `$context` *(array)* — Context data (`['variation' => ProductVariation]`)
* **Returns:** *(array)* — The modified validity settings array

#### Usage Example:
```php
// Filter license validity settings per product variation (Pro)
add_filter('fluent_cart/license/validity_by_variation', function ($validity, $context) {
    // Apply 365-day license validity for premium variation slug
    $variation = $context['variation'];
    if ($variation->slug === 'premium') {
        $validity['duration'] = 365;
        $validity['unit']     = 'days';
    }
    return $validity;
}, 10, 2);
```

---

# Filter Hooks: Orders & Payments

All filters related to Order lifecycle, payment processing, gateway integrations, and taxes.

---

## Order Statuses

### `order_statuses`
`fluent_cart/order_statuses` — Filter available order statuses

* **When it runs:** Applied when retrieving the list of available order statuses throughout the admin and storefront.
* **Source:** `app/Helpers/Status.php` (line 159)

#### Parameters:
* `$statuses` *(array)* — Associative array of order statuses (`'processing' => 'Processing'`, `'completed' => 'Completed'`, etc.)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified order statuses array

#### Usage Example:
```php
// Filter available order statuses array in FluentCart
add_filter('fluent_cart/order_statuses', function ($statuses, $data) {
    // Add custom "Awaiting Pickup" order status
    $statuses['awaiting_pickup'] = __('Awaiting Pickup', 'my-plugin');
    return $statuses;
}, 10, 2);
```

---

### `order_statuses` (legacy)
`fluent-cart/order_statuses` — Filter order statuses (legacy hook name)

* **When it runs:** Legacy location of the order statuses filter. Applied in the older Helper class. Prefer `fluent_cart/order_statuses` for new code.
* **Source:** `app/Helpers/Helper.php` (line 140)

#### Parameters:
* `$statuses` *(array)* — Associative array of order statuses
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified order statuses array

#### Usage Example:
```php
// Filter order statuses using legacy hyphenated hook name
add_filter('fluent-cart/order_statuses', function ($statuses, $data) {
    // Add custom status to legacy order statuses array
    $statuses['custom'] = __('Custom Status', 'my-plugin');
    return $statuses;
}, 10, 2);
```

---

### `editable_order_statuses`
`fluent-cart/editable_order_statuses` — Filter manually settable order statuses

* **When it runs:** Applied when building the list of order statuses an admin can manually set on an order. This controls the dropdown options in the order edit screen. Note the hyphenated prefix (`fluent-cart/`).
* **Source:** `app/Helpers/Helper.php` (line 151), `app/Helpers/Status.php` (lines 170, 242)

#### Parameters:
* `$statuses` *(array)* — Associative array of editable statuses (`on-hold`, `processing`, `completed`, `canceled`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified editable order statuses array

#### Usage Example:
```php
// Filter manually editable order statuses for admin dropdown
add_filter('fluent-cart/editable_order_statuses', function ($statuses, $data) {
    // Remove "canceled" status from manually selectable options
    unset($statuses['canceled']);
    return $statuses;
}, 10, 2);
```

---

### `payment_statuses`
`fluent_cart/payment_statuses` — Filter payment statuses

* **When it runs:** Applied when retrieving the list of available payment statuses used across the order and transaction system.
* **Source:** `app/Helpers/Status.php` (line 183)

#### Parameters:
* `$statuses` *(array)* — Associative array of payment statuses (`pending`, `paid`, `partially_paid`, `failed`, `refunded`, `partially_refunded`, `authorized`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified payment statuses array

#### Usage Example:
```php
// Filter available payment statuses across order and transaction systems
add_filter('fluent_cart/payment_statuses', function ($statuses, $data) {
    // Add custom "On Hold" payment status
    $statuses['on_hold'] = __('On Hold', 'my-plugin');
    return $statuses;
}, 10, 2);
```

---

### `transaction_statuses`
`fluent_cart/transaction_statuses` — Filter transaction statuses

* **When it runs:** Applied when retrieving available transaction statuses for the primary transaction system.
* **Source:** `app/Helpers/Status.php` (line 197)

#### Parameters:
* `$statuses` *(array)* — Associative array of transaction statuses (`pending`, `succeeded`, `authorized`, `failed`, `refunded`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified transaction statuses array

#### Usage Example:
```php
// Filter primary transaction system statuses array
add_filter('fluent_cart/transaction_statuses', function ($statuses, $data) {
    // Add custom "Disputed" transaction status
    $statuses['disputed'] = __('Disputed', 'my-plugin');
    return $statuses;
}, 10, 2);
```

---

### `transaction_statuses` (legacy)
`fluent-cart/transaction_statuses` — Filter transaction statuses (legacy hook name)

* **When it runs:** Legacy location of the transaction statuses filter. Applied in the older Helper class. Prefer `fluent_cart/transaction_statuses` for new code.
* **Source:** `app/Helpers/Helper.php` (line 215)

#### Parameters:
* `$statuses` *(array)* — Associative array of transaction statuses
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified transaction statuses array

#### Usage Example:
```php
// Filter transaction statuses using legacy hyphenated hook name
add_filter('fluent-cart/transaction_statuses', function ($statuses, $data) {
    // Return modified transaction statuses array
    return $statuses;
}, 10, 2);
```

---

### `editable_transaction_statuses`
`fluent-cart/editable_transaction_statuses` — Filter manually editable transaction statuses

* **When it runs:** Applied when building the list of transaction statuses that an admin can manually set. Note the hyphenated prefix (`fluent-cart/`).
* **Source:** `app/Helpers/Helper.php` (line 233), `app/Helpers/Status.php` (line 214)

#### Parameters:
* `$statuses` *(array)* — Associative array of editable transaction statuses
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified editable transaction statuses array

#### Usage Example:
```php
// Filter manually editable transaction statuses for admin dropdown
add_filter('fluent-cart/editable_transaction_statuses', function ($statuses, $data) {
    // Remove "refunded" status from manually selectable transaction statuses
    unset($statuses['refunded']);
    return $statuses;
}, 10, 2);
```

---

### `transaction_success_statuses`
`fluent_cart/transaction_success_statuses` — Filter which statuses count as successful transactions

* **When it runs:** Applied when determining which transaction statuses should be considered "successful" for reporting and order completion logic.
* **Source:** `app/Helpers/Status.php` (line 331)

#### Parameters:
* `$statuses` *(array)* — Indexed array of status strings (default: `['succeeded', 'authorized']`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified success statuses array

#### Usage Example:
```php
// Filter which transaction statuses count as successful for reports
add_filter('fluent_cart/transaction_success_statuses', function ($statuses, $data) {
    // Add "captured" to list of successful transaction statuses
    $statuses[] = 'captured';
    return $statuses;
}, 10, 2);
```

---

### `shipping_statuses` (legacy)
`fluent-cart/shipping_statuses` — Filter shipping statuses (legacy hook name)

* **When it runs:** Legacy location of the shipping statuses filter. Prefer `fluent_cart/shipping_statuses` for new code.
* **Source:** `app/Helpers/Helper.php` (line 170)

#### Parameters:
* `$statuses` *(array)* — Associative array of shipping statuses
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified shipping statuses array

#### Usage Example:
```php
// Filter shipping statuses using legacy hyphenated hook name
add_filter('fluent-cart/shipping_statuses', function ($statuses, $data) {
    // Return shipping statuses array
    return $statuses;
}, 10, 2);
```

---

### `shipping_statuses`
`fluent_cart/shipping_statuses` — Filter shipping statuses

* **When it runs:** Applied when retrieving the list of available shipping statuses used for order fulfillment.
* **Source:** `app/Helpers/Status.php` (line 232)

#### Parameters:
* `$statuses` *(array)* — Associative array of shipping statuses (`unshipped`, `shipped`, `delivered`, `unshippable`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified shipping statuses array

#### Usage Example:
```php
// Filter available shipping statuses for order fulfillment
add_filter('fluent_cart/shipping_statuses', function ($statuses, $data) {
    // Add custom "In Transit" shipping status
    $statuses['in_transit'] = __('In Transit', 'my-plugin');
    return $statuses;
}, 10, 2);
```

---

## Order Data & Lifecycle

### `orders_list`
`fluent_cart/orders_list` — Filter the admin orders list

* **When it runs:** Applied after retrieving the paginated orders collection for the admin orders list view.
* **Source:** `app/Http/Controllers/OrderController.php` (line 58)

#### Parameters:
* `$orders` *(\FluentCart\Framework\Database\Orm\LengthAwarePaginator)* — Paginated collection of orders
* **Returns:** *(\FluentCart\Framework\Database\Orm\LengthAwarePaginator)* — The modified paginated orders collection

#### Usage Example:
```php
// Filter paginated orders collection for admin list view
add_filter('fluent_cart/orders_list', function ($orders) {
    // Loop through orders and inject custom badge post meta
    foreach ($orders as $order) {
        $order->custom_badge = get_post_meta($order->id, '_custom_badge', true);
    }
    return $orders;
}, 10, 1);
```

---

### `order/view`
`fluent_cart/order/view` — Filter single order view data

* **When it runs:** Applied when preparing the data for a single order view in the admin panel.
* **Source:** `app/Http/Controllers/OrderController.php` (line 580)

#### Parameters:
* `$order` *(array)* — The order data array containing all order details
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified order data

#### Usage Example:
```php
// Filter single order view data structure in admin panel
add_filter('fluent_cart/order/view', function ($order, $data) {
    // Inject custom field key into order view data payload
    $order['custom_field'] = 'Custom Value';
    return $order;
}, 10, 2);
```

---

### `widgets/single_order`
`fluent_cart/widgets/single_order` — Filter single order admin widgets

* **When it runs:** Applied when loading the stats/widgets section on the single order admin view.
* **Source:** `app/Http/Controllers/OrderController.php` (line 1009)

#### Parameters:
* `$widgets` *(array)* — Array of widget data (default empty)
* `$order` *(\FluentCart\App\Models\Order)* — The Order model instance
* **Returns:** *(array)* — Array of widget definitions to display

#### Usage Example:
```php
// Filter admin widgets loaded on single order view page
add_filter('fluent_cart/widgets/single_order', function ($widgets, $order) {
    // Append custom widget array definition for single order
    $widgets[] = [
        'title' => __('Custom Widget', 'my-plugin'),
        'value' => 'Some data for order #' . $order->id,
    ];
    return $widgets;
}, 10, 2);
```

---

### `order/is_subscription_allowed_in_manual_order`
`fluent_cart/order/is_subscription_allowed_in_manual_order` — Allow subscriptions in manual orders

* **When it runs:** Applied when creating a manual order that contains subscription items. By default, subscriptions in manual orders are not supported.
* **Source:** `app/Http/Controllers/OrderController.php` (line 78)

#### Parameters:
* `$allowed` *(bool)* — Whether subscriptions are allowed (default: `false`)
* `$context` *(array)* — Context data (`['order_items' => [...]]`)
* **Returns:** *(bool)* — Whether to allow subscription items in manual orders

#### Usage Example:
```php
// Filter whether subscriptions are allowed in manual order creation
add_filter('fluent_cart/order/is_subscription_allowed_in_manual_order', function ($allowed, $context) {
    // Enable subscription items in manual orders
    return true;
}, 10, 2);
```

---

### `order/type`
`fluent_cart/order/type` — Filter order type during manual creation

* **When it runs:** Applied when determining the order type during manual order creation. Automatically set to `'subscription'` if subscription items are detected, otherwise `'payment'`.
* **Source:** `app/Http/Controllers/OrderController.php` (line 91)

#### Parameters:
* `$type` *(string)* — The order type (`'payment'` or `'subscription'`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(string)* — The order type string

#### Usage Example:
```php
// Filter order type classification during manual order creation
add_filter('fluent_cart/order/type', function ($type, $data) {
    // Return order type string ('payment' or 'subscription')
    return $type;
}, 10, 2);
```

---

### `order/expected_license_count`
`fluent_cart/order/expected_license_count` — Filter expected license count for an order

* **When it runs:** Applied when checking how many licenses should exist for an order. Used to detect missing licenses that need to be regenerated.
* **Source:** `app/Http/Controllers/OrderController.php` (lines 215, 585)

#### Parameters:
* `$count` *(int)* — Expected number of licenses (default: `0`)
* `$context` *(array)* — Context data (`['order_items' => [...]]`)
* **Returns:** *(int)* — The expected number of licenses

#### Usage Example:
```php
// Filter expected license count to detect missing licenses for order
add_filter('fluent_cart/order/expected_license_count', function ($count, $context) {
    // Calculate expected license count based on order item requirements
    foreach ($context['order_items'] as $item) {
        if ($item->requires_license) {
            $count += $item->quantity;
        }
    }
    return $count;
}, 10, 2);
```

---

### `create_receipt_number_on_order_create`
`fluent_cart/create_receipt_number_on_order_create` — Force receipt number generation on order creation

* **When it runs:** Applied during the order creating model event. By default, receipt numbers are only generated when the payment status is `'paid'`. Return true to always generate a receipt number.
* **Source:** `app/Models/Order.php` (line 52)

#### Parameters:
* `$force` *(bool)* — Whether to force receipt number creation (default: `false`)
* **Returns:** *(bool)* — Whether to generate a receipt number regardless of payment status

#### Usage Example:
```php
// Filter whether to force receipt number creation when order is created
add_filter('fluent_cart/create_receipt_number_on_order_create', function ($force) {
    // Always generate receipt number upon order creation regardless of payment status
    return true;
}, 10, 1);
```

---

### `single_order_downloads`
`fluent_cart/single_order_downloads` — Filter order downloads data

* **When it runs:** Applied when preparing the downloadable files for a specific order, allowing you to add, remove, or modify download data.
* **Source:** `app/Models/Order.php` (line 657)

#### Parameters:
* `$downloadData` *(array)* — Array of download groups (`title`, `product_id`, `downloads`, etc.)
* `$context` *(array)* — Context data (`['order' => Order, 'scope' => 'admin'|'customer']`)
* **Returns:** *(array)* — The modified download data array

#### Usage Example:
```php
// Filter downloadable files data array for a specific order
add_filter('fluent_cart/single_order_downloads', function ($downloadData, $context) {
    // Add bonus download file for completed orders
    if ($context['order']->status === 'completed') {
        $downloadData[] = [
            'title'     => 'Bonus Content',
            'downloads' => [
                ['name' => 'Bonus File', 'url' => 'https://example.com/bonus.pdf']
            ]
        ];
    }
    return $downloadData;
}, 10, 2);
```

---

### `order_can_be_deleted`
`fluent_cart/order_can_be_deleted` — Filter whether an order can be deleted

* **When it runs:** Applied when checking if an order is eligible for deletion. By default, orders with active subscriptions cannot be deleted.
* **Source:** `app/Models/Order.php` (line 812)

#### Parameters:
* `$canBeDeleted` *(true|\WP_Error)* — `true` if deletable, or a `WP_Error` with the reason
* `$context` *(array)* — Context data (`['order' => Order]`)
* **Returns:** *(true|\WP_Error)* — `true` to allow deletion, or `WP_Error` to block it

#### Usage Example:
```php
// Filter whether an order is eligible for deletion
add_filter('fluent_cart/order_can_be_deleted', function ($canBeDeleted, $context) {
    // Extract order model from context
    $order = $context['order'];
    // Prevent deletion of orders created within the last 30 days
    if (strtotime($order->created_at) > strtotime('-30 days')) {
        return new \WP_Error('too_recent', __('Orders less than 30 days old cannot be deleted.', 'my-plugin'));
    }
    return $canBeDeleted;
}, 10, 2);
```

---

### `min_receipt_number`
`fluent_cart/min_receipt_number` — Filter the minimum receipt number

* **When it runs:** Applied when calculating the next receipt number. If the computed next number is below this minimum, it will be bumped up.
* **Source:** `app/Services/OrderService.php` (line 572)

#### Parameters:
* `$min` *(int)* — The minimum receipt number from store settings (default: `1`)
* **Returns:** *(int)* — The minimum receipt number to enforce

#### Usage Example:
```php
// Filter minimum receipt number value
add_filter('fluent_cart/min_receipt_number', function ($min) {
    // Enforce starting receipt number of 1000
    return 1000;
}, 10, 1);
```

---

### `invoice_prefix`
`fluent_cart/invoice_prefix` — Filter the invoice number prefix

* **When it runs:** Applied when generating the invoice number string for new orders. Formed as `prefix + receipt_number`.
* **Source:** `app/Services/OrderService.php` (line 584)

#### Parameters:
* `$prefix` *(string)* — The invoice prefix from store settings (default: `'INV-'`)
* **Returns:** *(string)* — The modified invoice prefix

#### Usage Example:
```php
// Filter invoice number prefix string
add_filter('fluent_cart/invoice_prefix', function ($prefix) {
    // Use dynamic year-based invoice prefix string
    return 'INV-' . date('Y') . '-';
}, 10, 1);
```

---

### `order_refund_manually`
`fluent_cart/order_refund_manually` — Intercept manual refund processing

* **When it runs:** Applied during the refund process before the payment gateway refund method is called. Allows you to handle refunds through a custom mechanism instead of the gateway.
* **Source:** `app/Services/Payments/Refund.php` (line 65)

#### Parameters:
* `$manualRefund` *(array)* — Manual refund status (`['status' => 'no', 'source' => '']`)
* `$context` *(array)* — Refund context (`['refund_amount' => 5000, 'transaction' => Transaction, 'order' => Order, 'args' => [...]]`)
* **Returns:** *(array)* — Array with `'status'` key set to `'yes'` to skip the gateway refund

#### Usage Example:
```php
// Intercept manual refund processing before payment gateway invocation
add_filter('fluent_cart/order_refund_manually', function ($manualRefund, $context) {
    // Process refund via custom refund service logic
    $result = my_custom_refund($context['transaction'], $context['refund_amount']);
    if ($result) {
        return ['status' => 'yes', 'source' => 'my_custom_service'];
    }
    return $manualRefund;
}, 10, 2);
```

---

### `order_status/auto_complete_digital_order`
`fluent_cart/order_status/auto_complete_digital_order` — Control auto-completion of digital orders

* **When it runs:** Applied during payment status reconciliation. When a digital (non-physical) order is paid, it is automatically marked as completed. Return false to prevent this behavior.
* **Source:** `app/Helpers/StatusHelper.php` (line 193)

#### Parameters:
* `$autoComplete` *(bool)* — Whether to auto-complete the order (default: `true`)
* `$context` *(array)* — Context data (`['order' => Order]`)
* **Returns:** *(bool)* — Whether to automatically complete the digital order

#### Usage Example:
```php
// Control auto-completion behavior for digital product orders
add_filter('fluent_cart/order_status/auto_complete_digital_order', function ($autoComplete, $context) {
    // Require manual review for high-value digital orders over $500
    if ($context['order']->total > 50000) {
        return false;
    }
    return $autoComplete;
}, 10, 2);
```

---

### `customer/order_data`
`fluent_cart/customer/order_data` — Filter customer portal order data

* **When it runs:** Applied when preparing order data for display in the customer-facing order details page.
* **Source:** `app/Http/Controllers/FrontendControllers/CustomerOrderController.php` (line 285)

#### Parameters:
* `$formattedOrderData` *(array)* — The formatted order data array
* `$context` *(array)* — Context data (`['order' => Order, 'customer' => Customer]`)
* **Returns:** *(array)* — The modified formatted order data

#### Usage Example:
```php
// Filter formatted order data array in customer portal order details view
add_filter('fluent_cart/customer/order_data', function ($formattedOrderData, $context) {
    // Inject estimated delivery date meta into customer order details
    $formattedOrderData['estimated_delivery'] = get_post_meta(
        $context['order']->id, '_estimated_delivery', true
    );
    return $formattedOrderData;
}, 10, 2);
```

---

### `customer/order_details_section_parts`
`fluent_cart/customer/order_details_section_parts` — Filter customer order detail sections

* **When it runs:** Applied when building the customer-facing order details page. Allows you to inject custom HTML content into predefined section slots.
* **Source:** `app/Http/Controllers/FrontendControllers/CustomerOrderController.php` (line 292)

#### Parameters:
* `$sections` *(array)* — HTML content for section slots (`before_summary`, `after_summary`, `after_licenses`, `after_subscriptions`, `after_downloads`, `after_transactions`, `end_of_order`)
* `$context` *(array)* — Context data (`['order' => Order, 'formattedData' => [...]]`)
* **Returns:** *(array)* — The modified sections array with HTML content

#### Usage Example:
```php
// Filter customer order detail section HTML parts
add_filter('fluent_cart/customer/order_details_section_parts', function ($sections, $context) {
    // Inject custom HTML notice after order summary section
    $sections['after_summary'] = '<div class="custom-notice">Thank you for your order!</div>';
    return $sections;
}, 10, 2);
```

---

## Payment Processing

### `ipn_url_{$slug}`
`fluent_cart_ipn_url_{$slug}` — Filter IPN/webhook listener URL for a payment gateway

* **When it runs:** Applied when generating the IPN or webhook listener URL for a specific payment method. The `{$slug}` is the gateway slug (e.g. `stripe`, `paypal`).
* **Source:** `app/Services/Payments/PaymentHelper.php` (line 24)

#### Parameters:
* `$urlData` *(array)* — Array containing the listener URL (`['listener_url' => '...']`)
* **Returns:** *(array)* — The modified URL data array

#### Usage Example:
```php
// Filter IPN / webhook listener URL for Stripe gateway
add_action('fluent_cart_ipn_url_stripe', function ($urlData) {
    // Set custom endpoint URL for Stripe webhooks
    $urlData['listener_url'] = home_url('/custom-stripe-webhook/');
    return $urlData;
}, 10, 1);
```

---

### `payment/success_url`
`fluentcart/payment/success_url` — Filter the payment success redirect URL

* **When it runs:** Applied when generating the URL the customer is redirected to after a successful payment. Note the legacy prefix (`fluentcart/`).
* **Source:** `app/Services/Payments/PaymentHelper.php` (line 46)

#### Parameters:
* `$url` *(string)* — The success redirect URL (receipt page with query args)
* `$context` *(array)* — Context data (`['transaction_hash' => '...', 'args' => [], 'payment_method' => 'stripe']`)
* **Returns:** *(string)* — The modified success URL

#### Usage Example:
```php
// Filter payment success redirect URL (legacy hook prefix)
add_filter('fluentcart/payment/success_url', function ($url, $context) {
    // Redirect customer to custom thank-you page with transaction hash
    return add_query_arg('trx_hash', $context['transaction_hash'], home_url('/thank-you/'));
}, 10, 2);
```

---

### `default_payment_method_for_zero_payment`
`fluent_cart/default_payment_method_for_zero_payment` — Filter default payment method for zero-total orders

* **When it runs:** Applied during checkout validation when the order total (including recurring) is zero. Determines which payment method handles the $0 transaction.
* **Source:** `app/Services/Payments/PaymentHelper.php` (line 70)

#### Parameters:
* `$method` *(string)* — Payment method slug (default: `'offline_payment'`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(string)* — The payment method slug to use for zero-total orders

#### Usage Example:
```php
// Filter default payment method slug for zero-total orders
add_filter('fluent_cart/default_payment_method_for_zero_payment', function ($method, $data) {
    // Use Stripe for zero-total orders with recurring subscriptions
    return 'stripe';
}, 10, 2);
```

---

### `get_payment_connect_info_{$method}`
`fluent_cart/get_payment_connect_info_{$method}` — Filter payment method connection info

* **When it runs:** Applied when retrieving connection/setup information for a specific payment method. The `{$method}` is the sanitized gateway slug. Used by gateways that require an OAuth connection flow.
* **Source:** `api/PaymentMethods.php` (line 105)

#### Parameters:
* `$info` *(array)* — Connection info array (default: `[]`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The payment method connection information

#### Usage Example:
```php
// Filter payment method OAuth connect information for Stripe
add_filter('fluent_cart/get_payment_connect_info_stripe', function ($info, $data) {
    // Set connected status and Stripe account ID
    $info['connected'] = true;
    $info['account_id'] = 'acct_xxx';
    return $info;
}, 10, 2);
```

---

### `transaction/url_{$payment_method}`
`fluent_cart/transaction/url_{$payment_method}` — Filter vendor dashboard URL for a transaction

* **When it runs:** Applied when generating the URL attribute of an `OrderTransaction` model. The `{$payment_method}` is the gateway slug. Links to the transaction in the provider dashboard.
* **Source:** `app/Models/OrderTransaction.php` (line 111)

#### Parameters:
* `$url` *(string)* — The vendor URL (default: `''`)
* `$context` *(array)* — Context data (`['transaction' => Transaction, 'payment_mode' => 'live'|'test', 'vendor_charge_id' => 'ch_xxx', 'transaction_type' => 'charge']`)
* **Returns:** *(string)* — The URL to the transaction in the payment provider dashboard

#### Usage Example:
```php
// Filter vendor dashboard URL attribute for Stripe transactions
add_filter('fluent_cart/transaction/url_stripe', function ($url, $context) {
    // Extract vendor charge ID and mode
    $chargeId = $context['vendor_charge_id'];
    $mode = $context['payment_mode'] === 'test' ? 'test/' : '';

    // Construct Stripe dashboard transaction URL
    return "https://dashboard.example.com/{$mode}payments/{$chargeId}";
}, 10, 2);
```

---

### `transaction/receipt_page_url`
`fluentcart/transaction/receipt_page_url` — Filter the transaction receipt page URL

* **When it runs:** Applied when generating the public-facing receipt page URL for a transaction. Note legacy prefix (`fluentcart/`).
* **Source:** `app/Models/OrderTransaction.php` (line 183)

#### Parameters:
* `$url` *(string)* — The receipt page URL with `trx_hash` query parameter
* `$context` *(array)* — Context data (`['transaction' => Transaction, 'order' => Order]`)
* **Returns:** *(string)* — The modified receipt page URL

#### Usage Example:
```php
// Filter public receipt page URL for transaction (legacy hook prefix)
add_filter('fluentcart/transaction/receipt_page_url', function ($url, $context) {
    // Use custom public receipt page URL with transaction hash
    return add_query_arg('trx_hash', $context['transaction']->uuid, home_url('/my-receipt/'));
}, 10, 2);
```

---

## Stripe

### `stripe_settings`
`fluent_cart/stripe_settings` — Filter Stripe gateway settings

* **When it runs:** Applied when loading Stripe gateway settings during initialization.
* **Source:** `app/Modules/PaymentMethods/StripeGateway/StripeSettingsBase.php` (line 38)

#### Parameters:
* `$settings` *(array)* — The Stripe settings array including keys, modes, and configuration options
* **Returns:** *(array)* — The modified Stripe settings

#### Usage Example:
```php
// Filter Stripe gateway settings array during initialization
add_filter('fluent_cart/stripe_settings', function ($settings) {
    // Force test mode in staging environment
    if (wp_get_environment_type() === 'staging') {
        $settings['payment_mode'] = 'test';
    }
    return $settings;
}, 10, 1);
```

---

### `payments/stripe_metadata_subscription`
`fluent_cart/payments/stripe_metadata_subscription` — Filter Stripe subscription metadata

* **When it runs:** Applied when creating a Stripe subscription, allowing you to add or modify metadata sent to Stripe's subscription object. Max 50 keys per Stripe API limits.
* **Source:** `app/Modules/PaymentMethods/StripeGateway/Processor.php` (line 90)

#### Parameters:
* `$metadata` *(array)* — Metadata array for Stripe subscription (`fct_ref_id`, `email`, `name`, `subscription_item`, `order_reference`)
* `$context` *(array)* — Context data (`['order' => Order, 'transaction' => Transaction, 'subscription' => Subscription]`)
* **Returns:** *(array)* — The modified metadata array

#### Usage Example:
```php
// Filter Stripe subscription metadata array
add_filter('fluent_cart/payments/stripe_metadata_subscription', function ($metadata, $context) {
    // Inject custom affiliate ID into Stripe subscription metadata
    $metadata['affiliate_id'] = get_user_meta($context['order']->customer->user_id, 'affiliate_id', true);
    return $metadata;
}, 10, 2);
```

---

### `payments/stripe_metadata_onetime`
`fluent_cart/payments/stripe_metadata_onetime` — Filter Stripe one-time payment metadata

* **When it runs:** Applied when creating a Stripe payment intent for a one-time payment. Max 50 keys per Stripe API limits.
* **Source:** `app/Modules/PaymentMethods/StripeGateway/Processor.php` (line 221)

#### Parameters:
* `$metadata` *(array)* — Metadata array for Stripe payment intent (`fct_ref_id`, `Name`, `Email`, `order_reference`)
* `$context` *(array)* — Context data (`['order' => Order, 'transaction' => Transaction]`)
* **Returns:** *(array)* — The modified metadata array

#### Usage Example:
```php
// Filter Stripe one-time payment intent metadata array
add_filter('fluent_cart/payments/stripe_metadata_onetime', function ($metadata, $context) {
    // Inject campaign tag and customer ID into metadata
    $metadata['campaign'] = 'spring_sale_2025';
    if (isset($context['order'])) {
        $metadata['customer_id'] = $context['order']->customer_id;
    }
    return $metadata;
}, 10, 2);
```

---

### `payments/stripe_onetime_intent_args`
`fluent_cart/payments/stripe_onetime_intent_args` — Filter Stripe payment intent arguments

* **When it runs:** Applied after building the full payment intent data array, just before creating the intent via the Stripe API.
* **Source:** `app/Modules/PaymentMethods/StripeGateway/Processor.php` (line 257)

#### Parameters:
* `$intentData` *(array)* — Payment intent arguments (`amount`, `currency`, `automatic_payment_methods`, `metadata`, `customer`)
* `$context` *(array)* — Context data (`['order' => Order, 'transaction' => Transaction]`)
* **Returns:** *(array)* — The modified payment intent arguments

#### Usage Example:
```php
// Filter Stripe payment intent arguments for one-time payments
add_filter('fluent_cart/payments/stripe_onetime_intent_args', function ($intentData, $context) {
    // Add custom statement descriptor suffix for order
    $intentData['statement_descriptor_suffix'] = 'Order ' . $context['order']->id;
    return $intentData;
}, 10, 2);
```

---

### `payments/stripe_checkout_session_args`
`fluent_cart/payments/stripe_checkout_session_args` — Filter Stripe Checkout session arguments (one-time)

* **When it runs:** Applied when creating a Stripe Checkout session for one-time hosted payments.
* **Source:** `app/Modules/PaymentMethods/StripeGateway/Processor.php` (line 356)

#### Parameters:
* `$sessionData` *(array)* — Checkout session arguments (`customer`, `client_reference_id`, `line_items`, `mode`, `success_url`, `cancel_url`, `metadata`)
* `$context` *(array)* — Context data (`['order' => Order, 'transaction' => Transaction]`)
* **Returns:** *(array)* — The modified Checkout session arguments

#### Usage Example:
```php
// Filter Stripe Checkout session arguments for one-time payments
add_filter('fluent_cart/payments/stripe_checkout_session_args', function ($sessionData, $context) {
    // Enable promotion codes on hosted Stripe Checkout page
    $sessionData['allow_promotion_codes'] = true;
    return $sessionData;
}, 10, 2);
```

---

### `payments/stripe_subscription_checkout_session_args`
`fluent_cart/payments/stripe_subscription_checkout_session_args` — Filter Stripe Checkout session arguments (subscription)

* **When it runs:** Applied when creating a Stripe Checkout session for subscription-based hosted payments.
* **Source:** `app/Modules/PaymentMethods/StripeGateway/Processor.php` (line 509)

#### Parameters:
* `$sessionData` *(array)* — Checkout session arguments (`customer`, `client_reference_id`, `line_items`, `mode`, `subscription_data`, `metadata`)
* `$context` *(array)* — Context data (`['order' => Order, 'transaction' => Transaction, 'subscription' => Subscription]`)
* **Returns:** *(array)* — The modified Checkout session arguments

#### Usage Example:
```php
// Filter Stripe Checkout session arguments for subscriptions
add_filter('fluent_cart/payments/stripe_subscription_checkout_session_args', function ($sessionData, $context) {
    // Enable tax ID collection on hosted subscription Checkout page
    $sessionData['tax_id_collection'] = ['enabled' => true];
    return $sessionData;
}, 10, 2);
```

---

### `stripe_idempotency_key`
`fluent_cart_stripe_idempotency_key` — Filter the Stripe idempotency key

* **When it runs:** Applied when sending charge requests to the Stripe API to prevent duplicate charges.
* **Source:** `app/Modules/PaymentMethods/StripeGateway/API/ApiRequest.php` (line 115)

#### Parameters:
* `$key` *(string)* — Generated idempotency key string
* `$context` *(array)* — Context data (`['request' => [...]]`)
* **Returns:** *(string)* — The modified idempotency key

#### Usage Example:
```php
// Filter Stripe API request idempotency key string
add_filter('fluent_cart_stripe_idempotency_key', function ($key, $context) {
    // Generate custom hashed idempotency key
    return 'fct_' . md5($key . time());
}, 10, 2);
```

---

### `stripe_request_body`
`fluent_cart_stripe_request_body` — Filter the Stripe API request body

* **When it runs:** Applied just before every request is sent to the Stripe API. Low-level filter affecting all Stripe calls.
* **Source:** `app/Modules/PaymentMethods/StripeGateway/API/ApiRequest.php` (line 126)

#### Parameters:
* `$request` *(array)* — The request body data array
* `$context` *(array)* — Context data (`['api' => 'charges']`)
* **Returns:** *(array)* — The modified request body

#### Usage Example:
```php
// Filter Stripe API request body data array
add_filter('fluent_cart_stripe_request_body', function ($request, $context) {
    // Log low-level Stripe API call endpoint
    error_log('Stripe API call to: ' . $context['api']);
    return $request;
}, 10, 2);
```

---

### `form_disable_stripe_connect`
`fluent_cart_form_disable_stripe_connect` — Disable Stripe Connect provider option

* **When it runs:** Applied when rendering the Stripe settings form. Return true to force manual API keys.
* **Source:** `app/Modules/PaymentMethods/StripeGateway/Stripe.php` (line 288)

#### Parameters:
* `$disable` *(bool)* — Whether to disable Stripe Connect (default: `false`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(bool)* — `true` to disable Stripe Connect and force manual API keys mode

#### Usage Example:
```php
// Filter whether to disable Stripe Connect option in admin form
add_filter('fluent_cart_form_disable_stripe_connect', function ($disable, $data) {
    // Force manual API keys mode for Stripe
    return true;
}, 10, 2);
```

---

### `stripe_appearance`
`fluent_cart_stripe_appearance` — Filter Stripe Elements appearance configuration

* **When it runs:** Applied when initializing Stripe Elements on the checkout page. Controls visual theme and styling.
* **Source:** `app/Modules/PaymentMethods/StripeGateway/Stripe.php` (line 427)

#### Parameters:
* `$appearance` *(array)* — Stripe Elements appearance configuration array (`['theme' => 'stripe']`)
* **Returns:** *(array)* — The modified appearance configuration (follows Stripe Appearance API)

#### Usage Example:
```php
// Filter Stripe Elements appearance configuration array
add_filter('fluent_cart_stripe_appearance', function ($appearance) {
    // Apply custom dark theme styling to embedded Stripe form
    return [
        'theme'     => 'night',
        'variables' => [
            'colorPrimary'    => '#0570de',
            'borderRadius'    => '8px',
            'fontFamily'      => 'Inter, system-ui, sans-serif',
        ],
    ];
}, 10, 1);
```

---

### `stripe/setup_intent_rate_limit_customer_daily`
`fluent_cart/stripe/setup_intent_rate_limit_customer_daily` — Filter daily SetupIntent rate limit per customer

* **When it runs:** Applied when enforcing rate limit for Stripe SetupIntent creation (used for subscription card updates).
* **Source:** `app/Modules/PaymentMethods/StripeGateway/SubscriptionsManager.php` (lines 85, 101)

#### Parameters:
* `$limit` *(int)* — Maximum SetupIntent attempts per customer per day (default: `3`)
* `$customerId` *(string)* — The Stripe customer ID
* **Returns:** *(int)* — The modified daily rate limit

#### Usage Example:
```php
// Filter daily SetupIntent rate limit count per customer
add_filter('fluent_cart/stripe/setup_intent_rate_limit_customer_daily', function ($limit, $customerId) {
    // Increase daily rate limit to 5 attempts for card updates
    return 5;
}, 10, 2);
```

---

### `stripe/fallback_order_transaction`
`fluent_cart/stripe/fallback_order_transaction` — Fallback transaction for Stripe webhooks

* **When it runs:** Applied during Stripe webhook processing when no matching `OrderTransaction` can be found by `vendor_charge_id`.
* **Source:** `app/Modules/PaymentMethods/StripeGateway/Webhook/Webhook.php` (line 121)

#### Parameters:
* `$transaction` *(\FluentCart\App\Models\OrderTransaction|null)* — The fallback transaction (default: `null`)
* `$vendorDataObject` *(object)* — Stripe event data object containing charge details
* **Returns:** *(\FluentCart\App\Models\OrderTransaction|null)* — OrderTransaction instance or null

#### Usage Example:
```php
// Provide fallback OrderTransaction when vendor_charge_id lookup fails
add_filter('fluent_cart/stripe/fallback_order_transaction', function ($transaction, $vendorDataObject) {
    // Look up transaction by reference metadata in event payload
    if (isset($vendorDataObject->metadata->fct_ref_id)) {
        $order = \FluentCart\App\Models\Order::where('uuid', $vendorDataObject->metadata->fct_ref_id)->first();
        if ($order) {
            return \FluentCart\App\Models\OrderTransaction::where('order_id', $order->id)
                ->where('transaction_type', 'charge')
                ->first();
        }
    }
    return $transaction;
}, 10, 2);
```

---

## PayPal

### `paypal_plan_id`
`fluent_cart/paypal_plan_id` — Filter PayPal plan ID for subscriptions

* **When it runs:** Applied when generating or resolving the PayPal billing plan ID for a subscription product variation.
* **Source:** `app/Modules/PaymentMethods/PayPalGateway/PayPalHelper.php` (line 54)

#### Parameters:
* `$planId` *(string)* — The generated plan ID string
* `$context` *(array)* — Context data (`['plan_data' => [...], 'variation' => Variation, 'product' => Product]`)
* **Returns:** *(string)* — The modified PayPal plan ID

#### Usage Example:
```php
// Filter PayPal billing plan ID for subscription product variations
add_filter('fluent_cart/paypal_plan_id', function ($planId, $context) {
    // Construct custom formatted PayPal plan ID string
    return 'custom_plan_' . $context['variation']->id;
}, 10, 2);
```

---

### `payments/paypal_sdk_src`
`fluent_cart/payments/paypal_sdk_src` — Filter PayPal SDK JavaScript source URL

* **When it runs:** Applied when generating the PayPal JavaScript SDK script URL for the checkout page.
* **Source:** `app/Modules/PaymentMethods/PayPalGateway/PayPal.php` (line 518)

#### Parameters:
* `$sdkSrc` *(string)* — The PayPal SDK URL with query parameters
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(string)* — The modified PayPal SDK URL

#### Usage Example:
```php
// Filter PayPal SDK JavaScript script URL for checkout
add_filter('fluent_cart/payments/paypal_sdk_src', function ($sdkSrc, $data) {
    // Append locale parameter to PayPal SDK URL
    return add_query_arg('locale', 'en_US', $sdkSrc);
}, 10, 2);
```

---

### `payments/paypal/disable_webhook_verification`
`fluent_cart/payments/paypal/disable_webhook_verification` — Disable PayPal webhook signature verification

* **When it runs:** Applied at the start of PayPal webhook verification. Return `'yes'` to skip signature verification.
* **Source:** `app/Modules/PaymentMethods/PayPalGateway/IPN.php` (line 179)

#### Parameters:
* `$disable` *(string)* — Whether to disable verification (default: `'no'`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(string)* — `'yes'` to skip verification, `'no'` to verify normally

#### Usage Example:
```php
// Filter whether to disable PayPal webhook signature verification
add_filter('fluent_cart/payments/paypal/disable_webhook_verification', function ($disable, $data) {
    // Disable signature verification in local development environment
    if (wp_get_environment_type() === 'local') {
        return 'yes';
    }
    return $disable;
}, 10, 2);
```

---

### `payments/paypal/verify_webhook`
`fluent_cart/payments/paypal/verify_webhook` — Control PayPal webhook verification

* **When it runs:** Applied before the actual PayPal webhook signature verification step in the main processing flow.
* **Source:** `app/Modules/PaymentMethods/PayPalGateway/IPN.php` (line 302)

#### Parameters:
* `$verify` *(bool)* — Whether to verify the webhook (default: `true`)
* `$context` *(array)* — Context data (`['data' => [...], 'mode' => 'live'|'test', 'type' => 'PAYMENT.SALE.COMPLETED']`)
* **Returns:** *(bool)* — Whether to proceed with webhook verification

#### Usage Example:
```php
// Filter whether to proceed with PayPal webhook verification
add_filter('fluent_cart/payments/paypal/verify_webhook', function ($verify, $context) {
    // Skip verification for test mode webhooks
    if ($context['mode'] === 'test') {
        return false;
    }
    return $verify;
}, 10, 2);
```

---

## Tax

### `tax/country_tax_titles`
`fluent_cart/tax/country_tax_titles` — Filter tax title labels per country

* **When it runs:** Applied when retrieving the mapping of country codes to their tax identification field labels (e.g. VAT, GST, ABN).
* **Source:** `app/Modules/Tax/TaxModule.php` (line 1730)

#### Parameters:
* `$taxTitles` *(array)* — Associative array of country code => tax label (`AU => ABN`, `GB => VAT`, `US => EIN / Sales Tax`)
* **Returns:** *(array)* — The modified country tax titles array

#### Usage Example:
```php
// Filter country tax identification field labels mapping array
add_filter('fluent_cart/tax/country_tax_titles', function ($taxTitles) {
    // Override tax field labels for South Korea and US
    $taxTitles['KR'] = __('BRN / VAT', 'my-plugin');
    $taxTitles['US'] = __('Tax ID', 'my-plugin');
    return $taxTitles;
}, 10, 1);
```

---

### `tax_summary_should_render`
`fluent_cart/tax_summary_should_render` — Filter whether tax summary is rendered on order receipt

* **When it runs:** Applied in `TaxSummaryHelper::computeTaxSummary()` while building tax summary for order receipt surfaces (thank-you page, emails, PDFs).
* **Source:** `app/Services/Renderer/Receipt/TaxSummaryHelper.php` (line 172)

#### Parameters:
* `$shouldRender` *(bool)* — Whether tax summary should render (default: `true`)
* `$order` *(\FluentCart\App\Models\Order)* — The order being rendered
* **Returns:** *(bool)* — `false` to hide the tax summary block

#### Usage Example:
```php
// Filter whether tax summary block is rendered on order receipt
add_filter('fluent_cart/tax_summary_should_render', function ($shouldRender, $order) {
    // Hide tax summary block for test mode orders
    if ($order->mode === 'test') {
        return false;
    }
    return $shouldRender;
}, 10, 2);
```

---

## Mollie (Pro)

### `mollie_settings` (Pro)
`fluent_cart/mollie_settings` — Filter Mollie gateway settings

* **When it runs:** Applied when loading Mollie gateway settings during initialization.
* **Source:** `fluent-cart-pro/app/Modules/PaymentMethods/MollieGateway/MollieSettingsBase.php` (line 26)

#### Parameters:
* `$settings` *(array)* — The Mollie settings array including API keys and configuration
* **Returns:** *(array)* — The modified Mollie settings

#### Usage Example:
```php
// Filter Mollie gateway settings array during initialization (Pro)
add_filter('fluent_cart/mollie_settings', function ($settings) {
    // Override Mollie payment mode to test in staging
    if (wp_get_environment_type() === 'staging') {
        $settings['payment_mode'] = 'test';
    }
    return $settings;
}, 10, 1);
```

---

### `payments/mollie_payment_args` (Pro)
`fluent_cart/payments/mollie_payment_args` — Filter Mollie payment data

* **When it runs:** Applied when building the payment data array before sending to the Mollie API for payment creation.
* **Source:** `fluent-cart-pro/app/Modules/PaymentMethods/MollieGateway/MollieProcessor.php` (line 142)

#### Parameters:
* `$paymentData` *(array)* — Payment data array for Mollie API
* `$context` *(array)* — Context data (`['order' => Order, 'transaction' => Transaction]`)
* **Returns:** *(array)* — The modified payment data

#### Usage Example:
```php
// Filter Mollie payment API creation payload data (Pro)
add_filter('fluent_cart/payments/mollie_payment_args', function ($paymentData, $context) {
    // Inject custom description into Mollie payment creation payload
    $paymentData['description'] = 'Order #' . $context['order']->id . ' - My Store';
    return $paymentData;
}, 10, 2);
```

---

### `mollie/pass_line_items_details` (Pro)
`fluent_cart/mollie/pass_line_items_details` — Control passing line item details to Mollie

* **When it runs:** Applied before building the Mollie payment request. Return true to include line items (useful for Klarna, iDEAL).
* **Source:** `fluent-cart-pro/app/Modules/PaymentMethods/MollieGateway/MollieProcessor.php` (line 128)

#### Parameters:
* `$passLineItems` *(bool)* — Whether to include line items (default: `false`)
* `$context` *(array)* — Array containing `[$order, $transaction]`
* **Returns:** *(bool)* — Whether to pass line item details to Mollie

#### Usage Example:
```php
// Control whether line item details are passed to Mollie API (Pro)
add_filter('fluent_cart/mollie/pass_line_items_details', function ($passLineItems, $context) {
    // Enable line item details for Klarna payment support
    return true;
}, 10, 2);
```

---

### `mollie/webhook_url` (Pro)
`fluent_cart/mollie/webhook_url` — Filter the Mollie webhook URL

* **When it runs:** Applied when generating the webhook notification URL sent to Mollie during payment creation.
* **Source:** `fluent-cart-pro/app/Modules/PaymentMethods/MollieGateway/MollieProcessor.php` (line 301)

#### Parameters:
* `$webhookUrl` *(string)* — The IPN/webhook listener URL
* **Returns:** *(string)* — The modified webhook URL

#### Usage Example:
```php
// Filter Mollie IPN webhook notification URL (Pro)
add_filter('fluent_cart/mollie/webhook_url', function ($webhookUrl) {
    // Use ngrok tunnel URL for local development webhook testing
    if (wp_get_environment_type() === 'local') {
        return 'https://my-tunnel.ngrok.io/?fct_payment_listener=1&method=mollie';
    }
    return $webhookUrl;
}, 10, 1);
```

---

### `mollie/subscription_description` (Pro)
`fluent_cart/mollie/subscription_description` — Filter Mollie subscription description

* **When it runs:** Applied when creating a Mollie subscription to customize statement description string.
* **Source:** `fluent-cart-pro/app/Modules/PaymentMethods/MollieGateway/MollieHelper.php` (line 209)

#### Parameters:
* `$description` *(string)* — The generated subscription description string
* `$context` *(array)* — Context data (`['subscription_model' => Subscription, 'currency' => 'EUR']`)
* **Returns:** *(string)* — The modified subscription description

#### Usage Example:
```php
// Filter Mollie subscription description string (Pro)
add_filter('fluent_cart/mollie/subscription_description', function ($description, $context) {
    // Customize Mollie subscription statement description string
    return 'MyStore - ' . $context['subscription_model']->item_name;
}, 10, 2);
```

---

## Paddle (Pro)

### `paddle_product_tax_category` (Pro)
`fluent_cart/paddle_product_tax_category` — Filter Paddle product tax category

* **When it runs:** Applied when FluentCart creates the corresponding product on Paddle to determine the tax category (`standard`, `digital-goods`, `saas`).
* **Source:** `fluent-cart-pro/app/Modules/PaymentMethods/PaddleGateway/Product.php` (line 44)

#### Parameters:
* `$taxCategory` *(string)* — The tax category (default: `'standard'`)
* `$data` *(array)* — Context data (`['product' => Product, 'variation_id' => int|null]`)
* **Returns:** *(string)* — The Paddle tax category

#### Usage Example:
```php
// Filter Paddle product tax category string (Pro)
add_filter('fluent_cart/paddle_product_tax_category', function ($taxCategory, $data) {
    // Set tax category to saas for digital software products
    if ($data['product'] && $data['product']->type === 'digital') {
        return 'saas';
    }
    return $taxCategory;
}, 10, 2);
```

---

# Filter Hooks: Products & Pricing

All filters related to Product display, catalog management, pricing, stock, URLs, and Coupons.

---

## Product Display & Layout

### `products_list`
`fluent_cart/products_list` — Filter the admin products list

* **When it runs:** This filter is applied after fetching the paginated products collection in the admin products list view.
* **Source:** `app/Http/Controllers/ProductController.php` (line 52)

#### Parameters:
* `$products` *(\FluentCart\Framework\Database\Orm\LengthAwarePaginator)* — Paginated products collection with appended `view_url` and `edit_url` attributes
* **Returns:** *(\FluentCart\Framework\Database\Orm\LengthAwarePaginator)* — The modified paginated collection

#### Usage Example:
```php
// Filter paginated products collection for admin list view
add_filter('fluent_cart/products_list', function($products) {
    // Loop through collection and attach custom badge attribute
    $products->getCollection()->transform(function ($product) {
        $product->custom_badge = 'Featured';
        return $product;
    });
    return $products;
}, 10, 1);
```

---

### `shop_query`
`fluent_cart/shop_query` — Filter the shop product query builder

* **When it runs:** This filter is applied when building the query for the public-facing shop product listing, before search, status, and sorting clauses are added.
* **Source:** `api/Resource/ShopResource.php` (line 100)

#### Parameters:
* `$query` *(\FluentCart\Framework\Database\Orm\Builder)* — The Eloquent query builder instance with `select` and `with` already applied
* `$params` *(array)* — The query parameters array (`select`, `with`, `selected_status`, etc.)
* **Returns:** *(\FluentCart\Framework\Database\Orm\Builder)* — The modified query builder

#### Usage Example:
```php
// Filter shop product query builder before executing search and filters
add_filter('fluent_cart/shop_query', function($query, $params) {
    // Restrict shop query to products matching category term ID 5
    $query->whereHas('taxonomies', function ($q) {
        $q->where('taxonomy', 'product-category')
          ->where('term_id', 5);
    });
    return $query;
}, 10, 2);
```

---

### `single_product/variation_view_type`
`fluent_cart/single_product/variation_view_type` — Filter variation display type on single product pages

* **When it runs:** This filter is applied when initializing the product renderer to determine how variations are visually presented on the single product page.
* **Source:** `app/Services/Renderer/ProductRenderer.php` (line 67)

#### Parameters:
* `$viewType` *(string)* — The variation view type (`'image'`, `'text'`, `'both'`)
* `$data` *(array)* — Context data (`['product' => Product, 'variants' => Collection, 'defaultVariationId' => int]`)
* **Returns:** *(string)* — The modified view type

#### Usage Example:
```php
// Filter variation display type on single product pages
add_filter('fluent_cart/single_product/variation_view_type', function($viewType, $data) {
    // Force variation display mode to show both image and text
    return 'both';
}, 10, 2);
```

---

### `single_product/variation_column_type`
`fluent_cart/single_product/variation_column_type` — Filter variation column layout on single product pages

* **When it runs:** This filter is applied when initializing the product renderer to determine the column layout for product variations.
* **Source:** `app/Services/Renderer/ProductRenderer.php` (line 74)

#### Parameters:
* `$columnType` *(string)* — The column layout type (`'one'`, `'two'`, `'three'`, `'four'`, `'masonry'`)
* `$data` *(array)* — Context data (`['product' => Product, 'variants' => Collection, 'defaultVariationId' => int]`)
* **Returns:** *(string)* — The modified column type

#### Usage Example:
```php
// Filter variation column layout on single product pages
add_filter('fluent_cart/single_product/variation_column_type', function($columnType, $data) {
    // Extract product model instance from event context
    $product = $data['product'];

    // Use two-column layout when product has more than 6 variations
    if (count($data['variants']) > 6) {
        return 'two';
    }
    return $columnType;
}, 10, 2);
```

---

### `single_product/variation_price`
`fluent_cart/single_product/variation_price` — Filter variation price text on single product pages

* **When it runs:** This filter is applied when rendering the price text for each product variation. For one-time products the price is the formatted decimal amount; for subscriptions it includes the billing terms text.
* **Source:** `app/Services/Renderer/ProductRenderer.php` (line 827)

#### Parameters:
* `$priceText` *(string)* — The formatted price text (escaped HTML)
* `$data` *(array)* — Context data (`['product' => Product, 'variant' => ProductVariant, 'scope' => 'product_variant_price']`)
* **Returns:** *(string)* — The modified price text (HTML allowed via `wp_kses_post`)

#### Usage Example:
```php
// Filter variation price text rendered on single product pages
add_filter('fluent_cart/single_product/variation_price', function($priceText, $data) {
    // Extract variant model instance
    $variant = $data['variant'];

    // Append per-month label to subscription variation prices
    if ($variant->payment_type === 'subscription') {
        return $priceText . ' <small>/month</small>';
    }
    return $priceText;
}, 10, 2);
```

---

### `shop_app_product_query_taxonomy_filters`
`fluent_cart/shop_app_product_query_taxonomy_filters` — Filter taxonomy filters for Shop block product query

* **When it runs:** This filter is applied in the Shop App Gutenberg block when merging URL-based taxonomy filters with default block filters, before the product query is executed.
* **Source:** `app/Hooks/Handlers/BlockEditors/ShopApp/InnerBlocks/InnerBlocks.php` (line 1379)

#### Parameters:
* `$mergedTerms` *(array)* — Merged taxonomy term IDs keyed by taxonomy name (`['product-category' => [1, 5]]`)
* `$data` *(array)* — Context data (`['default_terms' => [...], 'url_terms' => [...], 'block' => $block]`)
* **Returns:** *(array)* — The modified taxonomy term IDs array

#### Usage Example:
```php
// Filter taxonomy filters for Shop Gutenberg block product query
add_filter('fluent_cart/shop_app_product_query_taxonomy_filters', function($mergedTerms, $data) {
    // Exclude category ID 99 from shop block product query
    if (isset($mergedTerms['product-category'])) {
        $mergedTerms['product-category'] = array_diff($mergedTerms['product-category'], [99]);
    }
    return $mergedTerms;
}, 10, 2);
```

---

### `products_views/preload_collection_{$provider}`
`fluent_cart/products_views/preload_collection_{$provider}` — Preload product view collection for a template provider

* **When it runs:** This dynamic filter is applied when the shop controller loads products via AJAX for a specific template provider (e.g. `bricks`). The `{$provider}` portion is replaced with the template provider name.
* **Source:** `app/Http/Controllers/ShopController.php` (line 103)

#### Parameters:
* `$html` *(string)* — Default empty string. Return rendered HTML to use preloaded view instead of JSON
* `$data` *(array)* — Context data (`['client_id' => string, 'products' => array, 'total' => int, 'requestData' => array]`)
* **Returns:** *(string)* — Rendered HTML string, or empty string to fall back to default JSON response

#### Usage Example:
```php
// Preload product view collection HTML for Bricks template provider
add_filter('fluent_cart/products_views/preload_collection_bricks', function($html, $data) {
    // Render custom HTML structure for Bricks page builder integration
    ob_start();
    foreach ($data['products'] as $product) {
        echo '<div class="custom-product-card">' . esc_html($product['title']) . '</div>';
    }
    return ob_get_clean();
}, 10, 2);
```

---

## Product Buttons & Text

### `product/buy_now_button_text`
`fluent_cart/product/buy_now_button_text` — Filter the Buy Now button text

* **When it runs:** Applied when rendering the "Buy Now" button on single product pages. Runs in both PHP product renderer and JavaScript variable localization.
* **Source:** `app/Services/Renderer/ProductRenderer.php` (lines 1081, 1181), `app/Modules/Templating/AssetLoader.php` (lines 87, 261)

#### Parameters:
* `$text` *(string)* — The button text (default: `'Buy Now'`)
* `$data` *(array)* — Context data (`['product' => Product]`)
* **Returns:** *(string)* — The modified button text

#### Usage Example:
```php
// Filter Buy Now button text on single product pages
add_filter('fluent_cart/product/buy_now_button_text', function($text, $data) {
    // Customize button text for digital product types
    if (!empty($data['product']) && $data['product']->product_type === 'digital') {
        return 'Download Now';
    }
    return $text;
}, 10, 2);
```

---

### `product/add_to_cart_text`
`fluent_cart/product/add_to_cart_text` — Filter the Add to Cart button text

* **When it runs:** Applied when rendering the "Add to Cart" button text across single product pages, shop blocks, carousels, shortcodes, and localized JS variables.
* **Source:** `app/Services/Renderer/ProductRenderer.php` (lines 1227, 1314), `app/Hooks/Handlers/ShortCodes/SingleProductShortCode.php` (line 81), `app/Hooks/Handlers/BlockEditors/ShopApp/InnerBlocks/InnerBlocks.php` (lines 1025, 1104)

#### Parameters:
* `$text` *(string)* — The button text (default: `'Add To Cart'`)
* `$data` *(array)* — Context data (`['product' => Product]`)
* **Returns:** *(string)* — The modified button text

#### Usage Example:
```php
// Filter Add to Cart button text across all product templates
add_filter('fluent_cart/product/add_to_cart_text', function($text, $data) {
    // Change default Add to Cart button text to Add to Basket
    return 'Add to Basket';
}, 10, 2);
```

---

### `product/out_of_stock_text`
`fluent_cart/product/out_of_stock_text` — Filter the out-of-stock button text

* **When it runs:** Applied when rendering button text for out-of-stock products across shortcodes, shop blocks, carousels, and localized JS variables.
* **Source:** `app/Hooks/Handlers/ShortCodes/SingleProductShortCode.php` (line 83), `app/Hooks/Handlers/BlockEditors/ShopApp/InnerBlocks/InnerBlocks.php` (lines 1027, 1106)

#### Parameters:
* `$text` *(string)* — The out-of-stock text (default: `'Not Available'`)
* `$data` *(array)* — Context data (empty array)
* **Returns:** *(string)* — The modified out-of-stock text

#### Usage Example:
```php
// Filter out-of-stock button text for unavailable products
add_filter('fluent_cart/product/out_of_stock_text', function($text) {
    // Override out-of-stock label text
    return 'Sold Out';
}, 10, 1);
```

---

### `product/out_of_stock_button_text`
`fluent_cart/product/out_of_stock_button_text` — Filter out-of-stock button text (block editor context)

* **When it runs:** Applied in block editor asset loader when localizing out-of-stock button text for JS-rendered product pages.
* **Source:** `app/Modules/Templating/AssetLoader.php` (line 260)

#### Parameters:
* `$text` *(string)* — The out-of-stock text (default: `'Not Available'`)
* `$data` *(array)* — Context data (empty array)
* **Returns:** *(string)* — The modified button text

#### Usage Example:
```php
// Filter out-of-stock button text in block editor asset loader
add_filter('fluent_cart/product/out_of_stock_button_text', function($text) {
    // Customize out-of-stock label for JS-rendered pages
    return 'Currently Unavailable';
}, 10, 1);
```

---

### `product/price_suffix_atts`
`fluent_cart/product/price_suffix_atts` — Filter price suffix for product variations

* **When it runs:** Applied when rendering each variation item in the selector. Tax module hooks here to append tax suffixes (e.g. "incl. tax").
* **Source:** `app/Services/Renderer/ProductRenderer.php` (line 1408)

#### Parameters:
* `$suffix` *(string)* — The price suffix text (default: `''`)
* `$data` *(array)* — Context data (`['product' => Product, 'variant' => ProductVariant, 'scope' => 'variant_item']`)
* **Returns:** *(string)* — The modified price suffix text

#### Usage Example:
```php
// Filter price suffix text for product variations
add_filter('fluent_cart/product/price_suffix_atts', function($suffix, $data) {
    // Append custom tax suffix label to variation price
    return ' incl. VAT';
}, 10, 2);
```

---

### `product_short_description`
`fluent_cart/product_short_description` — Filter product short description

* **When it runs:** Applied when rendering short description on single product page, using post excerpt as default value.
* **Source:** `app/Hooks/Handlers/TemplateLoader.php` (line 26)

#### Parameters:
* `$shortDescription` *(string)* — Product short description (from `$post->post_excerpt`)
* `$data` *(array)* — Context data (empty array)
* **Returns:** *(string)* — Modified short description (output via `wp_kses_post`)

#### Usage Example:
```php
// Filter product short description output on single product pages
add_filter('fluent_cart/product_short_description', function($shortDescription) {
    // Append price disclaimer paragraph to short description
    return $shortDescription . '<p class="disclaimer">Prices subject to change.</p>';
}, 10, 1);
```

---

## Stock & Availability

### `product_stock_availability`
`fluent_cart/product_stock_availability` — Filter product stock availability information

* **When it runs:** Applied when retrieving stock availability data from `ProductDetail` model, based on stock settings and inventory levels.
* **Source:** `app/Models/ProductDetail.php` (line 183)

#### Parameters:
* `$availability` *(array)* — Stock availability data (`manage_stock`, `availability`, `class`, `available_quantity`)
* `$data` *(array)* — Context data (`['detail' => ProductDetail, 'variation_id' => int|null]`)
* **Returns:** *(array)* — The modified availability data

#### Usage Example:
```php
// Filter product stock availability status data and label
add_filter('fluent_cart/product_stock_availability', function($availability, $data) {
    // Show low stock warning message when quantity is under 5
    if ($availability['manage_stock'] && $availability['available_quantity'] > 0 && $availability['available_quantity'] < 5) {
        $availability['availability'] = 'Only ' . $availability['available_quantity'] . ' left in stock!';
        $availability['class'] = 'low-stock';
    }
    return $availability;
}, 10, 2);
```

---

## Product URLs & Templates

### `price_class`
`fluent_cart/price_class` — Filter price element CSS class

* **When it runs:** Applied when rendering the price paragraph element on the single product page template.
* **Source:** `app/Hooks/Handlers/TemplateLoader.php` (line 40)

#### Parameters:
* `$class` *(string)* — The CSS class for price element (default: `'price'`)
* **Returns:** *(string)* — The modified CSS class string

#### Usage Example:
```php
// Filter price paragraph element CSS class on single product page
add_filter('fluent_cart/price_class', function($class) {
    // Add custom CSS class to price container element
    return 'price fct-custom-price';
}, 10, 1);
```

---

### `front_url_slug`
`fluent_cart/front_url_slug` — Filter product URL slug

* **When it runs:** Applied when registering `fluent-products` CPT to change URL slug for permalinks. Default comes from store settings (`'item'`).
* **Source:** `app/CPT/FluentProducts.php` (line 181)

#### Parameters:
* `$slug` *(string)* — Product URL slug
* `$data` *(array)* — Context data (empty array)
* **Returns:** *(string)* — Modified URL slug

#### Usage Example:
```php
// Filter product custom post type URL permalink slug
add_filter('fluent_cart/front_url_slug', function($slug) {
    // Change product permalink base slug from item to shop
    return 'shop';
}, 10, 1);
```

---

### `product_url_with_front`
`fluent_cart/product_url_with_front` — Filter whether product URL includes front base

* **When it runs:** Applied when registering `fluent-products` CPT rewrite rules. Controls whether permalink front base (e.g. `/blog/`) is prepended.
* **Source:** `app/CPT/FluentProducts.php` (line 183)

#### Parameters:
* `$withFront` *(bool)* — Whether to prepend permalink front base (default: `true`)
* `$data` *(array)* — Context data (`['slug' => string]`)
* **Returns:** *(bool)* — Modified boolean value

#### Usage Example:
```php
// Filter whether product permalinks include site front base prefix
add_filter('fluent_cart/product_url_with_front', function($withFront, $data) {
    // Remove permalink front base from product URLs
    return false;
}, 10, 2);
```

---

### `show_standalone_product_menu`
`fluent_cart/show_standalone_product_menu` — Filter whether to show standalone Products menu in WP admin

* **When it runs:** Applied during init when registering `fluent-products` CPT. When enabled, adds a separate "Products" sidebar menu.
* **Source:** `app/CPT/FluentProducts.php` (line 37)

#### Parameters:
* `$show` *(bool)* — Whether to show standalone menu (default: `false`)
* **Returns:** *(bool)* — Modified boolean value

#### Usage Example:
```php
// Filter whether to display standalone Products menu in WP admin sidebar
add_filter('fluent_cart/show_standalone_product_menu', function($show) {
    // Enable standalone Products CPT menu in WP admin
    return true;
}, 10, 1);
```

---

### `single_product_page/show_relevant_products`
`fluent_cart/single_product_page/show_relevant_products` — Filter showing related products on single product page

* **When it runs:** Applied when rendering single product page content after checking `show_relevant_product_in_single_page` store setting.
* **Source:** `app/Modules/Templating/TemplateActions.php` (line 240)

#### Parameters:
* `$show` *(bool)* — Whether to show related products
* `$postId` *(int)* — Current product post ID
* **Returns:** *(bool)* — Modified boolean value

#### Usage Example:
```php
// Filter whether to show related products section on single product page
add_filter('fluent_cart/single_product_page/show_relevant_products', function($show, $postId) {
    // Hide related products for specific product IDs
    $excludedIds = [100, 200, 300];
    if (in_array($postId, $excludedIds)) {
        return false;
    }
    return $show;
}, 10, 2);
```

---

### `disable_auto_single_product_page`
`fluent_cart/disable_auto_single_product_page` — Disable automatic single product page rendering

* **When it runs:** Applied when filtering title and content for single product pages. When true, prevents FluentCart from auto-injecting layout HTML.
* **Source:** `app/Modules/Templating/TemplateActions.php` (lines 191, 215)

#### Parameters:
* `$disable` *(bool)* — Whether to disable auto-rendering (default: `false`)
* **Returns:** *(bool)* — Modified boolean value

#### Usage Example:
```php
// Filter whether to disable automatic single product page template rendering
add_filter('fluent_cart/disable_auto_single_product_page', function($disable) {
    // Disable automatic rendering when Elementor page builder is active
    if (class_exists('Elementor\Plugin')) {
        return true;
    }
    return $disable;
}, 10, 1);
```

---

## Coupons

### `coupon/validating_coupon`
`fluent_cart/coupon/validating_coupon` — Filter coupon code during validation

* **When it runs:** Applied at the start of coupon validation before database lookup. Modify code string or return `WP_Error` to reject.
* **Source:** `app/Services/Coupon/Concerns/CanValidateCoupon.php` (line 21)

#### Parameters:
* `$couponCode` *(string)* — Coupon code being validated
* `$data` *(array)* — Context data (`['coupon_code' => string, 'line_items' => array, 'couponService' => CouponService]`)
* **Returns:** *(string|\WP_Error)* — Modified coupon code, or `WP_Error` to reject

#### Usage Example:
```php
// Filter coupon code string at start of validation
add_filter('fluent_cart/coupon/validating_coupon', function($couponCode, $data) {
    // Normalize coupon code string to uppercase
    $couponCode = strtoupper(trim($couponCode));

    // Reject blocked coupon codes with error message
    $blockedCodes = ['EXPIRED2024', 'TESTONLY'];
    if (in_array($couponCode, $blockedCodes)) {
        return new \WP_Error('coupon_blocked', __('This coupon code is no longer valid.', 'fluent-cart'));
    }

    return $couponCode;
}, 10, 2);
```

---

### `coupon/can_use_coupon`
`fluent_cart/coupon/can_use_coupon` — Filter whether a coupon can be used

* **When it runs:** Applied after coupon is found in database but before discount calculation to run custom eligibility checks.
* **Source:** `app/Services/Coupon/DiscountService.php` (line 257)

#### Parameters:
* `$canUse` *(bool)* — Whether coupon can be used (default: `true`)
* `$data` *(array)* — Context data (`['coupon' => Coupon, 'cart' => Cart, 'cart_items' => array]`)
* **Returns:** *(bool|\WP_Error)* — `true` to allow, `false` or `WP_Error` to reject

#### Usage Example:
```php
// Filter whether a validated coupon can be applied to current cart
add_filter('fluent_cart/coupon/can_use_coupon', function($canUse, $data) {
    // Extract coupon model and cart model from context
    $coupon = $data['coupon'];
    $cart = $data['cart'];

    // Enforce minimum cart subtotal requirement of $50
    if ($cart->sub_total < 5000) {
        return new \WP_Error(
            'coupon_min_total',
            __('This coupon requires a minimum order of $50.', 'fluent-cart')
        );
    }

    return $canUse;
}, 10, 2);
```

---

### `coupon/will_skip_item`
`fluent_cart/coupon/will_skip_item` — Filter whether item is skipped from coupon discount

* **When it runs:** Applied for each cart item when filtering applicable items. Returning true excludes item from discount calculation.
* **Source:** `app/Services/Coupon/DiscountService.php` (line 279)

#### Parameters:
* `$willSkip` *(bool)* — Whether to skip item (default: `false`)
* `$data` *(array)* — Context data (`['item' => array, 'coupon' => Coupon, 'cart' => Cart]`)
* **Returns:** *(bool)* — `true` to exclude item from coupon discount

#### Usage Example:
```php
// Filter whether specific cart item is skipped from coupon discount
add_filter('fluent_cart/coupon/will_skip_item', function($willSkip, $data) {
    // Extract cart item array from context
    $item = $data['item'];

    // Exclude gift card product types from coupon discount calculation
    if (!empty($item['product_type']) && $item['product_type'] === 'gift_card') {
        return true;
    }

    return $willSkip;
}, 10, 2);
```

---

### `coupon/per_customer_usage_query`
`fluent_cart/coupon/per_customer_usage_query` — Filter per-customer coupon usage query

* **When it runs:** Applied when checking if customer exceeded per-customer usage limit for coupon to modify previous usage count query.
* **Source:** `app/Services/Coupon/DiscountService.php` (line 592)

#### Parameters:
* `$usageQuery` *(\FluentCart\Framework\Database\Orm\Builder)* — Eloquent query builder for `AppliedCoupon` records
* `$data` *(array)* — Context data (`['coupon' => Coupon, 'customer' => Customer, 'cart' => Cart]`)
* **Returns:** *(\FluentCart\Framework\Database\Orm\Builder)* — Modified query builder

#### Usage Example:
```php
// Filter per-customer coupon usage limit Eloquent query
add_filter('fluent_cart/coupon/per_customer_usage_query', function($usageQuery, $data) {
    // Restrict usage check query to last 30 days for rolling limits
    $usageQuery->where('created_at', '>=', gmdate('Y-m-d H:i:s', strtotime('-30 days')));
    return $usageQuery;
}, 10, 2);
```

---

### `coupon_statuses` (legacy)
`fluent-cart/coupon_statuses` — Filter available coupon statuses

* **When it runs:** Applied when retrieving available coupon statuses for admin coupon management interface. Note hyphenated prefix (`fluent-cart/`).
* **Source:** `app/Helpers/Helper.php` (line 823)

#### Parameters:
* `$statuses` *(array)* — Array of coupon statuses (`'active' => 'Active'`, `'expired' => 'Expired'`, `'disabled' => 'Disabled'`)
* `$data` *(array)* — Context data (empty array)
* **Returns:** *(array)* — Modified coupon statuses array

#### Usage Example:
```php
// Filter available coupon statuses array (legacy hyphenated hook name)
add_filter('fluent-cart/coupon_statuses', function($statuses) {
    // Add custom "Scheduled" coupon status
    $statuses['scheduled'] = __('Scheduled', 'fluent-cart');
    return $statuses;
}, 10, 1);
```

---

# Filter Hooks: Settings & Configuration

All filters related to admin settings, store configuration, module management, currency formatting, admin UI, permissions, translations, email notifications, and block editor.

---

## Store Settings

### `store_settings/values`
`fluent_cart/store_settings/values` — Filter default store settings values

* **When it runs:** This filter is applied when retrieving the default store settings, before merging with saved values. Use it to add or modify defaults for all store configuration options.
* **Source:** `api/StoreSettings.php` (line 89)

#### Parameters:
* `$defaultSettings` *(array)* — The default store settings (`currency`, `order_mode`, `checkout_button_text`, etc.)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified default settings array

#### Usage Example:
```php
// Filter default store settings values before merging with saved options
add_filter('fluent_cart/store_settings/values', function ($defaultSettings, $data) {
    // Change default currency to EUR and set order mode to live
    $defaultSettings['currency'] = 'EUR';
    $defaultSettings['order_mode'] = 'live';
    return $defaultSettings;
}, 10, 2);
```

---

### `store_settings/fields`
`fluent_cart/store_settings/fields` — Filter store settings form field definitions

* **When it runs:** This filter is applied when rendering the store settings form in the admin interface. Use it to add, remove, or modify settings tabs and fields.
* **Source:** `api/StoreSettings.php` (line 1141)

#### Parameters:
* `$fields` *(array)* — Nested array of settings tabs and field definitions (`setting_tabs -> schema`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified fields array

#### Usage Example:
```php
// Filter store settings form field definitions in admin interface
add_filter('fluent_cart/store_settings/fields', function ($fields, $data) {
    // Add a custom settings section tab and field
    $fields['setting_tabs']['schema']['custom_tab'] = [
        'title'  => 'Custom Settings',
        'fields' => [
            [
                'key'   => 'custom_field',
                'label' => 'Custom Field',
                'type'  => 'text',
            ]
        ]
    ];
    return $fields;
}, 10, 2);
```

---

### `store_settings/rules`
`fluent_cart/store_settings/rules` — Filter validation rules for store settings

* **When it runs:** This filter is applied when validating store settings form submissions. Use it to add or modify validation rules for settings fields.
* **Source:** `app/Http/Requests/FluentMetaRequest.php` (line 34)

#### Parameters:
* `$rules` *(array)* — Validation rules keyed by field name (`'store_name' => 'required|...'`)
* **Returns:** *(array)* — The modified validation rules array

#### Usage Example:
```php
// Filter validation rules for store settings form submissions
add_filter('fluent_cart/store_settings/rules', function ($rules) {
    // Add validation rules for custom settings field
    $rules['custom_field'] = 'required|sanitizeText|maxLength:100';
    return $rules;
});
```

---

### `store_settings/sanitizer`
`fluent_cart/store_settings/sanitizer` — Filter sanitization rules for store settings

* **When it runs:** This filter is applied when sanitizing store settings input before saving. Each key maps to a sanitize callback function or callable.
* **Source:** `app/Http/Requests/FluentMetaRequest.php` (line 136)

#### Parameters:
* `$sanitizer` *(array)* — Sanitization callbacks keyed by field name
* **Returns:** *(array)* — The modified sanitizer array

#### Usage Example:
```php
// Filter sanitization rules for store settings before saving
add_filter('fluent_cart/store_settings/sanitizer', function ($sanitizer) {
    // Add sanitizer callback for custom settings field
    $sanitizer['custom_field'] = 'sanitize_text_field';
    return $sanitizer;
});
```

---

### `confirmation_setting_fields`
`fluent_cart/confirmation_setting_fields` — Filter confirmation page settings fields

* **When it runs:** This filter is applied when rendering the confirmation (receipt) page settings in the admin. Use it to add additional settings fields for the order confirmation page.
* **Source:** `api/Confirmation.php` (line 76)

#### Parameters:
* `$fields` *(array)* — Field definitions for the confirmation page settings
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified fields array

#### Usage Example:
```php
// Filter confirmation page settings fields in admin
add_filter('fluent_cart/confirmation_setting_fields', function ($fields, $data) {
    // Add a custom confirmation page setting checkbox
    $fields['show_social_share'] = [
        'label' => 'Show social share buttons',
        'type'  => 'checkbox',
        'value' => 'no',
    ];
    return $fields;
}, 10, 2);
```

---

## Module Settings

### `module_setting/fields`
`fluent_cart/module_setting/fields` — Filter module settings form fields

* **When it runs:** This filter is applied when retrieving module settings field definitions. Modules register their settings fields through this filter.
* **Source:** `api/ModuleSettings.php` (line 21)

#### Parameters:
* `$fields` *(array)* — Array of module settings field definitions (empty by default)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified fields array

#### Usage Example:
```php
// Filter module settings form field definitions
add_filter('fluent_cart/module_setting/fields', function ($fields, $data) {
    // Register custom module settings fields
    $fields['custom_module'] = [
        'title'  => 'Custom Module',
        'fields' => [
            [
                'key'   => 'api_key',
                'label' => 'API Key',
                'type'  => 'text',
            ]
        ]
    ];
    return $fields;
}, 10, 2);
```

---

### `module_setting/default_values`
`fluent_cart/module_setting/default_values` — Filter module settings default values

* **When it runs:** This filter is applied when retrieving all module settings. It provides default values that are merged with saved settings, ensuring newly registered modules have their defaults applied.
* **Source:** `api/ModuleSettings.php` (line 42)

#### Parameters:
* `$defaults` *(array)* — Default values for module settings (empty by default)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified defaults array keyed by module name

#### Usage Example:
```php
// Filter module settings default values
add_filter('fluent_cart/module_setting/default_values', function ($defaults, $data) {
    // Set default values array for custom module
    $defaults['custom_module'] = [
        'active'  => 'no',
        'api_key' => '',
        'mode'    => 'sandbox',
    ];
    return $defaults;
}, 10, 2);
```

---

### `module_settings/plugin_addons`
`fluent_cart/module_settings/plugin_addons` — Filter plugin add-on modules list

* **When it runs:** This filter is applied when listing available plugin add-ons in the module settings page. Use it to register third-party add-on modules that can be installed from the admin.
* **Source:** `app/Http/Controllers/ModuleSettingsController.php` (line 199)

#### Parameters:
* `$addons` *(array)* — Array of add-on module definitions (`title`, `description`, `logo`, `plugin_slug`, etc.)
* **Returns:** *(array)* — The modified add-ons array

#### Usage Example:
```php
// Filter plugin add-on modules list in module settings page
add_filter('fluent_cart/module_settings/plugin_addons', function ($addons) {
    // Register a custom add-on module to the admin list
    $addons[] = [
        'title'       => 'My Custom Add-on',
        'description' => 'Extends FluentCart with custom features.',
        'logo'        => plugin_dir_url(__FILE__) . 'logo.svg',
        'plugin_slug' => 'my-custom-addon',
        'plugin_file' => 'my-custom-addon/my-custom-addon.php',
        'source_type' => 'cdn',
        'source_link' => 'https://example.com/my-addon.zip',
        'upcoming'    => false,
    ];
    return $addons;
});
```

---

## Currency & Formatting

### `global_currency_setting`
`fluent_cart/global_currency_setting` — Filter global currency settings

* **When it runs:** This filter is applied when retrieving the global currency configuration. It runs after all currency settings have been resolved from stored values and defaults.
* **Source:** `api/CurrencySettings.php` (line 52)

#### Parameters:
* `$settings` *(array)* — Resolved currency settings (`currency`, `currency_sign`, `currency_position`, `decimal_separator`, etc.)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified currency settings

#### Usage Example:
```php
// Filter global currency settings array
add_filter('fluent_cart/global_currency_setting', function ($settings, $data) {
    // Override currency, symbol, and symbol position
    $settings['currency'] = 'EUR';
    $settings['currency_sign'] = '€';
    $settings['currency_position'] = 'right';
    return $settings;
}, 10, 2);
```

---

### `available_currencies`
`fluent-cart/available_currencies` — Filter available currencies for the store

* **When it runs:** This filter is applied when retrieving the list of available currencies for the currency selector in store settings. Note the hyphenated hook prefix (`fluent-cart/` instead of `fluent_cart/`).
* **Source:** `app/Helpers/Helper.php` (line 467)

#### Parameters:
* `$currencies` *(array)* — Array of currency definitions keyed by currency code (`BDT`, `USD`, `GBP`, etc.)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified currencies array

#### Usage Example:
```php
// Filter available currencies for the store currency selector
add_filter('fluent-cart/available_currencies', function ($currencies, $data) {
    // Add Bitcoin (BTC) to the list of available currencies
    $currencies['BTC'] = [
        'label'  => 'Bitcoin',
        'value'  => 'BTC',
        'symbol' => '₿',
    ];
    return $currencies;
}, 10, 2);
```

---

### `accepted_currencies`
`fluent_cart/accepted_currencies` — Filter the full list of accepted currencies

* **When it runs:** This filter is applied when retrieving the complete list of currencies supported by payment gateways (based on Stripe's currency list). Used for currency validation and display throughout the plugin.
* **Source:** `app/Helpers/CurrenciesHelper.php` (line 20)

#### Parameters:
* `$currencies` *(array)* — Associative array of currency code to localized name (`'USD' => 'United States Dollar'`)
* **Returns:** *(array)* — The modified currencies array

#### Usage Example:
```php
// Filter full list of accepted currencies supported by payment gateways
add_filter('fluent_cart/accepted_currencies', function ($currencies) {
    // Remove XRP from accepted currencies list
    unset($currencies['XRP']);
    // Add custom currency to accepted list
    $currencies['CUSTOM'] = 'My Custom Currency';
    return $currencies;
});
```

---

### `global_currency_symbols`
`fluent_cart/global_currency_symbols` — Filter currency symbols map

* **When it runs:** This filter is applied when retrieving the mapping of currency codes to their display symbols. Used for formatting prices throughout the plugin.
* **Source:** `app/Helpers/CurrenciesHelper.php` (line 195)

#### Parameters:
* `$symbols` *(array)* — Associative array of currency code to HTML symbol entity (`'USD' => '&#36;'`)
* **Returns:** *(array)* — The modified currency symbols array

#### Usage Example:
```php
// Filter currency symbols map
add_filter('fluent_cart/global_currency_symbols', function ($symbols) {
    // Override Bangladeshi Taka currency symbol string
    $symbols['BDT'] = 'Tk';
    return $symbols;
});
```

---

### `zero_decimal_currencies`
`fluent_cart/zero_decimal_currencies` — Filter zero-decimal currencies list

* **When it runs:** This filter is applied when retrieving currencies that do not use decimal subunits (e.g., Japanese Yen). These currencies store amounts without dividing by 100.
* **Source:** `app/Helpers/CurrenciesHelper.php` (line 383)

#### Parameters:
* `$currencies` *(array)* — Associative array of zero-decimal currency code to localized name (`'JPY' => 'Japanese Yen'`)
* **Returns:** *(array)* — The modified zero-decimal currencies array

#### Usage Example:
```php
// Filter zero-decimal currencies list
add_filter('fluent_cart/zero_decimal_currencies', function ($currencies) {
    // Add Icelandic Krona to zero-decimal currencies array
    $currencies['ISK'] = 'Icelandic Krona';
    return $currencies;
});
```

---

### `hide_unnecessary_decimals`
`fluent_cart/hide_unnecessary_decimals` — Filter whether to hide `.00` decimals in formatted prices

* **When it runs:** This filter is applied during price formatting. When true, prices like `$10.00` will display as `$10` instead.
* **Source:** `app/Helpers/Helper.php` (line 343)

#### Parameters:
* `$hide` *(bool)* — Whether to hide unnecessary decimals (default: `false`)
* `$context` *(array)* — Context data (`['amount' => 10.00, 'decimal' => 2]`)
* **Returns:** *(bool)* — Whether to hide unnecessary trailing zeros

#### Usage Example:
```php
// Filter whether to hide unnecessary trailing .00 decimals in price display
add_filter('fluent_cart/hide_unnecessary_decimals', function ($hide, $context) {
    // Always hide trailing .00 from displayed prices
    return true;
}, 10, 2);
```

---

## Admin UI & Menu

### `admin_menu_title`
`fluent_cart/admin_menu_title` — Filter admin menu title

* **When it runs:** This filter is applied when registering the WordPress admin menu, allowing you to change the menu label shown in the sidebar.
* **Source:** `app/Hooks/Handlers/MenuHandler.php` (line 164)

#### Parameters:
* `$menuTitle` *(string)* — The default menu title (`'FluentCart'`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(string)* — The modified menu title

#### Usage Example:
```php
// Filter WordPress admin menu title string
add_filter('fluent_cart/admin_menu_title', function ($menuTitle, $data) {
    // Change admin sidebar menu label to My Store
    return 'My Store';
}, 10, 2);
```

---

### `admin_menu_position`
`fluent_cart/admin_menu_position` — Filter admin menu position

* **When it runs:** This filter is applied when registering the admin menu, controlling its position in the WordPress sidebar.
* **Source:** `app/Hooks/Handlers/MenuHandler.php` (line 173)

#### Parameters:
* `$position` *(int)* — The menu position (default: `3`)
* **Returns:** *(int)* — The modified menu position

#### Usage Example:
```php
// Filter WordPress admin menu position integer
add_filter('fluent_cart/admin_menu_position', function ($position) {
    // Move FluentCart menu position lower in the sidebar
    return 25;
});
```

---

### `admin_filter_options`
`fluent_cart/admin_filter_options` — Filter admin filter options for list pages

* **When it runs:** This filter is applied when loading admin filter options for orders, customers, products, licenses, and tax list pages.
* **Source:** `app/Hooks/Handlers/MenuHandler.php` (line 380)

#### Parameters:
* `$filterOptions` *(array)* — Filter configurations for each list page (`order_filter_options`, `customer_filter_options`, etc.)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified filter options array

#### Usage Example:
```php
// Filter admin list page filter options for orders, customers, etc.
add_filter('fluent_cart/admin_filter_options', function ($filterOptions, $data) {
    // Add a custom status filter option to the orders list
    $filterOptions['order_filter_options']['custom_status'] = [
        'label'   => 'Custom Status',
        'type'    => 'select',
        'options' => ['pending', 'approved'],
    ];
    return $filterOptions;
}, 10, 2);
```

---

### `admin_app_data`
`fluent_cart/admin_app_data` — Filter admin Vue app localized data

* **When it runs:** This filter is applied when loading the admin SPA, providing the full configuration object passed to the Vue application via `wp_localize_script`.
* **Source:** `app/Hooks/Handlers/MenuHandler.php` (line 398)

#### Parameters:
* `$adminLocalizeData` *(array)* — The complete admin app data (`app_config`, `admin_url`, `rest`, `me`, `shop`, `trans`, etc.)
* **Returns:** *(array)* — The modified admin app data

#### Usage Example:
```php
// Filter localized configuration data passed to Vue admin SPA
add_filter('fluent_cart/admin_app_data', function ($adminLocalizeData) {
    // Inject custom settings data into the Vue admin app payload
    $adminLocalizeData['custom_setting'] = 'custom_value';
    $adminLocalizeData['my_plugin_config'] = [
        'enabled' => true,
        'api_url' => 'https://api.example.com',
    ];
    return $adminLocalizeData;
});
```

---

### `admin_notices`
`fluent_cart/admin_notices` — Filter admin notices

* **When it runs:** This filter is applied when loading the admin interface, allowing plugins to inject notices that display in the FluentCart admin panel.
* **Source:** `app/Hooks/Handlers/MenuHandler.php` (line 449)

#### Parameters:
* `$notices` *(array)* — Array of notice objects (default: `[]`)
* **Returns:** *(array)* — The modified notices array

#### Usage Example:
```php
// Filter admin notices array displayed in FluentCart panel
add_filter('fluent_cart/admin_notices', function ($notices) {
    // Inject a custom warning notice into admin panel
    $notices[] = [
        'type'    => 'warning',
        'message' => 'Please configure your payment gateway before going live.',
    ];
    return $notices;
});
```

---

### `admin_base_url`
`fluent_cart/admin_base_url` — Filter admin base URL

* **When it runs:** This filter is applied when constructing admin navigation URLs throughout the plugin, including product menus and global navigation items.
* **Source:** `app/Helpers/AdminHelper.php` (line 22)

#### Parameters:
* `$baseUrl` *(string)* — The default admin base URL (`admin_url('admin.php?page=fluent-cart#/')`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(string)* — The modified base URL

#### Usage Example:
```php
// Filter admin base URL used for navigation links
add_filter('fluent_cart/admin_base_url', function ($baseUrl, $data) {
    // Use custom admin base URL
    return admin_url('admin.php?page=my-custom-cart#/');
}, 10, 2);
```

---

### `product_admin_items`
`fluent_cart/product_admin_items` — Filter admin product action menu items

* **When it runs:** This filter is applied when rendering the product action menu in the admin product detail view. Use it to add custom navigation tabs to individual product pages.
* **Source:** `app/Helpers/AdminHelper.php` (line 24)

#### Parameters:
* `$menuItems` *(array)* — Array of menu item definitions (`product_edit`, `product_upgrade_paths`, `product_integrations`, etc.)
* `$context` *(array)* — Context data (`['product_id' => 123, 'base_url' => '...']`)
* **Returns:** *(array)* — The modified menu items array

#### Usage Example:
```php
// Filter admin product action menu items in product detail view
add_filter('fluent_cart/product_admin_items', function ($menuItems, $context) {
    // Extract product ID and base URL from context array
    $productId = $context['product_id'];
    $baseUrl = $context['base_url'];

    // Add a custom Analytics tab to individual product menu
    $menuItems['product_analytics'] = [
        'label' => 'Analytics',
        'link'  => $baseUrl . 'products/' . $productId . '/analytics',
    ];
    return $menuItems;
}, 10, 2);
```

---

### `global_admin_menu_items`
`fluent_cart/global_admin_menu_items` — Filter global admin navigation menu

* **When it runs:** This filter is applied when rendering the global admin navigation bar at the top of the FluentCart admin pages. Use it to add or modify top-level navigation items.
* **Source:** `app/Helpers/AdminHelper.php` (line 80)

#### Parameters:
* `$menuItems` *(array)* — Array of navigation items (`dashboard`, `orders`, `customers`, `products`, etc.)
* **Returns:** *(array)* — The modified menu items array

#### Usage Example:
```php
// Filter global admin navigation menu items
add_filter('fluent_cart/global_admin_menu_items', function ($menuItems) {
    // Add a custom top-level navigation item for Custom Reports
    $menuItems['custom_reports'] = [
        'label'      => 'Custom Reports',
        'link'       => admin_url('admin.php?page=fluent-cart#/custom-reports'),
        'permission' => ['reports/view'],
    ];
    return $menuItems;
});
```

---

### `dummy_product_info`
`fluent_cart/dummy_product_info` — Filter dummy product for onboarding

* **When it runs:** This filter is applied when loading the admin app data. It provides dummy product information used during the onboarding flow when the store has no products yet.
* **Source:** `app/Hooks/Handlers/MenuHandler.php` (line 435)

#### Parameters:
* `$dummyProduct` *(array)* — Dummy product info (default: `[]`)
* **Returns:** *(array)* — The modified dummy product info

#### Usage Example:
```php
// Filter dummy product info used during onboarding flow
add_filter('fluent_cart/dummy_product_info', function ($dummyProduct) {
    // Return custom dummy product data structure
    return [
        'title' => 'Sample Digital Product',
        'price' => 2999, // in cents
        'type'  => 'digital',
    ];
});
```

---

### `storage_driver_settings_routes`
`fluent_cart/storage/storage_driver_settings_routes` — Filter storage driver admin routes

* **When it runs:** This filter is applied when loading the admin app, allowing storage driver plugins to register their settings routes in the admin SPA navigation.
* **Source:** `app/Hooks/Handlers/MenuHandler.php` (line 367)

#### Parameters:
* `$routes` *(array)* — Array of storage driver route definitions (default: `[]`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified routes array

#### Usage Example:
```php
// Filter storage driver admin settings routes in SPA
add_filter('fluent_cart/storage/storage_driver_settings_routes', function ($routes, $data) {
    // Register custom S3 storage driver settings route
    $routes[] = [
        'key'   => 's3_storage',
        'title' => 'S3 Storage',
        'route' => 'settings/storage/s3',
    ];
    return $routes;
}, 10, 2);
```

---

## Permissions & Auth

### `permission/all_roles`
`fluent_cart/permission/all_roles` — Filter permission roles

* **When it runs:** This filter is applied when retrieving all available permission roles. FluentCart ships with four roles (`super_admin`, `manager`, `worker`, `accountant`), each with predefined permission sets.
* **Source:** `app/Services/Permission/PermissionManager.php` (line 92)

#### Parameters:
* `$allRoles` *(array)* — Array of role definitions (`super_admin`, `manager`, `worker`, `accountant`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified roles array

#### Usage Example:
```php
// Filter permission roles definition array
add_filter('fluent_cart/permission/all_roles', function ($allRoles, $data) {
    // Add a custom Support Agent role with specific permissions
    $allRoles['support_agent'] = [
        'title'        => 'Support Agent',
        'descriptions' => 'View orders and customers, manage order statuses',
        'permissions'  => [
            'orders/view',
            'orders/manage_statuses',
            'customers/view',
        ],
    ];
    return $allRoles;
}, 10, 2);
```

---

## Translations

### `admin_translations`
`fluent_cart/admin_translations` — Filter admin panel translations

* **When it runs:** This filter is applied when loading translation strings for the admin Vue SPA. The translations are passed to the frontend as a localized JavaScript object.
* **Source:** `app/Services/Translations/TransStrings.php` (line 9)

#### Parameters:
* `$translations` *(array)* — Key-value pairs of translation strings loaded from `admin-translation.php`
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified translations array

#### Usage Example:
```php
// Filter translation strings for Vue admin SPA
add_filter('fluent_cart/admin_translations', function ($translations, $data) {
    // Override custom admin label translation
    $translations['custom_label'] = __('My Custom Label', 'my-plugin');
    return $translations;
}, 10, 2);
```

---

### `blocks_translations`
`fluent_cart/blocks_translations` — Filter block editor translations

* **When it runs:** This filter is applied when loading translation strings for the FluentCart block editor interface.
* **Source:** `app/Services/Translations/TransStrings.php` (line 15)

#### Parameters:
* `$translations` *(array)* — Key-value pairs of translation strings loaded from `block-editor-translation.php`
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified translations array

#### Usage Example:
```php
// Filter translation strings for email block editor
add_filter('fluent_cart/blocks_translations', function ($translations, $data) {
    // Override Save translation label
    $translations['Save'] = __('Save Changes', 'my-plugin');
    return $translations;
}, 10, 2);
```

---

### `customer_profile_translations`
`fluent_cart/customer_profile_translations` — Filter customer profile translations

* **When it runs:** This filter is applied when loading translation strings for the customer profile (My Account) frontend page.
* **Source:** `app/Services/Translations/TransStrings.php` (line 87)

#### Parameters:
* `$translations` *(array)* — Key-value pairs of translation strings loaded from `customer-profile-translation.php`
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified translations array

#### Usage Example:
```php
// Filter customer profile (My Account) frontend translation strings
add_filter('fluent_cart/customer_profile_translations', function ($translations, $data) {
    // Customize My Orders heading translation
    $translations['My Orders'] = __('Purchase History', 'my-plugin');
    return $translations;
}, 10, 2);
```

---

### `checkout_translations`
`fluent_cart/checkout_translations` — Filter checkout page translations

* **When it runs:** This filter is applied when loading translation strings for the checkout page frontend.
* **Source:** `app/Services/Translations/TransStrings.php` (line 101)

#### Parameters:
* `$translations` *(array)* — Key-value pairs of translation strings loaded from `checkout-translation.php`
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified translations array

#### Usage Example:
```php
// Filter checkout page frontend translation strings
add_filter('fluent_cart/checkout_translations', function ($translations, $data) {
    // Customize Place Order button label
    $translations['Place Order'] = __('Complete Purchase', 'my-plugin');
    return $translations;
}, 10, 2);
```

---

### `payments_translations`
`fluent_cart/payments_translations` — Filter payment translations

* **When it runs:** This filter is applied when loading translation strings for payment-related UI elements on the frontend.
* **Source:** `app/Services/Translations/TransStrings.php` (line 107)

#### Parameters:
* `$translations` *(array)* — Key-value pairs of translation strings loaded from `payments-translation.php`
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified translations array

#### Usage Example:
```php
// Filter payment frontend translation strings
add_filter('fluent_cart/payments_translations', function ($translations, $data) {
    // Customize Credit Card gateway option label
    $translations['Credit Card'] = __('Debit/Credit Card', 'my-plugin');
    return $translations;
}, 10, 2);
```

---

### `pro/admin_translations` (Pro)
`fluent_cart_pro/admin_translations` — Filter Pro admin translations

* **When it runs:** This filter is applied when loading translation strings specific to FluentCart Pro features in the admin panel.
* **Source:** `fluent-cart-pro/app/Services/Translations/Translations.php` (line 24)

#### Parameters:
* `$translations` *(array)* — Key-value pairs of Pro-specific translation strings
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified translations array

#### Usage Example:
```php
// Filter Pro admin translation strings
add_filter('fluent_cart_pro/admin_translations', function ($translations, $data) {
    // Override Pro License Management menu label
    $translations['License Management'] = __('License Keys', 'my-plugin');
    return $translations;
}, 10, 2);
```

---

## Email & Notifications

### `email_notifications`
`fluent_cart/email_notifications` — Filter email notification settings

* **When it runs:** This filter is applied when retrieving the list of available email notifications. Each notification includes its configuration such as recipients, subject template, and default body. Runs before merging with saved notification configs.
* **Source:** `app/Services/Email/EmailNotifications.php` (line 24)

#### Parameters:
* `$settings` *(array)* — Associative array of notification definitions keyed by notification name
* **Returns:** *(array)* — The modified notification settings array

#### Usage Example:
```php
// Filter email notification settings array
add_filter('fluent_cart/email_notifications', function ($settings) {
    // Register a custom email notification definition
    $settings['custom_notification'] = [
        'title'       => 'Custom Alert',
        'group_label' => 'Custom Actions',
        'settings'    => [
            'subject'         => 'Custom Alert for Order #{order.id}',
            'email_body'      => '',
            'is_default_body' => 'yes',
            'to'              => '{{settings.admin_email}}',
            'status'          => 'active',
        ],
    ];
    return $settings;
});
```

---

### `keep_email_body_draft`
`fluent_cart/keep_email_body_draft` — Filter whether to prevent email body reset

* **When it runs:** This filter is applied when a notification is switched back to its default body. By default, the custom email body is cleared. Return true to preserve the custom body as a draft.
* **Source:** `app/Services/Email/EmailNotifications.php` (line 520)

#### Parameters:
* `$keepDraft` *(bool)* — Whether to keep the custom body as draft (default: `false`)
* `$context` *(array)* — The notification context (`['notification_name' => 'order_completed']`)
* **Returns:** *(bool)* — Whether to preserve the custom email body

#### Usage Example:
```php
// Filter whether to prevent custom email body reset when reverting to default
add_filter('fluent_cart/keep_email_body_draft', function ($keepDraft, $context) {
    // Always preserve custom email bodies as drafts
    return true;
}, 10, 2);
```

---

### `theme_pref`
`fluent_cart/theme_pref` — Filter email template theme preferences

* **When it runs:** This filter is applied when the block parser resolves the email theme preferences, including the color palette and font sizes used in email templates.
* **Source:** `app/Services/Email/FluentBlockParser.php` (line 1997)

#### Parameters:
* `$pref` *(array)* — Theme preference settings (`colors`, `font_sizes`)
* **Returns:** *(array)* — The modified theme preferences

#### Usage Example:
```php
// Filter email template theme preferences for block parser
add_filter('fluent_cart/theme_pref', function ($pref) {
    // Add brand custom color option to email palette
    $pref['colors'][] = [
        'name'  => 'Brand Primary',
        'slug'  => 'brand-primary',
        'color' => '#FF6600',
    ];
    return $pref;
});
```

---

### `condition_presets`
`fluent_cart/condition_presets` — Filter email condition presets

* **When it runs:** This filter is applied when retrieving available condition presets for email template conditional blocks. Presets define reusable conditions like "has note" or "has downloads" that control block visibility.
* **Source:** `app/Services/Email/ConditionPresets.php` (line 124)

#### Parameters:
* `$presets` *(array)* — Array of condition preset definitions (`has_order_note`, `has_downloads`, etc.)
* **Returns:** *(array)* — The modified presets array

#### Usage Example:
```php
// Filter email condition presets list
add_filter('fluent_cart/condition_presets', function ($presets) {
    // Add a custom High Value Order condition preset
    $presets[] = [
        'id'           => 'is_high_value',
        'label'        => 'High Value Order',
        'hint'         => 'Show when order total exceeds $100.',
        'shortcode'    => '{{order.total_amount}}',
        'condition'    => 'greater_than',
        'compareValue' => '10000', // in cents
    ];
    return $presets;
});
```

---

### `evaluate_condition_preset`
`fluent_cart/evaluate_condition_preset` — Filter evaluate condition preset

* **When it runs:** This filter is applied when evaluating a condition preset that has no shortcode and no callback defined. It serves as a fallback for custom condition evaluation logic.
* **Source:** `app/Services/Email/Blocks/BaseBlock.php` (line 196)

#### Parameters:
* `$result` *(bool)* — The evaluation result (default: `false`)
* `$context` *(array)* — Full context for evaluation (`preset`, `resolved`, `data`, `block_attrs`)
* **Returns:** *(bool)* — Whether the condition is met

#### Usage Example:
```php
// Filter evaluation of custom condition presets without built-in shortcodes
add_filter('fluent_cart/evaluate_condition_preset', function ($result, $context) {
    // Extract preset array and order model
    $preset = $context['preset'];
    if ($preset && $preset['id'] === 'my_custom_condition') {
        $order = $context['data']['order'] ?? null;
        return $order && $order->total_amount > 10000;
    }
    return $result;
}, 10, 2);
```

---

### `confirmation_shortcodes`
`fluent_cart/confirmation_shortcodes` — Filter confirmation page shortcodes

* **When it runs:** This filter is applied when retrieving available shortcodes for the order confirmation (receipt) page template editor.
* **Source:** `app/Helpers/EditorShortCodeHelper.php` (line 201)

#### Parameters:
* `$groups` *(array)* — Array of shortcode groups (`customer`, `order`, `general`, `settings`)
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(array)* — The modified shortcode groups array

#### Usage Example:
```php
// Filter available shortcodes for order confirmation (receipt) page template editor
add_filter('fluent_cart/confirmation_shortcodes', function ($groups, $data) {
    // Add a custom shortcode group for tracking URLs
    $groups[] = [
        'title'      => 'Custom Data',
        'key'        => 'custom',
        'shortcodes' => [
            '{{custom.tracking_url}}' => 'Tracking URL',
        ],
    ];
    return $groups;
}, 10, 2);
```

---

### `editor_shortcodes`
`fluent_cart/editor_shortcodes` — Filter email editor shortcodes

* **When it runs:** This filter is applied when retrieving available shortcodes for the email notification template editor. Includes order, general, customer, transaction, settings, and license shortcode groups.
* **Source:** `app/Helpers/EditorShortCodeHelper.php` (line 277)

#### Parameters:
* `$shortCodes` *(array)* — Associative array of shortcode groups (`order`, `general`, `customer`, `transaction`, `settings`, `license`)
* **Returns:** *(array)* — The modified shortcodes array

#### Usage Example:
```php
// Filter available shortcodes for email notification template editor
add_filter('fluent_cart/editor_shortcodes', function ($shortCodes) {
    // Add custom shortcode group for loyalty points and referral codes
    $shortCodes['custom'] = [
        'title'      => 'Custom Fields',
        'key'        => 'custom',
        'shortcodes' => [
            '{{custom.loyalty_points}}' => 'Loyalty Points',
            '{{custom.referral_code}}'  => 'Referral Code',
        ],
    ];
    return $shortCodes;
});
```

---

### `disable_email_celebration_messages`
`fluent_cart/disable_email_celebration_messages` — Filter whether to disable celebration messages in admin emails

* **When it runs:** This filter is applied when generating admin notification emails. By default, FluentCart adds a random celebration message (e.g., "Woo-Hoo! Another Sale!") to admin order emails.
* **Source:** `app/Services/TemplateService.php` (line 114)

#### Parameters:
* `$disable` *(bool)* — Whether to disable celebration messages (default: `false`)
* `$context` *(array)* — The notification type context (`['type' => 'order']`)
* **Returns:** *(bool)* — Whether to disable the celebration messages

#### Usage Example:
```php
// Filter whether to disable random celebration messages in admin notification emails
add_filter('fluent_cart/disable_email_celebration_messages', function ($disable, $context) {
    // Disable celebration header messages for all admin emails
    return true;
}, 10, 2);
```

---

## Block Editor

### `block_editor_require_nonce`
`fluent_cart/block_editor_require_nonce` — Filter whether the block editor requires nonce verification

* **When it runs:** This filter is applied when loading the FluentCart block editor (email template editor). It controls whether nonce verification is enforced for editor access.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 54)

#### Parameters:
* `$requireNonce` *(bool)* — Whether to require nonce (default: `true`)
* `$blockType` *(string)* — The block editor type being loaded
* `$request` *(array)* — The current request data
* **Returns:** *(bool)* — Whether to enforce nonce verification

#### Usage Example:
```php
// Filter whether block editor requires nonce verification
add_filter('fluent_cart/block_editor_require_nonce', function ($requireNonce, $blockType, $request) {
    // Disable nonce for specific preview block types if needed
    if ($blockType === 'preview') {
        return false;
    }
    return $requireNonce;
}, 10, 3);
```

---

### `disable_pro_email_templates`
`fluent_cart/disable_pro_email_templates` — Filter whether to disable Pro email templates

* **When it runs:** This filter is applied when loading starter templates in the email block editor. When true, templates with `/pro` or `/modern` in their IDs are excluded from the template picker.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 230)

#### Parameters:
* `$disable` *(bool)* — Whether to disable Pro templates (default: `true`)
* **Returns:** *(bool)* — Whether to filter out Pro email templates

#### Usage Example:
```php
// Filter whether to disable Pro email starter templates
add_filter('fluent_cart/disable_pro_email_templates', function ($disable) {
    // Enable Pro email templates when Pro plugin is active
    if (defined('FLUENT_CART_PRO')) {
        return false;
    }
    return $disable;
});
```

---

### `skip_no_conflict` (editor)
`fluent_cart_editor/skip_no_conflict` — Filter whether to skip script unloading in the block editor

* **When it runs:** This filter is applied when the email block editor loads. FluentCart aggressively unloads third-party scripts to prevent conflicts. Return true to skip this behavior and allow all scripts.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 638)

#### Parameters:
* `$skip` *(bool)* — Whether to skip no-conflict mode (default: `false`)
* **Returns:** *(bool)* — Whether to skip unloading third-party scripts

#### Usage Example:
```php
// Filter whether to skip third-party script unloading in block editor
add_filter('fluent_cart_editor/skip_no_conflict', function ($skip) {
    // Allow third-party scripts in the block editor
    return true;
});
```

---

### `asset_listed_slugs` (editor)
`fluent_cart_editor/asset_listed_slugs` — Filter approved script slugs in block editor

* **When it runs:** This filter is applied when unloading third-party scripts from the email block editor. Only scripts matching these slug patterns (regex) will be kept.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 650)

#### Parameters:
* `$approvedSlugs` *(array)* — Array of regex slug patterns to keep (`['\/gutenberg\/']`)
* **Returns:** *(array)* — The modified approved slugs array

#### Usage Example:
```php
// Filter approved script slug regex patterns in block editor
add_filter('fluent_cart_editor/asset_listed_slugs', function ($approvedSlugs) {
    // Allow scripts from a specific custom plugin
    $approvedSlugs[] = '\/my-custom-plugin\/';
    return $approvedSlugs;
});
```

---

### `skip_no_conflict` (styles)
`fluent_cart/skip_no_conflict` — Filter whether to skip style unloading in the block editor

* **When it runs:** This filter is applied when unloading third-party stylesheets from the email block editor. Return true to allow all styles to load without filtering.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 707)

#### Parameters:
* `$skip` *(bool)* — Whether to skip no-conflict mode for styles (default: `false`)
* `$type` *(string)* — The asset type (`'styles'`)
* **Returns:** *(bool)* — Whether to skip unloading third-party styles

#### Usage Example:
```php
// Filter whether to skip third-party stylesheet unloading in block editor
add_filter('fluent_cart/skip_no_conflict', function ($skip, $type) {
    // Skip stylesheet unloading for styles asset type
    if ($type === 'styles') {
        return true;
    }
    return $skip;
}, 10, 2);
```

---

### `asset_listed_slugs` (styles)
`fluent_cart/asset_listed_slugs` — Filter approved style slugs in block editor

* **When it runs:** This filter is applied when filtering third-party stylesheets from the email block editor. Only styles matching these slug patterns (regex) will be kept.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 720)

#### Parameters:
* `$approvedSlugs` *(array)* — Array of regex slug patterns to keep (`['\/gutenberg\/']`)
* **Returns:** *(array)* — The modified approved slugs array

#### Usage Example:
```php
// Filter approved stylesheet slug regex patterns in block editor
add_filter('fluent_cart/asset_listed_slugs', function ($approvedSlugs) {
    // Allow custom plugin stylesheets in block editor
    $approvedSlugs[] = '\/my-custom-plugin\/';
    return $approvedSlugs;
});
```

---

### `block_editor_unregister_all_patterns`
`fluent_cart/block_editor_unregister_all_patterns` — Filter whether to unregister default block patterns

* **When it runs:** This filter is applied when loading the email block editor. By default, all WordPress core block patterns are removed since they are designed for web pages, not emails.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 740)

#### Parameters:
* `$shouldUnregister` *(bool)* — Whether to unregister patterns (default: `true`)
* `$context` *(string)* — The editor context
* `$data` *(array)* — Additional context data (empty array)
* **Returns:** *(bool)* — Whether to unregister default block patterns

#### Usage Example:
```php
// Filter whether to unregister default block patterns in the email editor
add_filter('fluent_cart/block_editor_unregister_all_patterns', function ($shouldUnregister, $context, $data) {
    // Retain default WordPress block patterns in the editor
    return false;
}, 10, 3);
```
