# FluentCart Action Hooks — Complete Reference

# Action Hooks: Admin & Templates

All hooks related to plugin boot/initialization, admin UI, modules, the block/email editor, form rendering, page templating, shortcode-driven views, policy verification, and custom web routes.

---

## Boot / Initialization
Fired during plugin startup. These are the earliest FluentCart hooks and let you tap into the container before any other logic runs.

### `fluentcart_loaded`
`fluentcart_loaded` — Plugin application container loaded (first hook)

* **When it runs:** Fires inside the `plugins_loaded` WordPress hook, immediately after the FluentCart Application container is constructed and the Action Scheduler is loaded. This is the very first FluentCart hook — use it to register early bindings, service providers, or listeners before anything else initialises.
* **Source:** `boot/app.php` (line 30)

#### Parameters:
* `$app` *(\FluentCart\Framework\Foundation\Application)* — The FluentCart application container instance

#### Usage Example:
```php
// Hook into plugin application container load (earliest hook)
add_action('fluentcart_loaded', function ($app) {
    // Register a custom service into the FluentCart container early
    $app->bind('myCustomService', function () {
        return new \MyPlugin\CustomService();
    });
}, 10, 1);
```

---

### `fluent_cart/init`
`fluent_cart/init` — FluentCart fully initialised on WP init

* **When it runs:** Fires inside the WordPress `init` hook (which itself runs after `plugins_loaded`). By this point, all post types, taxonomies, and rewrite rules are available. Use this for logic that depends on WordPress being fully bootstrapped — custom post type queries, REST route registration, etc.
* **Source:** `boot/app.php` (line 35)

#### Parameters:
* `$app` *(\FluentCart\Framework\Foundation\Application)* — The FluentCart application container instance

#### Usage Example:
```php
// Hook when FluentCart is fully initialised on WP init
add_action('fluent_cart/init', function ($app) {
    // Safe to query custom post types or register custom REST routes
    register_rest_route('my-plugin/v1', '/data', [
        'methods'  => 'GET',
        'callback' => 'my_custom_handler',
    ]);
}, 10, 1);
```

---

## Admin
Hooks that fire during admin page rendering, menu setup, and asset enqueueing. Use these to extend the FluentCart admin panel.

### `admin_menu`
`fluent_cart/admin_menu` — Render admin navigation menu

* **When it runs:** Fires in two places: inside the admin Vue SPA wrapper (`admin_app.php`) and on the product CPT taxonomy pages. It is the hook that renders the FluentCart admin navigation bar. The default handler (`MenuHandler::renderAdminMenu`) is attached to it to output the menu HTML.
* **Parameters:** None — this is a rendering hook. Callbacks should `echo` HTML.
* **Source:** `app/CPT/FluentProducts.php` (line 333), `app/Views/admin/admin_app.php` (line 4)

#### Usage Example:
```php
// Hook to render elements inside FluentCart admin navigation menu
add_action('fluent_cart/admin_menu', function () {
    // Append a custom link to the admin navigation bar HTML
    echo '<a href="#/my-custom-page" class="fct-nav-item">My Page</a>';
}, 20);
```

---

### `admin_submenu_added`
`fluent_cart/admin_submenu_added` — After all admin submenus registered

* **When it runs:** Fires at the end of `MenuHandler::addAdminMenu()`, after all default submenu items (Dashboard, Orders, Customers, Products, Integrations, Reports, Settings, Coupons, Logs, and taxonomy pages) have been registered under the FluentCart admin menu.
* **Source:** `app/Hooks/Handlers/MenuHandler.php` (line 283)

#### Parameters:
`$submenu` *(array)*: The WordPress global `$submenu` array (keyed by parent slug). The `fluent-cart` key contains all FluentCart submenu items.

#### Usage Example:
```php
// Hook after all default FluentCart admin submenus are registered
add_action('fluent_cart/admin_submenu_added', function ($submenu) {
    // Add a custom submenu item programmatically to WordPress global $submenu
    global $submenu;
    $submenu['fluent-cart']['my_page'] = [
        __('My Custom Page', 'my-plugin'),
        'manage_options',
        'admin.php?page=fluent-cart#/my-custom',
    ];
}, 10, 1);
```

---

### `loading_app`
`fluent_cart/loading_app` — Admin Vue SPA assets about to be enqueued

* **When it runs:** Fires at the very beginning of `MenuHandler::enqueueAssets()`, before any admin JavaScript or CSS is registered. Use this to enqueue your own scripts or styles that need to load alongside (or before) the admin SPA.
* **Source:** `app/Hooks/Handlers/MenuHandler.php` (line 355)

#### Parameters:
* `$app` *(\FluentCart\Framework\Foundation\Application)* — The FluentCart application container instance

#### Usage Example:
```php
// Hook before FluentCart admin Vue SPA assets are enqueued
add_action('fluent_cart/loading_app', function ($app) {
    // Enqueue a custom admin stylesheet before the SPA loads
    wp_enqueue_style('my-fct-admin-style', plugins_url('css/admin.css', __FILE__));
}, 10, 1);
```

---

### `admin_js_loaded`
`fluent_cart/admin_js_loaded` — After all admin JS enqueued and localised

* **When it runs:** Fires at the end of `MenuHandler::enqueueAssets()`, after all admin scripts have been enqueued and `wp_localize_script` has injected the `fluentCartAdminApp` and `fluentCartRestVars` objects. Use this to enqueue scripts that depend on the admin SPA data being available, or to add inline script data.
* **Source:** `app/Hooks/Handlers/MenuHandler.php` (line 465)

#### Parameters:
* `$app` *(\FluentCart\Framework\Foundation\Application)* — The FluentCart application container instance

#### Usage Example:
```php
// Hook after all admin JS is enqueued and localized
add_action('fluent_cart/admin_js_loaded', function ($app) {
    // Enqueue a script that depends on the admin app being fully loaded
    wp_enqueue_script('my-fct-addon', plugins_url('js/addon.js', __FILE__), [], '1.0', true);

    // Add inline data that references fluentCartAdminApp
    wp_add_inline_script('my-fct-addon', 'window.myAddonConfig = { ready: true };', 'before');
}, 10, 1);
```

---

## Modules
Hooks that fire when built-in FluentCart modules (e.g. stock management, subscriptions, shipping) are activated or deactivated via the admin settings panel.

### `module/deactivated/{module_key}`
`fluent_cart/module/deactivated/{$moduleKey}` — Module deactivated (dynamic)

* **When it runs:** Fires inside `ModuleSettingsController::saveSettings()` when a module's active status transitions from `'yes'` to `'no'`. The `{$moduleKey}` portion is replaced dynamically with the module identifier.
* **Available dynamic variants:** `stock_management`, `subscriptions`, `shipping`, `tax`, `coupon`, `license`, `digital_downloads`, and any other registered module key.
* **Source:** `app/Http/Controllers/ModuleSettingsController.php` (line 58)

#### Parameters:
* `$moduleData` *(array)* — The newly saved settings for this module (`['active' => 'no', ...]`)
* `$prevModuleData` *(array)* — The previous settings for this module before the save (`['active' => 'yes', ...]`)

#### Usage Example:
```php
// Hook when stock management module is deactivated
add_action('fluent_cart/module/deactivated/stock_management', function ($moduleData, $prevModuleData) {
    // Clean up stock-related cron jobs when stock management is turned off
    as_unschedule_all_actions('fluent_cart/stock_check');
}, 10, 2);
```

---

### `module/activated/{module_key}`
`fluent_cart/module/activated/{$moduleKey}` — Module activated (dynamic)

* **When it runs:** Fires inside `ModuleSettingsController::saveSettings()` when a module's active status transitions from `'no'` to `'yes'`. The `{$moduleKey}` portion is replaced dynamically with the module identifier.
* **Available dynamic variants:** `stock_management`, `subscriptions`, `shipping`, `tax`, `coupon`, `license`, `digital_downloads`, and any other registered module key.
* **Source:** `app/Http/Controllers/ModuleSettingsController.php` (line 61)

#### Parameters:
* `$moduleData` *(array)* — The newly saved settings for this module (`['active' => 'yes', ...]`)
* `$prevModuleData` *(array)* — The previous settings for this module before the save (`['active' => 'no', ...]`)

#### Usage Example:
```php
// Hook when subscriptions module is activated
add_action('fluent_cart/module/activated/subscriptions', function ($moduleData, $prevModuleData) {
    // Run database migrations when subscriptions module is first activated
    \FluentCart\Database\DBMigrator::run('subscription_tables');
}, 10, 2);
```

---

## Block Editor / Email Editor
Hooks for the custom FluentCart block editor used to compose email templates. These fire during the editor page lifecycle and asset loading.

### `fluent_cart_enqueue_block_editor_assets`
`fluent_cart_enqueue_block_editor_assets` — Block editor assets being enqueued

* **When it runs:** Fires at the end of `FluentCartBlockEditorHandler::enqueueEditorStyles()`, after all core WordPress block editor styles (`wp-edit-post`, `wp-block-library`, etc.) have been enqueued. WordPress's own `wp_enqueue_editor_format_library_assets` is also attached to this hook. Use it to add custom styles or scripts to the email block editor.
* **Parameters:** None.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 428)

#### Usage Example:
```php
// Hook when email block editor assets are enqueued
add_action('fluent_cart_enqueue_block_editor_assets', function () {
    // Add custom styles for the email block editor page
    wp_enqueue_style('my-email-editor-styles', plugins_url('css/email-editor.css', __FILE__));
}, 10);
```

---

### `fluent_cart_block_editor/head`
`fluent_cart_block_editor/head` — In `<head>` of custom block editor page

* **When it runs:** Fires inside the `<head>` tag of the custom block editor HTML page. WordPress core hooks (`wp_enqueue_scripts`, `wp_print_styles`, `wp_print_head_scripts`, etc.) are pre-attached to this action so that editor stylesheets and scripts are output in the correct location. Use this to inject additional `<meta>`, `<link>`, or `<style>` tags into the editor page head.
* **Parameters:** None.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 620)

#### Usage Example:
```php
// Hook inside head tag of custom block editor page
add_action('fluent_cart_block_editor/head', function () {
    // Print a self-hosted editor stylesheet tag (point the href at your own asset path)
    echo '<link rel="stylesheet" href="/wp-content/uploads/editor-fonts.css">';
}, 20);
```

---

### `block_editor_head`
`fluent_cart/block_editor_head` — Second head hook in block editor page

* **When it runs:** Fires immediately after `fluent_cart_block_editor/head` inside the `<head>` tag, right before the closing `</head>`. This is a secondary head hook — use it for last-minute style overrides or scripts that must load after everything else in the head.
* **Parameters:** None.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 622)

#### Usage Example:
```php
// Secondary head hook right before closing head tag in block editor
add_action('fluent_cart/block_editor_head', function () {
    // Override editor font family styles as final head injection
    echo '<style>.editor-styles-wrapper { font-family: "Inter", sans-serif; }</style>';
}, 10);
```

---

### `new_block_editor_footer`
`fluent_cart/new_block_editor_footer` — Footer of custom block editor page (for JS)

* **When it runs:** Fires inside the `<body>` of the custom block editor page, after the editor `<div>` and before `</body>`. This is the recommended place to inject footer JavaScript for the email editor.
* **Parameters:** None.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 629)

#### Usage Example:
```php
// Hook inside body of custom block editor page before closing body tag
add_action('fluent_cart/new_block_editor_footer', function () {
    // Inject custom JavaScript into email editor page footer
    echo '<script>console.log("FluentCart email editor loaded");</script>';
}, 10);
```

---

### `block_editor/enqueue_assets`
`fluent_cart/block_editor/enqueue_assets` — After email editor block assets enqueued

* **When it runs:** Fires at the end of `FluentCartBlockEditorHandler::enqueueEmailEditorBlocks()`, after all FluentCart-specific email editor block scripts, styles, and global editor SCSS have been enqueued. Use this to register additional custom blocks or scripts for the email editor.
* **Parameters:** None.
* **Source:** `app/Hooks/Handlers/FluentCartBlockEditorHandler.php` (line 1232)

#### Usage Example:
```php
// Hook after email editor block scripts and styles are enqueued
add_action('fluent_cart/block_editor/enqueue_assets', function () {
    // Register custom email block script for editor
    wp_enqueue_script('my-email-block', plugins_url('js/my-email-block.js', __FILE__), ['wp-blocks'], '1.0', true);
}, 10);
```

---

### `block_editor/render_block`
`fluent_cart/block_editor/render_block` — Render unknown block types in email parser

* **When it runs:** Fires inside `FluentBlockParser` when processing a block whose name is not recognised by any built-in handler and is not a standard email editor block. The hook runs inside `ob_start()` — any output you echo will be captured and used as the block's rendered HTML in the email. If nothing is output, the parser falls back to raw innerHTML.
* **Source:** `app/Services/Email/FluentBlockParser.php` (line 278)

#### Parameters:
`$data` *(array)*: Block rendering context
```php
$data = [
    'block'      => [...],        // array — Full block array (name, attrs, innerBlocks, innerHTML, etc.)
    'block_name' => 'my/custom',  // string — The block type name string
    'attributes' => [...],        // array — Block attributes array
];
```

#### Usage Example:
```php
// Hook to render unrecognized block types in email parser
add_action('fluent_cart/block_editor/render_block', function ($data) {
    // Check block type name match
    if ($data['block_name'] === 'my-plugin/promo-banner') {
        $heading = $data['attributes']['heading'] ?? 'Special Offer';
        // Echo rendered HTML for custom promo banner block
        echo '<div style="background: #f0f0f0; padding: 20px; text-align: center;">';
        echo '<h2>' . esc_html($heading) . '</h2>';
        echo '</div>';
    }
}, 10, 1);
```

---

## Form Rendering

### `render_custom_form_field`
`fluent_cart/render_custom_form_field` — Unrecognised form field type fallback

* **When it runs:** Fires inside the `default` case of `FormFieldRenderer::renderField()` when the field type does not match any built-in type (`section`, `sub_section`, `text`, `email`, `tel`, `number`, `textarea`, `checkbox`, `select`, `address_select`). Use this to render custom field types in the checkout or registration forms.
* **Source:** `app/Services/Renderer/FormFieldRenderer.php` (line 58)

#### Parameters:
`$fieldData` *(array)*: The field configuration array
```php
$fieldData = [
    'type'          => 'my_custom_type',  // string — The unrecognised field type
    'label'         => 'Custom Field',    // string — Field label
    'id'            => 'my_field',        // string — Field HTML ID
    'name'          => 'my_field',        // string — Field name attribute
    'required'      => true,              // bool — Whether the field is required
    'wrapper_class' => '',                // string — CSS class for the wrapper
    'options'       => [],                // array — Options (if applicable)
];
```

#### Usage Example:
```php
// Hook to render unrecognized form field types in checkout
add_action('fluent_cart/render_custom_form_field', function ($fieldData) {
    // Render custom date_picker field type HTML
    if ($fieldData['type'] === 'date_picker') {
        $id = esc_attr($fieldData['id'] ?? '');
        $name = esc_attr($fieldData['name'] ?? '');
        $label = esc_html($fieldData['label'] ?? '');
        $required = !empty($fieldData['required']) ? 'required' : '';
        echo "<div class='fct_form_field'>";
        echo "<label for='{$id}'>{$label}</label>";
        echo "<input type='date' id='{$id}' name='{$name}' {$required} />";
        echo "</div>";
    }
}, 10, 1);
```

---

## Templating
Hooks for the generic fallback template used on product archive pages and other FluentCart template-driven pages. They fire in sequence from top to bottom of the page layout.

### `generic_template/rendering`
`fluent_cart/generic_template/rendering` — Start of generic fallback template

* **When it runs:** Fires at the very top of `fallback-generic-template.php`, before `get_header()` is called. Use this to set up global variables, enqueue assets, or modify the page state before any template output begins.
* **Parameters:** None.
* **Source:** `app/Modules/Templating/fallback-generic-template.php` (line 7)

#### Usage Example:
```php
// Hook at top of generic fallback template before get_header()
add_action('fluent_cart/generic_template/rendering', function () {
    // Enqueue custom styles for product archive template
    wp_enqueue_style('my-archive-styles', plugins_url('css/archive.css', __FILE__));
}, 10);
```

---

### `generic_template/before_content`
`fluent_cart/generic_template/before_content` — After get_header(), before main wrapper

* **When it runs:** Fires after the WordPress header has been rendered by `get_header()` and before the main content wrapper `<div>` opens. Use this for banners, breadcrumbs, or other full-width elements above the content area.
* **Parameters:** None.
* **Source:** `app/Modules/Templating/fallback-generic-template.php` (line 10)

#### Usage Example:
```php
// Hook after get_header() and before main wrapper in generic template
add_action('fluent_cart/generic_template/before_content', function () {
    // Add breadcrumb trail above product archive
    echo '<nav class="fct-breadcrumb">Home &raquo; Shop</nav>';
}, 10);
```

---

### `template/before_content`
`fluent_cart/template/before_content` — Inside main wrapper, before content

* **When it runs:** Fires inside the `<div id="main">` site-main wrapper, before the main content hook. Use this for content-width elements like filter bars or category headers that sit above the product grid.
* **Parameters:** None.
* **Source:** `app/Modules/Templating/fallback-generic-template.php` (line 13)

#### Usage Example:
```php
// Hook inside main wrapper before main content area
add_action('fluent_cart/template/before_content', function () {
    // Show category filter bar above product grid
    echo '<div class="fct-filter-bar">Filter by category...</div>';
}, 10);
```

---

### `template/main_content`
`fluent_cart/template/main_content` — Main content area

* **When it runs:** Fires inside the `<div id="main">` wrapper between the `before_content` and `after_content` hooks. This is where the primary page content (product grid, archive loop, etc.) is rendered. FluentCart's templating module hooks its archive rendering here.
* **Parameters:** None.
* **Source:** `app/Modules/Templating/fallback-generic-template.php` (line 14)

#### Usage Example:
```php
// Hook inside main wrapper to render primary page content
add_action('fluent_cart/template/main_content', function () {
    // Output custom product grid layout HTML
    echo '<div class="my-custom-product-grid">Custom grid here</div>';
}, 10);
```

---

### `template/after_content`
`fluent_cart/template/after_content` — After main content

* **When it runs:** Fires inside the `<div id="main">` wrapper after the main content has been rendered. Use this for pagination, call-to-action blocks, or related products sections that sit below the product grid.
* **Parameters:** None.
* **Source:** `app/Modules/Templating/fallback-generic-template.php` (line 15)

#### Usage Example:
```php
// Hook inside main wrapper after primary page content
add_action('fluent_cart/template/after_content', function () {
    // Render pagination elements below product grid
    echo '<div class="fct-pagination"><!-- pagination links --></div>';
}, 10);
```

---

### `generic_template/after_content`
`fluent_cart/generic_template/after_content` — After main wrapper, before get_footer()

* **When it runs:** Fires after the main content wrapper `<div>` closes and before `get_footer()` renders the site footer. Use this for full-width elements below the content area like newsletter signups or related content.
* **Parameters:** None.
* **Source:** `app/Modules/Templating/fallback-generic-template.php` (line 18)

#### Usage Example:
```php
// Hook after main wrapper closes and before get_footer()
add_action('fluent_cart/generic_template/after_content', function () {
    // Output full-width newsletter signup section
    echo '<section class="fct-newsletter">Subscribe to our newsletter</section>';
}, 10);
```

---

## Views (Shortcode-Driven Rendering)
Hooks that render specific view partials on the checkout page, receipt emails, and customer-facing forms. These fire inside `ob_start()` / `ob_get_clean()` blocks — your callbacks should `echo` HTML output.

### `views/checkout_page_cart_item_list`
`fluent_cart/views/checkout_page_cart_item_list` — Render cart item list on checkout

* **When it runs:** Fires inside `CheckoutController::getCheckoutSummary()` to render the cart item list partial on the checkout page. The output is captured via `ob_start()` and returned as part of the checkout summary AJAX response.
* **Source:** `app/Http/Controllers/CheckoutController.php` (line 39)

#### Parameters:
`$data` *(array)*: Checkout context
```php
$data = [
    'checkout' => $checkOutHelper,  // \FluentCart\App\Helpers\CartCheckoutHelper instance
    'items'    => [...],            // array — Cart items from $checkOutHelper->getItems()
];
```

#### Usage Example:
```php
// Hook to render cart item list partial on checkout page
add_action('fluent_cart/views/checkout_page_cart_item_list', function ($data) {
    // Extract items array from checkout data
    $items = $data['items'];
    echo '<div class="fct-cart-items">';
    foreach ($items as $item) {
        echo '<div class="fct-cart-item">' . esc_html($item['title'] ?? '') . '</div>';
    }
    echo '</div>';
}, 10, 1);
```

---

### `views/checkout_page_registration_form`
`fluent_cart/views/checkout_page_registration_form` — Render registration form on checkout

* **When it runs:** Fires inside `CustomerRegistrationHandler::render()` to output the guest registration form on the checkout page. The output is captured via `ob_start()` and returned as the rendered form HTML.
* **Source:** `app/Hooks/Handlers/ShortCodes/CustomerRegistrationHandler.php` (line 79)

#### Parameters:
`$viewData` *(array)*: View context
```php
$viewData = [
    'checkout' => $checkOutHelper,  // \FluentCart\App\Helpers\CartCheckoutHelper instance
];
```

#### Usage Example:
```php
// Hook to render guest registration form on checkout page
add_action('fluent_cart/views/checkout_page_registration_form', function ($viewData) {
    // Extract checkout helper instance
    $checkout = $viewData['checkout'];
    echo '<div class="fct-registration-form">';
    echo '<h3>Create an Account</h3>';
    // Render custom registration input fields
    echo '<input type="text" name="full_name" placeholder="Full Name" />';
    echo '<input type="email" name="email" placeholder="Email" />';
    echo '<input type="password" name="password" placeholder="Password" />';
    echo '</div>';
}, 10, 1);
```

---

### `views/checkout_page_login_form`
`fluent_cart/views/checkout_page_login_form` — Render login form on checkout

* **When it runs:** Fires inside `CustomerLoginHandler::render()` to output the login form on the checkout page for returning customers. The output is captured via `ob_start()` and returned as the rendered form HTML.
* **Source:** `app/Hooks/Handlers/ShortCodes/CustomerLoginHandler.php` (line 81)

#### Parameters:
`$viewData` *(array)*: View context (same structure as `registration_form`)

#### Usage Example:
```php
// Hook to render returning customer login form on checkout page
add_action('fluent_cart/views/checkout_page_login_form', function ($viewData) {
    // Render login form inputs and submit button
    echo '<div class="fct-login-form">';
    echo '<h3>Returning Customer? Log In</h3>';
    echo '<input type="email" name="email" placeholder="Email" />';
    echo '<input type="password" name="password" placeholder="Password" />';
    echo '<button type="submit">Log In</button>';
    echo '</div>';
}, 10, 1);
```

---

### `views/checkout_order_summary`
`fluent_cart/views/checkout_order_summary` — Render order summary (email shortcodes)

* **When it runs:** Fires inside `ShortcodeParser::getSummary()` when the shortcode is parsed in email templates. The output is captured via `ob_start()` and inserted into the email body as the order summary block. Receives the Order model instance.
* **Source:** `app/Services/ShortCodeParser/ShortcodeParser.php` (line 248)

#### Parameters:
`$data` *(array)*: Order summary context
```php
$data = [
    'order'          => $order,          // \FluentCart\App\Models\Order instance
    'paymentReceipt' => $paymentReceipt, // \FluentCart\App\Services\PaymentReceipt instance
];
```

#### Usage Example:
```php
// Hook to render order summary block in email shortcodes
add_action('fluent_cart/views/checkout_order_summary', function ($data) {
    // Extract order model and payment receipt instances
    $order = $data['order'];
    $receipt = $data['paymentReceipt'];
    echo '<table class="fct-order-summary">';
    echo '<tr><th>Order #' . esc_html($order->id) . '</th></tr>';
    // Render order summary table rows
    echo '</table>';
}, 10, 1);
```

---

### `views/checkout_order_receipt`
`fluent_cart/views/checkout_order_receipt` — Render full order receipt (email shortcodes)

* **When it runs:** Fires inside `ShortcodeParser::getReceipt()` when the shortcode is parsed in email templates. The output is captured via `ob_start()` and inserted into the email body as the complete Order receipt.
* **Source:** `app/Services/ShortCodeParser/ShortcodeParser.php` (line 256)

#### Parameters:
`$data` *(array)*: Order receipt context (same structure as `checkout_order_summary`)

#### Usage Example:
```php
// Hook to render full order receipt block in email shortcodes
add_action('fluent_cart/views/checkout_order_receipt', function ($data) {
    // Extract order model and payment receipt instances
    $order = $data['order'];
    $receipt = $data['paymentReceipt'];
    echo '<div class="fct-receipt">';
    echo '<h2>Receipt for Order #' . esc_html($order->id) . '</h2>';
    // Render full receipt wrapper HTML
    echo '</div>';
}, 10, 1);
```

---

### `views/checkout_page_shipping_method_list`
`fluent_cart/views/checkout_page_shipping_method_list` — Render shipping method list

* **When it runs:** Fires inside `ShippingFrontendController::getShippingMethodsListView()` to render the list of available `ShippingMethod` instances on the checkout page. The output is captured via `ob_start()` and returned as part of the shipping methods AJAX response.
* **Source:** `app/Modules/Shipping/Http/Controllers/Frontend/ShippingFrontendController.php` (line 75)

#### Parameters:
`$data` *(array)*: Shipping methods context
```php
$data = [
    'shipping_methods' => [
        // Array of available \FluentCart\App\Models\ShippingMethod instances filtered by country
    ],
];
```

#### Usage Example:
```php
// Hook to render shipping method list partial on checkout page
add_action('fluent_cart/views/checkout_page_shipping_method_list', function ($data) {
    // Extract filtered shipping methods list array
    $methods = $data['shipping_methods'];
    echo '<div class="fct-shipping-methods">';
    foreach ($methods as $method) {
        echo '<label>';
        echo '<input type="radio" name="shipping_method" value="' . esc_attr($method->id) . '" />';
        echo esc_html($method->title);
        echo '</label>';
    }
    echo '</div>';
}, 10, 1);
```

---

### `views/checkout_page_form_address_info_wrapper`
`fluent_cart/views/checkout_page_form_address_info_wrapper` — Render address info card

* **When it runs:** Fires inside `CustomerController` when rendering the address information card on the checkout page after a customer selects or submits their address. The output is captured via `ob_start()` and returned in the AJAX response.
* **Source:** `app/Http/Controllers/FrontendControllers/CustomerController.php` (line 137)

#### Parameters:
`$data` *(array)*: Address display data
```php
$data = [
    'name'    => 'John Doe',                          // string — Customer name
    'phone'   => '+1234567890',                       // string — Customer phone number
    'label'   => 'Home',                              // string — Address label
    'address' => '123 Main St, City, State, Country', // string — Formatted address string
];
```

#### Usage Example:
```php
// Hook to render address info card view on checkout page
add_action('fluent_cart/views/checkout_page_form_address_info_wrapper', function ($data) {
    // Render formatted address info card block
    echo '<div class="fct-address-card">';
    echo '<strong>' . esc_html($data['name']) . '</strong>';
    if (!empty($data['phone'])) {
        echo '<br />' . esc_html($data['phone']);
    }
    echo '<br />' . esc_html($data['address']);
    echo '</div>';
}, 10, 1);
```

---

## Policies / Security
Hooks that fire during REST API policy verification. These allow you to add custom security checks, rate limiting, or audit logging before the standard permission check runs.

### `policy/store_sensitive_request`
`fluent_cart/policy/store_sensitive_request` — Store-sensitive API request verification

* **When it runs:** Fires at the beginning of `StoreSensitivePolicy::verifyRequest()`, before the `store/sensitive` capability check is performed. This policy protects sensitive store operations (e.g. payment gateway configuration, API key management). Use this to add additional security measures like IP whitelisting or two-factor verification.
* **Source:** `app/Http/Policies/StoreSensitivePolicy.php` (line 11)

#### Parameters:
`$data` *(array)*: Request context
```php
$data = [
    'request' => $request, // \FluentCart\Framework\Http\Request\Request instance
];
```

#### Usage Example:
```php
// Hook before store-sensitive REST API capability check is performed
add_action('fluent_cart/policy/store_sensitive_request', function ($data) {
    // Extract request object and remote IP address
    $request = $data['request'];
    $ip = $request->server('REMOTE_ADDR');

    // Log sensitive API access attempt details
    fluent_cart_add_log(
        'Sensitive API Access',
        sprintf('IP: %s, Endpoint: %s', $ip, $request->url()),
        'info'
    );
}, 10, 1);
```

---

### `policy/store_settings_request`
`fluent_cart/policy/store_settings_request` — Store-settings API request verification

* **When it runs:** Fires at the beginning of `StoreSettingsPolicy::verifyRequest()`, before the route-meta permission check (`hasRoutePermissions()`) is performed. This policy protects store settings endpoints (e.g. general settings, email templates, checkout configuration). Use this for additional validation or logging.
* **Source:** `app/Http/Policies/StoreSettingsPolicy.php` (line 11)

#### Parameters:
`$data` *(array)*: Request context (same structure as `store_sensitive_request`)

#### Usage Example:
```php
// Hook before store-settings REST API capability check is performed
add_action('fluent_cart/policy/store_settings_request', function ($data) {
    // Extract request object
    $request = $data['request'];

    // Restrict settings changes to specific allowed admin user IDs
    $allowedUserIds = [1, 2, 3];
    if (!in_array(get_current_user_id(), $allowedUserIds)) {
        wp_die('You are not allowed to modify store settings.', 403);
    }
}, 10, 1);
```

---

## Web Routes
Dynamic hooks for custom web route endpoints. Used primarily by payment gateways for IPN (Instant Payment Notification) callbacks, webhook handlers, and other server-to-server endpoints.

### `fluent_cart_action_{page}`
`fluent_cart_action_{$page}` — Custom web route action handler (dynamic)

* **When it runs:** Fires inside `WebRoutes` when the current FluentCart web route `$page` slug matches a registered action. After the action fires, `die()` is called immediately — your callback must handle the full response (headers, body, exit). This is typically used by payment gateway modules to register IPN/webhook listeners (e.g. `fluent_cart_action_stripe_ipn`).
* **Source:** `app/Http/Routes/WebRoutes.php` (line 198)

#### Parameters:
`$requestData` *(array)*: All request parameters from `App::request()->all()`, which includes merged GET and POST data.
```php
$requestData = [
    'webhook_id'   => 'evt_123abc',
    'payment_type' => 'subscription',
    // ... any other query string and POST body parameters
];
```

#### Usage Example:
```php
// Hook for custom web route IPN callback action handler
add_action('fluent_cart_action_my_gateway_ipn', function ($requestData) {
    // Verify incoming HTTP webhook payload and signature
    $payload = file_get_contents('php://input');
    $signature = $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? '';

    if (!verify_webhook_signature($payload, $signature)) {
        status_header(403);
        echo 'Invalid signature';
        return;
    }

    // Process IPN payment notification payload
    process_ipn_notification($requestData);

    status_header(200);
    echo 'OK';
}, 10, 1);
```

---

# Action Hooks: Cart & Checkout

All hooks related to the shopping flow — from adding items to the Cart through checkout rendering and the receipt/thank-you page.

---

## Cart Events

### `item_added`
`fluent_cart/cart/item_added` — Fired after an item is added to the cart

* **When it runs:** This action fires immediately after a product item has been successfully added to the Cart model and saved to the database. It runs before the `cart_data_items_updated` hook with the `item_added` scope.
* **Source:** `app/Models/Cart.php`

#### Parameters:
`$data` *(array)*: Cart and item data
```php
$data = [
    'cart' => $cart,   // \FluentCart\App\Models\Cart instance
    'item' => $item,   // array — the cart item that was just added
];
```

#### Usage Example:
```php
// Hook after an item is added to the cart
add_action('fluent_cart/cart/item_added', function ($data) {
    // Extract cart model and item array from event data
    $cart = $data['cart'];
    $item = $data['item'];

    // Log the added product for analytics
    error_log('Product ' . $item['post_id'] . ' added to cart #' . $cart->id);
}, 10, 1);
```

---

### `item_removed`
`fluent_cart/cart/item_removed` — Fired after an item is removed from the cart

* **When it runs:** This action fires after a product item has been removed from the Cart and saved, but only when the `$triggerEvent` parameter is `true` (the default). When an item is removed silently (e.g., during a replacement operation), this hook does not fire.
* **Source:** `app/Models/Cart.php`

#### Parameters:
`$data` *(array)*: Cart and removal context
```php
$data = [
    'cart'         => $cart,          // \FluentCart\App\Models\Cart instance
    'variation_id' => $variationId,   // int — the variation ID that was removed
    'extra_args'   => $extraArgs,     // array — additional matching arguments
    'removed_item' => $removingItem,  // array — the full cart item that was removed
];
```

#### Usage Example:
```php
// Hook after an item is removed from the cart
add_action('fluent_cart/cart/item_removed', function ($data) {
    // Extract removed item array and cart model from event data
    $removedItem = $data['removed_item'];
    $cart = $data['cart'];

    // Track removal for abandoned cart analytics
    do_action('my_plugin/track_cart_removal', [
        'variation_id' => $data['variation_id'],
        'product_id'   => $removedItem['post_id'] ?? null,
        'cart_id'      => $cart->id,
    ]);
}, 10, 1);
```

---

### `cart_data_items_updated`
`fluent_cart/cart/cart_data_items_updated` — General-purpose hook for any cart data change

* **When it runs:** This action fires whenever the cart data array is modified. The `scope` field tells you what operation triggered the update. It fires on item add, item remove, coupon apply, coupon remove, discount recalculation, and checkout page loading.
* **Source:** `app/Models/Cart.php`, `app/Hooks/Handlers/ShortCodes/Checkout/CheckoutPageHandler.php`

#### Parameters:
`$data` *(array)*: Cart and scope context
```php
$data = [
    'cart'       => $cart,        // \FluentCart\App\Models\Cart instance
    'scope'      => 'item_added', // string — one of the scope values below
    'scope_data' => $scopeData,   // mixed — context data depending on scope
];
```

#### Possible Scope Values and `scope_data`:
| Scope | `scope_data` Description |
|---|---|
| `'item_added'` | The cart item array that was added |
| `'item_removed'` | The variation ID (`int`) that was removed |
| `'discounts_recalculated'` | Array of applied coupon codes |
| `'remove_coupon'` | Array of coupon codes that were removed |
| `'apply_coupons'` | Array of coupon codes that were applied |
| `'loading'` | Empty string (fired on checkout page load) |

#### Usage Example:
```php
// General-purpose hook for any cart data change
add_action('fluent_cart/cart/cart_data_items_updated', function ($data) {
    // Extract cart model and update scope string
    $cart = $data['cart'];
    $scope = $data['scope'];

    // Recalculate custom surcharges when cart items change
    if ($scope === 'item_added' || $scope === 'item_removed') {
        my_plugin_recalculate_surcharges($cart);
    }

    // Log applied coupons if scope is apply_coupons
    if ($scope === 'apply_coupons') {
        error_log('Coupons applied to cart #' . $cart->id . ': ' . implode(', ', $data['scope_data']));
    }
}, 10, 1);
```

---

### `cart_completed`
`fluent_cart/cart_completed` — Fired when a cart is marked as completed after payment

* **When it runs:** This action fires when the cart's stage is set to `completed` after a successful Order payment. The cart's `completed_at` timestamp has already been saved at this point. This is triggered inside `StatusHelper` during order status transitions when payment is marked as paid.
* **Source:** `app/Helpers/StatusHelper.php`

#### Parameters:
`$data` *(array)*: Completed cart and associated order
```php
$data = [
    'cart'  => $relatedCart,  // \FluentCart\App\Models\Cart instance (stage = 'completed')
    'order' => $order,        // \FluentCart\App\Models\Order instance
];
```

#### Usage Example:
```php
// Hook when a cart is marked as completed after payment
add_action('fluent_cart/cart_completed', function ($data) {
    // Extract completed cart and associated order models
    $cart = $data['cart'];
    $order = $data['order'];

    // Fire a conversion pixel or sync to analytics
    my_plugin_track_conversion([
        'order_id'    => $order->id,
        'total'       => $order->total_amount,
        'customer_id' => $order->customer_id,
    ]);
}, 10, 1);
```

---

## Checkout Data Events

### `prepare_other_data`
`fluent_cart/checkout/prepare_other_data` — After order creation, before finalizing

* **When it runs:** This action fires during the checkout submission flow, after the draft Order has been created but before it is finalized (before addresses and items are attached). This gives modules a chance to attach additional data to the order.
* **Source:** `api/Checkout/CheckoutApi.php`

#### Parameters:
`$data` *(array)*: Full checkout context
```php
$data = [
    'cart'           => $cart,           // \FluentCart\App\Models\Cart instance
    'order'          => $createdOrder,   // \FluentCart\App\Models\Order — the newly created draft order
    'prev_order'     => $prevOrder,      // \FluentCart\App\Models\Order|null — previous order if retrying
    'request_data'   => $data,           // array — raw validated request data from checkout form
    'validated_data' => $validatedData,  // array — sanitized/validated checkout field values
];
```

#### Usage Example:
```php
// Hook after draft order creation, before finalizing checkout
add_action('fluent_cart/checkout/prepare_other_data', function ($data) {
    // Extract draft order and request data array
    $order = $data['order'];
    $requestData = $data['request_data'];

    // Attach custom metadata to the order before it finalizes
    $customField = sanitize_text_field($requestData['custom_gift_message'] ?? '');
    if ($customField) {
        $order->updateMeta('gift_message', $customField);
    }
}, 10, 1);
```

---

### `cart_amount_updated`
`fluent_cart/checkout/cart_amount_updated` — Fired when the cart total may have changed

* **When it runs:** This action fires whenever an operation changes (or may change) the cart total. This includes: item removal (silent mode), coupon application, coupon removal, discount recalculation, quantity updates, order bump toggles, and tax recalculations. Use this hook to react to price changes regardless of the specific cause.
* **Source:** `app/Models/Cart.php`, `app/Hooks/Cart/WebCheckoutHandler.php`, `app/Modules/Tax/TaxModule.php`

#### Parameters:
`$data` *(array)*: The affected cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook when the cart total amount is updated
add_action('fluent_cart/checkout/cart_amount_updated', function ($data) {
    // Extract cart model instance
    $cart = $data['cart'];

    // Recalculate a custom fee based on the new cart total
    $estimatedTotal = $cart->getEstimatedTotal();
    if ($estimatedTotal > 10000) { // over $100.00 in cents
        // Apply free shipping threshold logic
        my_plugin_apply_free_shipping($cart);
    }
}, 10, 1);
```

---

### `shipping_data_changed`
`fluent_cart/checkout/shipping_data_changed` — Fired when shipping data changes

* **When it runs:** This action fires when shipping-related data on the cart changes, such as when a new shipping method is selected, the shipping charge changes, or the shipping address is updated in a way that affects shipping calculations.
* **Source:** `app/Helpers/CartHelper.php`, `app/Hooks/Cart/WebCheckoutHandler.php`

#### Parameters:
`$data` *(array)*: The affected cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook when shipping-related data on the cart changes
add_action('fluent_cart/checkout/shipping_data_changed', function ($data) {
    // Extract cart model and shipping data array
    $cart = $data['cart'];
    $shippingData = $cart->checkout_data['shipping_data'] ?? [];

    // Log shipping method selection for analytics
    error_log('Cart #' . $cart->id . ' shipping method: ' . ($shippingData['shipping_method_id'] ?? 'none'));
}, 10, 1);
```

---

### `form_data_changed`
`fluent_cart/checkout/form_data_changed` — Fired when checkout form data changes

* **When it runs:** This action fires when the checkout form data is updated via AJAX, such as when a customer changes their address, toggles "ship to different address", or any form field is updated that triggers a server-side recalculation.
* **Source:** `app/Hooks/Cart/WebCheckoutHandler.php`

#### Parameters:
`$data` *(array)*: The affected cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook when checkout form data is updated via AJAX
add_action('fluent_cart/checkout/form_data_changed', function ($data) {
    // Extract cart model and checkout form data array
    $cart = $data['cart'];
    $formData = $cart->checkout_data['form_data'] ?? [];

    // Check if the billing country requires special handling
    $billingCountry = $formData['billing_country'] ?? '';
    if (in_array($billingCountry, ['BR', 'IN'])) {
        // Add country-specific checkout notices
        my_plugin_add_country_notice($cart, $billingCountry);
    }
}, 10, 1);
```

---

### `customer_data_saved`
`fluent_cart/checkout/customer_data_saved` — Fired when customer checkout data is saved

* **When it runs:** This action fires when a specific piece of customer data is saved during the checkout process. The hook provides both the old and new values, making it useful for detecting changes. It fires after the data has already been persisted to the cart model.
* **Source:** `app/Hooks/Cart/WebCheckoutHandler.php`

#### Parameters:
`$data` *(array)*: Customer data change context
```php
$data = [
    'cart'      => $cart,            // \FluentCart\App\Models\Cart instance
    'key'       => $key,             // string — the data key that changed (e.g. 'billing_country')
    'value'     => $value,           // mixed — the new value
    'old_value' => $prevValue,       // mixed — the previous value
    'old_data'  => $oldCheckoutData, // array — the full previous checkout_data array
];
```

#### Usage Example:
```php
// Hook when customer checkout data key is saved
add_action('fluent_cart/checkout/customer_data_saved', function ($data) {
    // Extract cart model and change key metadata
    $cart = $data['cart'];
    $key = $data['key'];

    // React to billing country changes for tax recalculation
    if ($key === 'billing_country' && $data['value'] !== $data['old_value']) {
        error_log('Cart #' . $cart->id . ' billing country changed from '
            . $data['old_value'] . ' to ' . $data['value']);
    }
}, 10, 1);
```

---

### `tax/reverse_charge_applied`
`fluent_cart/tax/reverse_charge_applied` — Fired when the EU VAT reverse charge is applied to the cart

* **When it runs:** This action fires during cart tax calculation (`TaxModule::calculateCartTax()`) when the reverse charge mechanism has just been applied — a qualifying business customer (e.g. validated EU VAT number) is liable for the VAT, so tax has been removed and inclusive product lines and fees have been adjusted to net prices. It fires after those adjustments are written into the cart's checkout data.
* **Source:** `app/Modules/Tax/TaxModule.php` (line 750)

#### Parameters:
`$data` *(array)*: Reverse charge context
```php
$data = [
    'checkout_data' => $checkoutData, // array — the cart's checkout_data (includes the updated 'tax_data')
    'product_lines' => $productLines, // array — cart product line items, already adjusted to net prices
];
```

#### Usage Example:
```php
// Hook when EU VAT reverse charge is applied to the cart
add_action('fluent_cart/tax/reverse_charge_applied', function ($data) {
    // Extract tax data array from checkout data
    $taxData = $data['checkout_data']['tax_data'] ?? [];

    // Log or sync with an external tax service
    my_tax_service_flag_reverse_charge($taxData);
}, 10, 1);
```

---

### `tax/reverse_charge_removed`
`fluent_cart/tax/reverse_charge_removed` — Fired when the EU VAT reverse charge is removed from the cart

* **When it runs:** This action fires during cart tax calculation (`TaxModule::calculateCartTax()`) when a previously applicable reverse charge no longer applies (e.g. the VAT number was removed or the billing country changed). Product lines have already been restored to gross prices and the reverse charge fee adjustments cleared before it fires.
* **Source:** `app/Modules/Tax/TaxModule.php` (line 762)

#### Parameters:
`$data` *(array)*: Reverse charge context
```php
$data = [
    'checkout_data' => $checkoutData, // array — the cart's checkout_data (includes 'tax_data')
    'product_lines' => $productLines, // array — cart product line items, restored to gross prices
];
```

#### Usage Example:
```php
// Hook when EU VAT reverse charge is removed from the cart
add_action('fluent_cart/tax/reverse_charge_removed', function ($data) {
    // React to the customer no longer qualifying for reverse charge
    my_tax_service_clear_reverse_charge($data['checkout_data']);
}, 10, 1);
```

---

## Checkout Page Rendering
All hooks in this section fire during server-side HTML rendering of the checkout page. They use output buffering, so you should `echo` (not return) any custom HTML you want to inject.

### `before_checkout_page_start`
`fluent_cart/before_checkout_page_start` — Before the checkout page wrapper div

* **When it runs:** This action fires immediately before the main checkout page `<div>` wrapper is opened. Use it to output HTML or scripts that should appear above the entire checkout page.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook before the checkout page wrapper div is rendered
add_action('fluent_cart/before_checkout_page_start', function ($data) {
    // Extract cart model instance
    $cart = $data['cart'];
    // Output custom promotional banner HTML
    echo '<div class="my-checkout-banner">';
    echo '<p>Free shipping on orders over $50!</p>';
    echo '</div>';
}, 10, 1);
```

---

### `afrer_checkout_page_start`
`fluent_cart/afrer_checkout_page_start` — After the checkout page wrapper div opens

* **When it runs:** This action fires right after the main checkout page `<div>` wrapper opens. Note the typo in the hook name (`afrer` instead of `after`) — this matches the actual hook name in the source code and must be used as-is.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook after the checkout page wrapper div opens (note 'afrer' spelling in hook name)
add_action('fluent_cart/afrer_checkout_page_start', function ($data) {
    // Extract cart model instance
    $cart = $data['cart'];
    // Insert a progress indicator at the top of the checkout page
    echo '<div class="my-checkout-progress-bar">Step 1 of 3: Checkout</div>';
}, 10, 1);
```

---

### `before_checkout_form`
`fluent_cart/before_checkout_form` — Before the checkout form element

* **When it runs:** This action fires just before the `<form>` tag for the checkout form is rendered.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook before the checkout form element is rendered
add_action('fluent_cart/before_checkout_form', function ($data) {
    // Render security and trust badges HTML
    echo '<div class="my-trust-badges">';
    echo '<img src="/wp-content/uploads/secure-checkout.svg" alt="Secure Checkout" />';
    echo '</div>';
}, 10, 1);
```

---

### `checkout_form_opening`
`fluent_cart/checkout_form_opening` — Right after the checkout form tag opens

* **When it runs:** This action fires immediately after the `<form>` tag opens, before any form fields are rendered. Use it to insert hidden fields, nonce fields, or other elements that must be inside the form.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook right after the checkout form tag opens
add_action('fluent_cart/checkout_form_opening', function ($data) {
    // Add a hidden input field for tracking
    echo '<input type="hidden" name="my_tracking_ref" value="' . esc_attr(my_get_tracking_ref()) . '" />';
}, 10, 1);
```

---

### `before_billing_fields`
`fluent_cart/before_billing_fields` — Before billing address fields

* **When it runs:** This action fires after the name/email fields and the "create account" checkbox, but before the billing address fields section is rendered.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook before billing address fields section
add_action('fluent_cart/before_billing_fields', function ($data) {
    // Output custom billing instructions paragraph
    echo '<p class="my-billing-note">Please enter your billing address exactly as it appears on your card statement.</p>';
}, 10, 1);
```

---

### `before_billing_fields_section`
`fluent_cart/before_billing_fields_section` — Before the billing address field section renders

* **When it runs:** This action fires right before the billing address form section (with its heading and input fields) is rendered. It fires inside the `renderBillingAddressFields()` method, after billing field data has been prepared and filtered.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook before the billing address field section heading renders
add_action('fluent_cart/before_billing_fields_section', function ($data) {
    // Output billing section introduction heading
    echo '<div class="my-billing-section-intro">';
    echo '<h4>Where should we send the invoice?</h4>';
    echo '</div>';
}, 10, 1);
```

---

### `after_billing_fields_section`
`fluent_cart/after_billing_fields_section` — After the billing address field section

* **When it runs:** This action fires after the billing address fields section and the "ship to different address" checkbox have been rendered. It only fires when the cart requires shipping.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook after the billing address field section
add_action('fluent_cart/after_billing_fields_section', function ($data) {
    // Extract cart model instance
    $cart = $data['cart'];
    // Add a note between billing and shipping sections
    echo '<div class="my-address-note">';
    echo '<p>Shipping is calculated based on your delivery address.</p>';
    echo '</div>';
}, 10, 1);
```

---

### `before_shipping_fields_section`
`fluent_cart/before_shipping_fields_section` — Before the shipping address field section

* **When it runs:** This action fires right before the shipping address form section is rendered. The shipping section may be hidden via CSS if "ship to different address" is not checked.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook before the shipping address field section
add_action('fluent_cart/before_shipping_fields_section', function ($data) {
    // Output shipping address entry guidance
    echo '<p class="my-shipping-note">Enter the address where you want us to deliver your order.</p>';
}, 10, 1);
```

---

### `after_shipping_fields_section`
`fluent_cart/after_shipping_fields_section` — After the shipping address field section

* **When it runs:** This action fires immediately after the shipping address form section is rendered.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook after the shipping address field section
add_action('fluent_cart/after_shipping_fields_section', function ($data) {
    // Display estimated delivery timeframe note
    echo '<div class="my-delivery-estimate">';
    echo '<p>Estimated delivery: 3-5 business days</p>';
    echo '</div>';
}, 10, 1);
```

---

### `before_payment_methods`
`fluent_cart/before_payment_methods` — Before payment method options

* **When it runs:** This action fires before the payment methods section is rendered on the checkout page. It also fires in the modal checkout renderer and the Gutenberg block inner blocks renderer.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`, `app/Services/Renderer/ModalCheckoutRenderer.php`, `app/Hooks/Handlers/BlockEditors/Checkout/InnerBlocks/InnerBlocks.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook before payment method options are rendered
add_action('fluent_cart/before_payment_methods', function ($data) {
    // Display payment security notice
    echo '<div class="my-payment-security-note">';
    echo '<p>All transactions are encrypted and secure.</p>';
    echo '</div>';
}, 10, 1);
```

---

### `after_payment_methods`
`fluent_cart/after_payment_methods` — After payment method options

* **When it runs:** This action fires after the payment methods section has been rendered, before the checkout submit button.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook after payment method options are rendered
add_action('fluent_cart/after_payment_methods', function ($data) {
    // Render accepted payment gateway logo icons
    echo '<div class="my-payment-icons">';
    echo '<img src="/wp-content/uploads/visa.svg" alt="Visa" />';
    echo '<img src="/wp-content/uploads/mastercard.svg" alt="Mastercard" />';
    echo '</div>';
}, 10, 1);
```

---

### `after_checkout_button`
`fluent_cart/after_checkout_button` — After the checkout submit button

* **When it runs:** This action fires immediately after the "Place order" submit button is rendered.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook after the checkout submit button
add_action('fluent_cart/after_checkout_button', function ($data) {
    // Render terms and conditions disclaimer text
    echo '<p class="my-checkout-disclaimer">';
    echo 'By placing your order you agree to our <a href="/terms">Terms of Service</a>.';
    echo '</p>';
}, 10, 1);
```

---

### `after_order_notes`
`fluent_cart/after_order_notes` — After the order notes section in the summary sidebar

* **When it runs:** This action fires after the order notes field in the checkout summary/sidebar section, inside the order summary wrapper.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook after the order notes section in the summary sidebar
add_action('fluent_cart/after_order_notes', function ($data) {
    // Render gift wrap upsell checkbox
    echo '<div class="my-gift-wrap-option">';
    echo '<label><input type="checkbox" name="gift_wrap" value="yes" /> Add gift wrapping (+$5.00)</label>';
    echo '</div>';
}, 10, 1);
```

---

### `after_order_notes_field`
`fluent_cart/after_order_notes_field` — After the order notes form field

* **When it runs:** This action fires right after the order notes textarea field is rendered, inside the `renderOrderNoteField()` method. Note that the order notes field only appears when the cart requires shipping (unless overridden by the `fluent_cart/disable_order_notes_for_digital_products` filter).
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook after the order notes form textarea field
add_action('fluent_cart/after_order_notes_field', function ($data) {
    // Render example order notes hint
    echo '<p class="my-notes-hint"><em>Example: Leave package at the back door.</em></p>';
}, 10, 1);
```

---

### `after_checkout_form`
`fluent_cart/after_checkout_form` — After the checkout form closes

* **When it runs:** This action fires immediately after the closing `</form>` tag of the checkout form.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook after the checkout form closes
add_action('fluent_cart/after_checkout_form', function ($data) {
    // Render a support chat widget below the form
    echo '<div class="my-checkout-support">';
    echo '<p>Need help? <a href="#" onclick="openChat()">Chat with us</a></p>';
    echo '</div>';
}, 10, 1);
```

---

### `before_checkout_page_close`
`fluent_cart/before_checkout_page_close` — Before the checkout page wrapper div closes

* **When it runs:** This action fires just before the closing `</div>` of the main checkout page wrapper.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook before the checkout page wrapper div closes
add_action('fluent_cart/before_checkout_page_close', function ($data) {
    // Render money-back guarantee footer badge
    echo '<div class="my-checkout-footer-badges">';
    echo '<p>30-day money-back guarantee</p>';
    echo '</div>';
}, 10, 1);
```

---

### `after_checkout_page`
`fluent_cart/after_checkout_page` — After the entire checkout page wrapper

* **When it runs:** This action fires after the checkout page wrapper `</div>` has been closed. Use it for scripts, tracking pixels, or other content that should appear after the entire checkout page.
* **Source:** `app/Services/Renderer/CheckoutRenderer.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook after the entire checkout page wrapper closes
add_action('fluent_cart/after_checkout_page', function ($data) {
    // Extract cart model instance
    $cart = $data['cart'];
    // Output a tracking script after the checkout page
    echo '<script>myAnalytics.trackCheckoutView({ cartId: ' . intval($cart->id) . ' });</script>';
}, 10, 1);
```

---

### `before_summary_total`
`fluent_cart/checkout/before_summary_total` — Before the total line in the cart summary

* **When it runs:** This action fires in the cart summary sidebar, after the subtotal, shipping, and discount lines but before the coupon input field and the final total line.
* **Source:** `app/Services/Renderer/CartSummaryRender.php`

#### Parameters:
`$data` *(array)*: The current cart
```php
$data = [
    'cart' => $cart,  // \FluentCart\App\Models\Cart instance
];
```

#### Usage Example:
```php
// Hook before the total line in the cart summary sidebar
add_action('fluent_cart/checkout/before_summary_total', function ($data) {
    // Extract cart model instance
    $cart = $data['cart'];
    // Add a custom fee line in the summary sidebar
    echo '<li class="my-custom-fee">';
    echo '<span class="fct_summary_label">Processing Fee</span>';
    echo '<span class="fct_summary_value">$2.50</span>';
    echo '</li>';
}, 10, 1);
```

---

## Cart Line Items Rendering
These hooks fire during the rendering of individual cart line items on the checkout page. They all receive the same parameter structure from `CartItemRenderer::getEventInfo()`, which includes Cart, Product, and ProductVariation model instances. Use `echo` to output custom HTML.

### `line_meta`
`fluent_cart/cart/line_item/line_meta` — After line item content, for custom metadata

* **When it runs:** This action fires after the main item content (title, variant info, child variants) inside the item info area, but before the price section. Use it to display custom per-item metadata such as personalization details or custom options.
* **Source:** `app/Services/Renderer/CartItemRenderer.php`

#### Parameters:
`$data` *(array)*: Line item rendering context
* `item` *(array)* — The cart item data (`post_id`, `title`, `quantity`, `unit_price`, etc.)
* `cart` *(\FluentCart\App\Models\Cart|null)* — Cart instance or `null`
* `product` *(\FluentCart\App\Models\Product|null)* — Product model or `null`
* `variant` *(\FluentCart\App\Models\ProductVariation|null)* — ProductVariation model or `null`

#### Usage Example:
```php
// Hook after cart line item content for custom metadata
add_action('fluent_cart/cart/line_item/line_meta', function ($data) {
    // Extract item array from event data
    $item = $data['item'];

    // Display custom engraving text if present
    $engraving = $item['custom_fields']['engraving'] ?? '';
    if ($engraving) {
        echo '<div class="my-engraving-preview">';
        echo '<small>Engraving: ' . esc_html($engraving) . '</small>';
        echo '</div>';
    }
}, 10, 1);
```

---

### `before_total`
`fluent_cart/cart/line_item/before_total` — Before the line item price/total

* **When it runs:** This action fires inside the price area of a cart line item, before the item total (and any promotional strikethrough price) is displayed.
* **Source:** `app/Services/Renderer/CartItemRenderer.php`

#### Parameters:
`$data` *(array)*: Line item rendering context (same structure as `line_meta`)

#### Usage Example:
```php
// Hook before the cart line item price/total
add_action('fluent_cart/cart/line_item/before_total', function ($data) {
    // Extract item array and calculate promotional savings amount
    $item = $data['item'];
    $savings = ($item['other_info']['original_price'] ?? 0) - ($item['unit_price'] ?? 0);
    if ($savings > 0) {
        echo '<span class="my-savings-badge">You save ' . esc_html(\FluentCart\App\Helpers\Helper::toDecimal($savings)) . '</span>';
    }
}, 10, 1);
```

---

### `after_total`
`fluent_cart/cart/line_item/after_total` — After the line item price/total

* **When it runs:** This action fires inside the price area of a cart line item, after the item total is displayed.
* **Source:** `app/Services/Renderer/CartItemRenderer.php`

#### Parameters:
`$data` *(array)*: Line item rendering context (same structure as `line_meta`)

#### Usage Example:
```php
// Hook after the cart line item price/total
add_action('fluent_cart/cart/line_item/after_total', function ($data) {
    // Extract item array from event data
    $item = $data['item'];
    $paymentType = $item['other_info']['payment_type'] ?? '';
    if ($paymentType === 'subscription') {
        echo '<span class="my-recurring-label"><small>Recurring</small></span>';
    }
}, 10, 1);
```

---

### `before_main_title`
`fluent_cart/cart/line_item/before_main_title` — Before the product title in a line item

* **When it runs:** This action fires at the very beginning of the item title area, before the quantity badge, product name, and variant title.
* **Source:** `app/Services/Renderer/CartItemRenderer.php`

#### Parameters:
`$data` *(array)*: Line item rendering context (same structure as `line_meta`)

#### Usage Example:
```php
// Hook before the product title in a cart line item
add_action('fluent_cart/cart/line_item/before_main_title', function ($data) {
    // Extract item array from event data
    $item = $data['item'];
    // Add a "Sale" badge before the product title if on sale
    if (!empty($item['other_info']['is_on_sale'])) {
        echo '<span class="my-sale-badge">Sale</span>';
    }
}, 10, 1);
```

---

### `after_main_title`
`fluent_cart/cart/line_item/after_main_title` — After the product title in a line item

* **When it runs:** This action fires at the end of the item title area, after the product name, variant title, and payment type information (subscription details / per-unit price).
* **Source:** `app/Services/Renderer/CartItemRenderer.php`

#### Parameters:
`$data` *(array)*: Line item rendering context (same structure as `line_meta`)

#### Usage Example:
```php
// Hook after the product title in a cart line item
add_action('fluent_cart/cart/line_item/after_main_title', function ($data) {
    // Extract item array from event data
    $item = $data['item'];
    // Show estimated delivery date per line item
    $deliveryDays = $item['other_info']['delivery_days'] ?? null;
    if ($deliveryDays) {
        $date = date('M j', strtotime("+{$deliveryDays} days"));
        echo '<div class="my-delivery-estimate"><small>Est. delivery: ' . esc_html($date) . '</small></div>';
    }
}, 10, 1);
```

---

## Receipt / Thank You Page
These hooks fire during the rendering of the thank-you / receipt page shown after a successful checkout. The `$config` parameter passed to most hooks contains the Order model instance along with view context. All rendering hooks use output buffering — use `echo` to inject custom HTML.

### `before_header`
`fluent_cart/receipt/thank_you/before_header` — Before the thank-you page header

* **When it runs:** This action fires at the very beginning of the thank-you page content, before the header section (which contains the success/pending icon and title).
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`

#### Parameters:
`$config` *(array)*: Thank-you page configuration
```php
$config = [
    'order'           => $order,           // \FluentCart\App\Models\Order instance
    'is_first_time'   => true|false,       // bool — whether this is the first view of this receipt
    'order_operation' => $orderOperation,  // mixed — order operation context or null
];
```

#### Usage Example:
```php
// Hook before the thank-you page header
add_action('fluent_cart/receipt/thank_you/before_header', function ($config) {
    // Extract order model from thank-you config array
    $order = $config['order'];
    echo '<div class="my-confetti-wrapper" data-order-id="' . intval($order->id) . '"></div>';
}, 10, 1);
```

---

### `after_header`
`fluent_cart/receipt/thank_you/after_header` — After the thank-you page header

* **When it runs:** This action fires after the header section (the success/pending icon and title) is fully rendered, before the body section begins.
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`

#### Parameters:
`$config` *(array)*: Thank-you page configuration (same structure as `before_header`)

#### Usage Example:
```php
// Hook after the thank-you page header
add_action('fluent_cart/receipt/thank_you/after_header', function ($config) {
    // Extract order model from thank-you config array
    $order = $config['order'];
    if ($order->payment_status === 'paid') {
        echo '<div class="my-share-prompt">';
        echo '<p>Love your purchase? Share it with friends!</p>';
        echo '</div>';
    }
}, 10, 1);
```

---

### `after_header_title`
`fluent_cart/receipt/thank_you/after_header_title` — After the header title text

* **When it runs:** This action fires inside the header section, after the "Purchase Successful!" or "Payment Pending!" heading, but still within the header wrapper div. Use it to add a subtitle or additional context below the main title.
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`

#### Parameters:
`$config` *(array)*: Thank-you page configuration (same structure as `before_header`)

#### Usage Example:
```php
// Hook after the header title text on thank-you page
add_action('fluent_cart/receipt/thank_you/after_header_title', function ($config) {
    // Extract order model from thank-you config array
    $order = $config['order'];
    echo '<p class="my-order-ref">Order Reference: #' . esc_html($order->invoice_no) . '</p>';
}, 10, 1);
```

---

### `before_body`
`fluent_cart/receipt/thank_you/before_body` — Before the thank-you page body

* **When it runs:** This action fires after the header section and before the body section, which contains the order details, items, subscriptions, downloads, licenses, and addresses.
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`

#### Parameters:
`$config` *(array)*: Thank-you page configuration (same structure as `before_header`)

#### Usage Example:
```php
// Hook before the thank-you page body section
add_action('fluent_cart/receipt/thank_you/before_body', function ($config) {
    // Render confirmation email sent message
    echo '<div class="my-receipt-notice">';
    echo '<p>A confirmation email has been sent to your email address.</p>';
    echo '</div>';
}, 10, 1);
```

---

### `after_body`
`fluent_cart/receipt/thank_you/after_body` — After the thank-you page body

* **When it runs:** This action fires after the body section (order details, items, addresses) is fully rendered, before the page wrapper closes.
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`

#### Parameters:
`$config` *(array)*: Thank-you page configuration (same structure as `before_header`)

#### Usage Example:
```php
// Hook after the thank-you page body section
add_action('fluent_cart/receipt/thank_you/after_body', function ($config) {
    // Render recommended upsell products block
    echo '<div class="my-upsell-section">';
    echo '<h3>You might also like</h3>';
    echo '</div>';
}, 10, 1);
```

---

### `before_order_header`
`fluent_cart/receipt/thank_you/before_order_header` — Before the order header in the receipt body

* **When it runs:** This action fires inside the receipt body, before the order header area (which shows the customer greeting and order number).
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`

#### Parameters:
`$config` *(array)*: Thank-you page configuration (same structure as `before_header`)

#### Usage Example:
```php
// Hook before the order header in the receipt body
add_action('fluent_cart/receipt/thank_you/before_order_header', function ($config) {
    // Render order placement date heading
    echo '<div class="my-receipt-date">';
    echo '<p>Order placed on: ' . esc_html(date('F j, Y')) . '</p>';
    echo '</div>';
}, 10, 1);
```

---

### `after_order_header`
`fluent_cart/receipt/thank_you/after_order_header` — After the order header in the receipt body

* **When it runs:** This action fires after the order header (customer greeting, order number, and payment status message), before the tax information and order items.
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`

#### Parameters:
`$config` *(array)*: Thank-you page configuration (same structure as `before_header`)

#### Usage Example:
```php
// Hook after the order header in the receipt body
add_action('fluent_cart/receipt/thank_you/after_order_header', function ($config) {
    // Extract order model from thank-you config array
    $order = $config['order'];
    if ($order->note) {
        echo '<div class="my-order-note">';
        echo '<strong>Your note:</strong> ' . esc_html($order->note);
        echo '</div>';
    }
}, 10, 1);
```

---

### `before_order_items`
`fluent_cart/receipt/thank_you/before_order_items` — Before the order items list in the receipt

* **When it runs:** This action fires after the store tax information and before the order items table is rendered.
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`

#### Parameters:
`$config` *(array)*: Thank-you page configuration (same structure as `before_header`)

#### Usage Example:
```php
// Hook before the order items list in the receipt
add_action('fluent_cart/receipt/thank_you/before_order_items', function ($config) {
    // Render items section title
    echo '<div class="my-items-intro"><h4>Here is what you ordered:</h4></div>';
}, 10, 1);
```

---

### `after_order_items`
`fluent_cart/receipt/thank_you/after_order_items` — After the order items list in the receipt

* **When it runs:** This action fires after the order items table (including the totals breakdown), before the subscription items, downloads, licenses, and address sections.
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`

#### Parameters:
`$config` *(array)*: Thank-you page configuration (same structure as `before_header`)

#### Usage Example:
```php
// Hook after the order items list in the receipt
add_action('fluent_cart/receipt/thank_you/after_order_items', function ($config) {
    // Extract order model from thank-you config array
    $order = $config['order'];
    // Show a customer referral code block after items list
    echo '<div class="my-referral-block">';
    echo '<p>Share your referral code <strong>REF-' . intval($order->customer_id) . '</strong> and earn 10% credit!</p>';
    echo '</div>';
}, 10, 1);
```

---

### `before_footer_buttons`
`fluent_cart/receipt/thank_you/before_footer_buttons` — Before the footer buttons

* **When it runs:** This action fires in the receipt footer area, before the "View Order" and "Download Receipt" buttons are rendered.
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`

#### Parameters:
`$config` *(array)*: Thank-you page configuration (same structure as `before_header`)

#### Usage Example:
```php
// Hook before the thank-you page footer buttons
add_action('fluent_cart/receipt/thank_you/before_footer_buttons', function ($config) {
    // Render thank you footer message
    echo '<div class="my-footer-message">';
    echo '<p>Thank you for shopping with us!</p>';
    echo '</div>';
}, 10, 1);
```

---

### `after_footer_buttons`
`fluent_cart/receipt/thank_you/after_footer_buttons` — After the footer buttons

* **When it runs:** This action fires in the receipt footer area, after the "View Order" and "Download Receipt" buttons have been rendered.
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`

#### Parameters:
`$config` *(array)*: Thank-you page configuration (same structure as `before_header`)

#### Usage Example:
```php
// Hook after the thank-you page footer buttons
add_action('fluent_cart/receipt/thank_you/after_footer_buttons', function ($config) {
    // Render social share buttons
    echo '<div class="my-social-share">';
    echo '<p>Follow us on social media for updates and exclusive offers.</p>';
    echo '</div>';
}, 10, 1);
```

---

### `after_receipt`
`fluent_cart/after_receipt` — After the entire receipt/thank-you page

* **When it runs:** This action fires after the complete thank-you page has been rendered, including the footer. It fires on every receipt view (both first-time and returning visits). This hook is also present in the legacy `thank_you.php` view template.
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`, `app/Views/invoice/thank_you.php`

#### Parameters:
`$data` *(array)*: Order and view context
```php
$data = [
    'order'           => $order,           // \FluentCart\App\Models\Order instance
    'is_first_time'   => true|false,       // bool — whether this is the first view of this receipt
    'order_operation' => $orderOperation,  // mixed — order operation context or null
];
```

#### Usage Example:
```php
// Hook after the entire receipt/thank-you page renders
add_action('fluent_cart/after_receipt', function ($data) {
    // Extract order model instance
    $order = $data['order'];

    // Render a customer satisfaction survey link
    echo '<div class="my-survey-widget">';
    echo '<h4>How was your experience?</h4>';
    echo '<a href="/survey?order=' . intval($order->id) . '">Take a quick survey</a>';
    echo '</div>';
}, 10, 1);
```

---

### `after_receipt_first_time`
`fluent_cart/after_receipt_first_time` — Only on the first receipt view (for conversion tracking)

* **When it runs:** This action fires only on the first time a customer views the receipt page after a purchase. It does not fire on subsequent visits to the same receipt URL. This is the ideal hook for firing conversion tracking pixels, analytics events, or affiliate postback URLs.
* **Source:** `app/Services/Renderer/Receipt/ThankYouRender.php`, `app/Views/invoice/thank_you.php`

#### Parameters:
`$data` *(array)*: Order and operation context
```php
$data = [
    'order'           => $order,           // \FluentCart\App\Models\Order instance
    'order_operation' => $orderOperation,  // mixed — order operation context or null
];
```

#### Usage Example:
```php
// Hook on the first receipt view (ideal for conversion tracking)
add_action('fluent_cart/after_receipt_first_time', function ($data) {
    // Extract order model and formatted decimal total
    $order = $data['order'];
    $total = \FluentCart\App\Helpers\Helper::toDecimal($order->total_amount);

    // Fire Meta Facebook conversion tracking pixel
    echo '<script>';
    echo 'fbq("track", "Purchase", { value: ' . esc_js($total) . ', currency: "' . esc_js($order->currency) . '" });';
    echo '</script>';

    // Fire Google Ads conversion tracking script
    echo '<script>';
    echo 'gtag("event", "conversion", { send_to: "AW-XXXXX/YYYYY", value: ' . esc_js($total) . ', currency: "' . esc_js($order->currency) . '", transaction_id: "' . esc_js($order->invoice_no) . '" });';
    echo '</script>';
}, 10, 1);
```

---

### `before_render_redirect_page`
`fluent_cart/before_render_redirect_page` — Before the payment redirect/receipt page renders

* **When it runs:** This action fires at the very beginning of the receipt shortcode handler, before any receipt or redirect page content is rendered. It provides the raw URL parameters used to identify the order and transaction. Use it for early validation, logging, or to set up resources needed by the receipt page.
* **Source:** `app/Hooks/Handlers/ShortCodes/ReceiptHandler.php`

#### Parameters:
`$data` *(array)*: URL parameters for the receipt/redirect
```php
$data = [
    'order_hash' => $orderHash,       // string — the order UUID from the URL
    'trx_hash'   => $transactionHash, // string — the transaction hash from the URL
    'method'     => $method,          // string — the payment method slug
    'is_receipt' => $isReceipt,       // bool — true if this is a receipt page, false if redirect
];
```

#### Usage Example:
```php
// Hook before the payment redirect or receipt page renders
add_action('fluent_cart/before_render_redirect_page', function ($data) {
    // Log receipt page visits for debugging payment callbacks
    if ($data['is_receipt'] && $data['order_hash']) {
        error_log('Receipt page visited for order: ' . $data['order_hash']
            . ' via method: ' . $data['method']);
    }
}, 10, 1);
```

---

# Action Hooks: Customers & Users

All hooks related to Customer lifecycle, user registration, and the customer-facing frontend portal.

---

## Customer Status Changes

### `customer_status_to_{status}`
`fluent_cart/customer_status_to_{$newStatus}` — Fired when a customer's status changes to a specific status

* **When it runs:** This dynamic action fires immediately after a Customer's status is updated and saved to the database. A separate hook is dispatched for each target status, allowing you to listen for transitions to a single status (e.g., `active` or `inactive`) without inspecting the payload.
* **Available dynamic variants:** `active`, `inactive`
* **Source:** `app/Models/Customer.php`

#### Parameters:
`$data` *(array)*: Customer status transition data
```php
$data = [
    'customer'   => $customer,   // \FluentCart\App\Models\Customer — The customer model instance (already updated)
    'old_status' => 'inactive',  // string — Previous status before the change
    'new_status' => 'active',    // string — The new status that was just applied
];
```

#### Usage Example:
```php
// Listen specifically for customers becoming active
add_action('fluent_cart/customer_status_to_active', function ($data) {
    // Extract customer model instance
    $customer = $data['customer'];
    // Send a reactivation welcome-back email
    wp_mail(
        $customer->email,
        'Welcome back!',
        'Your account has been reactivated.'
    );
}, 10, 1);
```

---

### `customer_status_updated`
`fluent_cart/customer_status_updated` — Fired on any customer status change

* **When it runs:** This action fires immediately after the dynamic `fluent_cart/customer_status_to_{$newStatus}` hook for every customer status change. Use this hook when you need to respond to all status transitions regardless of the target status.
* **Source:** `app/Models/Customer.php`

#### Parameters:
`$data` *(array)*: Customer status transition data
```php
$data = [
    'customer'   => $customer,   // \FluentCart\App\Models\Customer — The customer model instance (already updated)
    'old_status' => 'active',    // string — Previous status before the change
    'new_status' => 'inactive',  // string — The new status that was just applied
];
```

#### Usage Example:
```php
// Hook into any customer status change
add_action('fluent_cart/customer_status_updated', function ($data) {
    // Extract customer model instance
    $customer = $data['customer'];
    // Log every status transition into FluentCart logs
    fluent_cart_add_log(
        'Customer Status Changed',
        sprintf(
            'Customer #%d (%s) status changed from %s to %s',
            $customer->id,
            $customer->email,
            $data['old_status'],
            $data['new_status']
        ),
        'info'
    );
}, 10, 1);
```

---

## Customer Data

### `customer_email_changed`
`fluent_cart/customer_email_changed` — Fired when a customer's email is updated via WordPress profile

* **When it runs:** This action fires when a WordPress user updates their email address (via `profile_update`) and no existing FluentCart Customer record matches the new email. In that case the existing customer row is updated in place with the new email. If a customer record already exists for the new email, this hook does not fire -- instead, resources are moved and `fluent_cart/customer_resources_moved` fires.
* **Note:** Both `old_customer` and `new_customer` reference the same Customer model instance. The customer record has already been updated with the new email at the time this hook fires.
* **Source:** `app/Hooks/Handlers/UserHandler.php`

#### Parameters:
`$data` *(array)*: Email change data
```php
$data = [
    'old_customer' => $oldCustomer,       // \FluentCart\App\Models\Customer — The customer model (already updated with new email)
    'new_customer' => $oldCustomer,       // \FluentCart\App\Models\Customer — Same customer instance (already updated)
    'old_email'    => 'old@example.com',  // string — The previous email address
    'new_email'    => 'new@example.com',  // string — The new email address
    'userId'       => 42,                 // int — WordPress user ID
];
```

#### Usage Example:
```php
// Hook when a customer's email is updated via WordPress profile
add_action('fluent_cart/customer_email_changed', function ($data) {
    // Extract updated customer model
    $customer = $data['old_customer'];
    // Sync the email change to an external CRM
    my_crm_update_email(
        $customer->id,
        $data['old_email'],
        $data['new_email']
    );
}, 10, 1);
```

---

### `customer_resources_moved`
`fluent_cart/customer_resources_moved` — Fired after all resources are moved between customers

* **When it runs:** This action fires after a WordPress user's email change triggers a merge between two Customer records. When the new email already belongs to an existing FluentCart customer, all resources (`Order`, `Subscription`, `AppliedCoupon`, `Cart`, customer meta, addresses, and download permissions) are transferred from the old customer to the existing customer. This hook fires once the migration is complete.
* **Migrated resources:** `OrderDownloadPermission`, `Order`, `AppliedCoupon`, `Cart`, `CustomerMeta`, `CustomerAddresses`, `Subscription`
* **Source:** `app/Hooks/Handlers/UserHandler.php`

#### Parameters:
`$data` *(array)*: Resource migration data
```php
$data = [
    'from_customer_id' => 10,  // int — The source customer ID (resources moved away)
    'to_customer_id'   => 25,  // int — The target customer ID (resources moved to)
];
```

#### Usage Example:
```php
// Hook after all resources are moved between merged customers
add_action('fluent_cart/customer_resources_moved', function ($data) {
    // Extract source and target customer IDs
    $fromId = $data['from_customer_id'];
    $toId   = $data['to_customer_id'];

    // Sync merged customer data to system logs
    fluent_cart_add_log(
        'Customer Resources Merged',
        sprintf('All resources moved from customer #%d to customer #%d', $fromId, $toId),
        'info'
    );
}, 10, 1);
```

---

## User Registration

### `user/before_registration`
`fluent_cart/user/before_registration` — Fired before a new WordPress user is created during FluentCart registration

* **When it runs:** This action fires after the registration form data has been validated and processed, but before `wp_create_user()` is called. Use it to perform additional validation, modify the processed data, or trigger external pre-registration workflows.
* **Note:** This parameter is passed directly as an array, not wrapped inside a parent key.
* **Source:** `api/User.php`

#### Parameters:
`$processedData` *(array)*: Processed registration form data
```php
$processedData = [
    'email'      => 'user@example.com',  // string — Sanitized email address
    'password'   => 'securepass123',      // string — User-provided or auto-generated password
    'first_name' => 'John',               // string — Extracted from full name
    'last_name'  => 'Doe',                // string — Extracted from full name
    'username'   => 'user@example.com',   // string — Defaults to the email address
];
```

#### Usage Example:
```php
// Hook before a new WordPress user is created during FluentCart registration
add_action('fluent_cart/user/before_registration', function ($processedData) {
    // Log registration attempts for incoming email
    fluent_cart_add_log(
        'User Registration Attempt',
        sprintf('Registration initiated for %s', $processedData['email']),
        'info'
    );
}, 10, 1);
```

---

### `user/after_register`
`fluent_cart/user/after_register` — Fired after a new WordPress user is created during checkout registration

* **When it runs:** This action fires after `wp_insert_user()` succeeds during the checkout registration flow (handled by `AuthService`). At this point the WordPress user has been created, locale preferences have been saved, and the password change nag has been set if applicable. This hook fires before the standard WordPress `register_new_user` action.
* **Note:** This hook passes two arguments. Make sure to set the accepted argument count to 2 in `add_action`.
* **Source:** `app/Services/AuthService.php`

#### Parameters:
* `$user_id` *(int)* — The newly created WordPress user ID
* `$data` *(array)* — Additional context data:
  ```php
  $data = [
      'user_id' => 42,  // int — Same WordPress user ID
  ];
  ```

#### Usage Example:
```php
// Hook after a new WordPress user is created during checkout registration
add_action('fluent_cart/user/after_register', function ($user_id, $data) {
    // Auto-login the newly registered WordPress user
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id);

    // Send a custom welcome email to new user
    $user = get_user_by('ID', $user_id);
    wp_mail(
        $user->user_email,
        'Welcome to our store!',
        'Your account has been created successfully.'
    );
}, 10, 2);
```

---

## Customer Frontend

### `customer_menu`
`fluent_cart/customer_menu` — Renders the customer dashboard navigation menu

* **When it runs:** This output action fires inside the customer dashboard template, within the main container and before the content area. It is used to render the sidebar navigation menu for the customer portal. This is a rendering hook with no parameters.
* **Parameters:** None.
* **Source:** `app/Views/frontend/customer_app.php`

#### Usage Example:
```php
// Render custom menu items in customer dashboard navigation
add_action('fluent_cart/customer_menu', function () {
    // Add a custom navigation link to the customer dashboard menu
    echo '<a href="/my-account/custom-page/" class="fct-customer-nav-link">';
    echo esc_html__('My Custom Page', 'my-plugin');
    echo '</a>';
}, 20);
```

---

### `customer_app`
`fluent_cart/customer_app` — Renders the customer dashboard main content area

* **When it runs:** This output action fires inside the customer dashboard template, within the main content container (`.fct-customer-dashboard-main-content`). It is used to render the primary content of the customer portal. This is a rendering hook with no parameters.
* **Parameters:** None.
* **Source:** `app/Views/frontend/customer_app.php`

#### Usage Example:
```php
// Render custom section in customer dashboard main content area
add_action('fluent_cart/customer_app', function () {
    // Append custom HTML content block to customer dashboard
    echo '<div class="my-custom-section">';
    echo '<h3>' . esc_html__('My Custom Section', 'my-plugin') . '</h3>';
    echo '<p>' . esc_html__('Additional dashboard content here.', 'my-plugin') . '</p>';
    echo '</div>';
}, 20);
```

---

# Action Hooks: Licenses (Pro)

Action hooks for software licensing lifecycle management including License status changes, `LicenseActivation` management, `LicenseSite` activations/deactivations, and bulk operations. All hooks in this section require the FluentCart Pro plugin.

---

## License Status

### `license_status_updated` (Pro)
`fluent_cart_sl/license_status_updated` — Fires on any license status change

* **When it runs:** This action fires whenever a License's status transitions from one value to another (e.g., `active` to `expired`, `active` to `disabled`, etc.).
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Models/License.php` (line 206)

#### Parameters:
`$data` *(array)*: License status change data
* `license` *(\FluentCart\App\Models\License)* — The license model after the status change
* `old_status` *(string)* — The previous status value
* `new_status` *(string)* — The new status value

#### Usage Example:
```php
// Hook into any license status update
add_action('fluent_cart_sl/license_status_updated', function ($data) {
    // Extract license model and status transition strings
    $license   = $data['license'];
    $oldStatus = $oldStatus = $data['old_status'];
    $newStatus = $data['new_status'];

    // Log status change to system log
    fluent_cart_add_log(
        'License Status Changed',
        sprintf('License #%d changed from %s to %s', $license->id, $oldStatus, $newStatus),
        'info'
    );
}, 10, 1);
```

---

### `license_status_updated_to_{$newStatus}` (Pro)
`fluent_cart_sl/license_status_updated_to_{$newStatus}` — Fires when a license transitions to a specific status

* **When it runs:** This is a dynamic hook that fires for a specific target status. For example, `fluent_cart_sl/license_status_updated_to_expired` fires only when a License becomes expired.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Models/License.php` (line 211)

#### Parameters:
`$data` *(array)*: License status change data
* `license` *(\FluentCart\App\Models\License)* — The license model after the status change
* `old_status` *(string)* — The previous status value
* `new_status` *(string)* — The new status value

#### Usage Example:
```php
// Hook when a license transitions to expired status
add_action('fluent_cart_sl/license_status_updated_to_expired', function ($data) {
    // Extract license model and status values
    $license   = $data['license'];
    $oldStatus = $data['old_status'];
    $newStatus = $data['new_status'];

    // Handle license expiration notification via email
    wp_mail(get_option('admin_email'), 'License Expired', sprintf('License #%d has expired.', $license->id));
}, 10, 1);
```

---

## License Activation Status

### `license_activation_status_updated` (Pro)
`fluent_cart_sl/license_activation_status_updated` — Fires on any license activation status change

* **When it runs:** This action fires whenever a `LicenseActivation`'s status transitions from one value to another.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Models/LicenseActivation.php` (line 52)

#### Parameters:
`$data` *(array)*: License activation status change data
* `license` *(\FluentCart\App\Models\LicenseActivation)* — The license activation model (note: key is `license` but value is a `LicenseActivation` instance)
* `old_status` *(string)* — The previous activation status
* `new_status` *(string)* — The new activation status

#### Usage Example:
```php
// Hook into any license activation status change
add_action('fluent_cart_sl/license_activation_status_updated', function ($data) {
    // Extract activation instance and status strings
    $activation = $data['license']; // Note: key is 'license' but value is a LicenseActivation instance
    $oldStatus  = $data['old_status'];
    $newStatus  = $data['new_status'];

    // Log activation status transition
    fluent_cart_add_log(
        'License Activation Status Changed',
        sprintf('Activation #%d status changed from %s to %s', $activation->id, $oldStatus, $newStatus),
        'info'
    );
}, 10, 1);
```

---

### `license_activation_status_updated_to_{$newStatus}` (Pro)
`fluent_cart_sl/license_activation_status_updated_to_{$newStatus}` — Fires when a license activation transitions to a specific status

* **When it runs:** This is a dynamic hook that fires for a specific target `LicenseActivation` status.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Models/LicenseActivation.php` (line 57)

#### Parameters:
`$data` *(array)*: License activation status change data
* `license` *(\FluentCart\App\Models\LicenseActivation)* — The license activation model (note: key is `license` but value is a `LicenseActivation` instance)
* `old_status` *(string)* — The previous activation status
* `new_status` *(string)* — The new activation status

#### Usage Example:
```php
// Hook when a license activation becomes active
add_action('fluent_cart_sl/license_activation_status_updated_to_active', function ($data) {
    // Extract activation model instance
    $activation = $data['license']; // Note: key is 'license' but value is a LicenseActivation instance
    $oldStatus  = $data['old_status'];
    $newStatus  = $data['new_status'];

    // Handle activation becoming active
}, 10, 1);
```

---

## License Limits

### `license_limit_increased` (activation count) (Pro)
`fluent_cart_sl/license_limit_increased` — Fires when the license activation count is increased

* **When it runs:** This action fires when a License's activation count is increased.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Models/License.php` (line 224)

#### Parameters:
`$data` *(array)*: License limit change data
* `license` *(\FluentCart\App\Models\License)* — The license model
* `old_count` *(int)* — The previous activation count

#### Usage Example:
```php
// Hook when the license activation count is increased
add_action('fluent_cart_sl/license_limit_increased', function ($data) {
    // Extract license model and previous activation count
    $license  = $data['license'];
    $oldCount = $data['old_count'];

    // Log activation count increase
    fluent_cart_add_log(
        'License Activation Count Increased',
        sprintf('License #%d activation count increased from %d', $license->id, $oldCount),
        'info'
    );
}, 10, 1);
```

---

### `license_limit_decreased` (Pro)
`fluent_cart_sl/license_limit_decreased` — Fires when the license activation count is decreased

* **When it runs:** This action fires when a License's activation count is decreased.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Models/License.php` (line 239)

#### Parameters:
`$data` *(array)*: License limit change data
* `license` *(\FluentCart\App\Models\License)* — The license model
* `old_count` *(int)* — The previous activation count

#### Usage Example:
```php
// Hook when the license activation count is decreased
add_action('fluent_cart_sl/license_limit_decreased', function ($data) {
    // Extract license model and previous activation count
    $license  = $data['license'];
    $oldCount = $data['old_count'];

    // Log activation count decrease
    fluent_cart_add_log(
        'License Activation Count Decreased',
        sprintf('License #%d activation count decreased from %d', $license->id, $oldCount),
        'info'
    );
}, 10, 1);
```

---

### `license_limit_increased` (limit slots) (Pro)
`fluent_cart_sl/license_limit_increased` — Fires when the license activation limit (slots) is increased

* **When it runs:** This action fires when a License's activation limit (maximum allowed activations) is increased.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Models/License.php` (line 259)

#### Parameters:
`$data` *(array)*: License limit change data
* `license` *(\FluentCart\App\Models\License)* — The license model
* `old_count` *(int)* — The previous activation limit

#### Usage Example:
```php
// Hook when the license activation limit (slots) is increased
add_action('fluent_cart_sl/license_limit_increased', function ($data) {
    // Extract license model and previous limit count
    $license  = $data['license'];
    $oldCount = $data['old_count'];

    // Log activation limit increase
    fluent_cart_add_log(
        'License Limit Increased',
        sprintf('License #%d activation limit increased from %d', $license->id, $oldCount),
        'info'
    );
}, 10, 1);
```

---

## License Key & Validity

### `license_key_regenerated` (Pro)
`fluent_cart_sl/license_key_regenerated` — Fires when a license key is regenerated

* **When it runs:** This action fires when a license key is regenerated, replacing the old key with a new one.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Models/License.php` (line 318)

#### Parameters:
`$data` *(array)*: License key change data
* `license` *(\FluentCart\App\Models\License)* — The license model with the new key
* `old_key` *(string)* — The previous license key

#### Usage Example:
```php
// Hook when a license key is regenerated
add_action('fluent_cart_sl/license_key_regenerated', function ($data) {
    // Extract license model and previous key string
    $license = $data['license'];
    $oldKey  = $data['old_key'];

    // Log license key regeneration event
    fluent_cart_add_log(
        'License Key Regenerated',
        sprintf('License #%d key was regenerated', $license->id),
        'info'
    );
}, 10, 1);
```

---

### `license_validity_extended` (Pro)
`fluent_cart_sl/license_validity_extended` — Fires when a license expiration date is changed

* **When it runs:** This action fires when a license's expiration date is modified to a new date.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Models/License.php` (line 348)

#### Parameters:
`$data` *(array)*: License validity change data
* `license` *(\FluentCart\App\Models\License)* — The license model
* `old_date` *(string)* — The previous expiration date
* `new_date` *(string)* — The new expiration date

#### Usage Example:
```php
// Hook when a license expiration date is modified
add_action('fluent_cart_sl/license_validity_extended', function ($data) {
    // Extract license model and expiration dates
    $license = $data['license'];
    $oldDate = $data['old_date'];
    $newDate = $data['new_date'];

    // Log license expiration change
    fluent_cart_add_log(
        'License Validity Extended',
        sprintf('License #%d expiration changed from %s to %s', $license->id, $oldDate, $newDate),
        'info'
    );
}, 10, 1);
```

---

## License Lifecycle

### `license_issued` (order) (Pro)
`fluent_cart/licensing/license_issued` — Fires when a new license is created for an order

* **When it runs:** This action fires when a new license is generated as part of an order fulfillment process.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Hooks/Handlers/LicenseGenerationHandler.php` (line 532)

#### Parameters:
`$data` *(array)*: License issuance data
* `license` *(\FluentCart\App\Models\License)* — The newly created license
* `data` *(array)* — License creation data
* `order` *(\FluentCart\App\Models\Order)* — The associated order
* `subscription` *(\FluentCart\App\Models\Subscription|null)* — The associated subscription, if any

#### Usage Example:
```php
// Hook when a new license is created for an order
add_action('fluent_cart/licensing/license_issued', function ($data) {
    // Extract license, order, and subscription models
    $license      = $data['license'];
    $order        = $data['order'];
    $subscription = $data['subscription'];

    // Notify customer about their new license via email
    wp_mail(
        $order->customer->email,
        'Your License Key',
        sprintf('Your license key for order #%d is: %s', $order->id, $license->license_key)
    );
}, 10, 1);
```

---

### `license_issued` (manager) (Pro)
`fluent_cart_sl/license_issued` — Fires when a license is issued via the license manager

* **When it runs:** This action fires when a license is created through the admin license management interface.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Services/LicenseManager.php` (line 261)

#### Parameters:
`$data` *(array)*: License issuance data
* `license` *(\FluentCart\App\Models\License)* — The newly created license
* `data` *(array)* — License creation data

#### Usage Example:
```php
// Hook when a license is issued via the admin manager
add_action('fluent_cart_sl/license_issued', function ($data) {
    // Extract newly created license and input data
    $license    = $data['license'];
    $createData = $data['data'];

    // Log manual license creation
    fluent_cart_add_log(
        'License Issued via Manager',
        sprintf('License #%d issued manually', $license->id),
        'info'
    );
}, 10, 1);
```

---

### `license_renewed` (Pro)
`fluent_cart/licensing/license_renewed` — Fires when a license expiration is extended on subscription renewal

* **When it runs:** This action fires when a license's expiration date is extended because the associated subscription has been successfully renewed.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Hooks/Handlers/LicenseGenerationHandler.php` (line 231)

#### Parameters:
`$data` *(array)*: License renewal data
* `license` *(\FluentCart\App\Models\License)* — The renewed license
* `subscription` *(\FluentCart\App\Models\Subscription)* — The associated subscription
* `prev_status` *(string)* — The previous license status

#### Usage Example:
```php
// Hook when a license expiration is extended on subscription renewal
add_action('fluent_cart/licensing/license_renewed', function ($data) {
    // Extract license, subscription, and previous status
    $license      = $data['license'];
    $subscription = $data['subscription'];
    $prevStatus   = $data['prev_status'];

    // Log license renewal event
    fluent_cart_add_log(
        'License Renewed',
        sprintf('License #%d renewed via subscription #%d', $license->id, $subscription->id),
        'info'
    );
}, 10, 1);
```

---

### `license_expired` (Pro)
`fluent_cart/licensing/license_expired` — Fires when a license expires due to subscription cancellation or scheduler

* **When it runs:** This action fires when a license is marked as expired, either because the associated subscription was cancelled or because the license scheduler determined it has passed its expiration date.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Hooks/Handlers/LicenseGenerationHandler.php` (line 267), `fluent-cart-pro/app/Modules/Licensing/Hooks/Handlers/LicenseSchedulerHandler.php` (line 46)

#### Parameters:
`$data` *(array)*: License expiration data
* `license` *(\FluentCart\App\Models\License)* — The expired license
* `subscription` *(\FluentCart\App\Models\Subscription)* — The associated subscription
* `prev_status` *(string)* — The previous license status

#### Usage Example:
```php
// Hook when a license expires due to subscription cancellation or scheduler
add_action('fluent_cart/licensing/license_expired', function ($data) {
    // Extract license, subscription, and previous status
    $license      = $data['license'];
    $subscription = $data['subscription'];
    $prevStatus   = $data['prev_status'];

    // Notify customer about license expiration via email
    wp_mail(
        $license->customer->email,
        'License Expired',
        sprintf('Your license #%d has expired.', $license->id)
    );
}, 10, 1);
```

---

### `license_disabled` (Pro)
`fluent_cart/licensing/license_disabled` — Fires when a license is disabled due to payment failure or refund

* **When it runs:** This action fires when a license is disabled, typically because the associated order's payment failed or a refund was processed.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Hooks/Handlers/LicenseGenerationHandler.php` (lines 158, 196)

#### Parameters:
`$data` *(array)*: License disabled data
* `license` *(\FluentCart\App\Models\License)* — The disabled license
* `order` *(\FluentCart\App\Models\Order)* — The associated order
* `reason` *(string|undefined)* — The reason for disabling (only present on payment failure; absent on refund)

#### Usage Example:
```php
// Hook when a license is disabled due to payment failure or refund
add_action('fluent_cart/licensing/license_disabled', function ($data) {
    // Extract license, order, and disabling reason
    $license = $data['license'];
    $order   = $data['order'];
    $reason  = $data['reason'] ?? '';

    // Log license disable event
    fluent_cart_add_log(
        'License Disabled',
        sprintf('License #%d disabled for order #%d. Reason: %s', $license->id, $order->id, $reason ?: 'refund'),
        'warning'
    );
}, 10, 1);
```

---

### `extended_to_lifetime` (Pro)
`fluent_cart/licensing/extended_to_lifetime` — Fires when a license is extended to lifetime on subscription end-of-term

* **When it runs:** This action fires when a license is converted to a lifetime license because its associated subscription has completed all billing cycles (end-of-term).
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Hooks/Handlers/LicenseGenerationHandler.php` (line 302)

#### Parameters:
`$data` *(array)*: License lifetime extension data
* `license` *(\FluentCart\App\Models\License)* — The license extended to lifetime
* `subscription` *(\FluentCart\App\Models\Subscription)* — The associated subscription
* `prev_status` *(string)* — The previous license status

#### Usage Example:
```php
// Hook when a license is extended to lifetime on subscription end-of-term
add_action('fluent_cart/licensing/extended_to_lifetime', function ($data) {
    // Extract license, subscription, and previous status
    $license      = $data['license'];
    $subscription = $data['subscription'];
    $prevStatus   = $data['prev_status'];

    // Notify customer about lifetime upgrade via email
    wp_mail(
        $license->customer->email,
        'License Extended to Lifetime',
        sprintf('Your license #%d has been extended to lifetime access!', $license->id)
    );
}, 10, 1);
```

---

### `license_upgraded` (Pro)
`fluent_cart/licensing/license_upgraded` — Fires when a license is upgraded to a new plan

* **When it runs:** This action fires when a license is upgraded to a different plan, typically through a plan change or upgrade flow.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Hooks/Handlers/LicenseGenerationHandler.php` (line 375)

#### Parameters:
`$data` *(array)*: License upgrade data
* `license` *(\FluentCart\App\Models\License)* — The upgraded license
* `order` *(\FluentCart\App\Models\Order)* — The associated order
* `subscription` *(\FluentCart\App\Models\Subscription)* — The associated subscription
* `updates` *(array)* — The update data applied to the license

#### Usage Example:
```php
// Hook when a license is upgraded to a new plan
add_action('fluent_cart/licensing/license_upgraded', function ($data) {
    // Extract upgraded license, order, subscription, and update parameters
    $license      = $data['license'];
    $order        = $data['order'];
    $subscription = $data['subscription'];
    $updates      = $data['updates'];

    // Log license upgrade event
    fluent_cart_add_log(
        'License Upgraded',
        sprintf('License #%d upgraded for order #%d', $license->id, $order->id),
        'info'
    );
}, 10, 1);
```

---

### `license_deleted` (admin) (Pro)
`fluent_cart_sl/license_deleted` — Fires when a license is deleted from the admin interface

* **When it runs:** This action fires when an admin deletes a license through the license management UI.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Http/Controllers/LicenseController.php` (line 255)

#### Parameters:
`$data` *(array)*: License deletion data
* `license` *(\FluentCart\App\Models\License)* — The license being deleted

#### Usage Example:
```php
// Hook when a license is deleted from the admin interface
add_action('fluent_cart_sl/license_deleted', function ($data) {
    // Extract deleted license model instance
    $license = $data['license'];

    // Log admin license deletion
    fluent_cart_add_log(
        'License Deleted',
        sprintf('License #%d was deleted by admin', $license->id),
        'warning'
    );
}, 10, 1);
```

---

### `license_deleted` (order deleted) (Pro)
`fluent_cart/licensing/license_deleted` — Fires when a license is deleted because its parent order was deleted

* **When it runs:** This action fires when a license is automatically deleted as a result of its parent order being deleted.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Hooks/license-actions.php` (line 141)

#### Parameters:
`$data` *(array)*: License deletion data
* `license` *(\FluentCart\App\Models\License)* — The license being deleted
* `order` *(\FluentCart\App\Models\Order)* — The parent order being deleted

#### Usage Example:
```php
// Hook when a license is deleted because its parent order was deleted
add_action('fluent_cart/licensing/license_deleted', function ($data) {
    // Extract license and parent order being deleted
    $license = $data['license'];
    $order   = $data['order'];

    // Log automatic license deletion with order
    fluent_cart_add_log(
        'License Deleted with Order',
        sprintf('License #%d deleted because order #%d was deleted', $license->id, $order->id),
        'warning'
    );
}, 10, 1);
```

---

## License Site Activation

### `site_activated` (API) (Pro)
`fluent_cart/license/site_activated` — Fires when a site is activated for a license via the public API

* **When it runs:** This action fires when a site is successfully activated for a license through the external licensing API.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Hooks/Handlers/LicenseApiHandler.php` (line 255)

#### Parameters:
* `$site` *(\FluentCart\App\Models\LicenseSite)* — The activated site
* `$activation` *(\FluentCart\App\Models\LicenseActivation)* — The license activation record
* `$license` *(\FluentCart\App\Models\License)* — The associated license
* `$data` *(array)* — The activation request data

#### Usage Example:
```php
// Hook when a site is activated for a license via the public API
add_action('fluent_cart/license/site_activated', function ($site, $activation, $license, $data) {
    // Log API site activation event
    fluent_cart_add_log(
        'Site Activated via API',
        sprintf('Site %s activated for license #%d', $site->site_url, $license->id),
        'info'
    );
}, 10, 4);
```

---

### `site_deactivated` (API) (Pro)
`fluent_cart/license/site_deactivated` — Fires when a site is deactivated via the public API

* **When it runs:** This action fires when a site is successfully deactivated for a license through the external licensing API.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Hooks/Handlers/LicenseApiHandler.php` (line 340)

#### Parameters:
* `$site` *(\FluentCart\App\Models\LicenseSite)* — The deactivated site
* `$activation` *(\FluentCart\App\Models\LicenseActivation)* — The license activation record
* `$license` *(\FluentCart\App\Models\License)* — The associated license
* `$data` *(array)* — The deactivation request data

#### Usage Example:
```php
// Hook when a site is deactivated via the public API
add_action('fluent_cart/license/site_deactivated', function ($site, $activation, $license, $data) {
    // Log API site deactivation event
    fluent_cart_add_log(
        'Site Deactivated via API',
        sprintf('Site %s deactivated for license #%d', $site->site_url, $license->id),
        'info'
    );
}, 10, 4);
```

---

### `site_deactivated_failed` (Pro)
`fluent_cart/license/site_deactivated_failed` — Fires when a site deactivation attempt fails

* **When it runs:** This action fires when a site deactivation request fails. This can happen for multiple reasons such as an invalid license key, site not found, or activation mismatch.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Hooks/Handlers/LicenseApiHandler.php` (lines 295, 309, 321)

#### Parameters:
* `$formattedData` *(array)* — Error information including the reason for failure

#### Usage Example:
```php
// Hook when a site deactivation attempt fails
add_action('fluent_cart/license/site_deactivated_failed', function ($formattedData) {
    // Log failed site deactivation error payload
    fluent_cart_add_log(
        'Site Deactivation Failed',
        wp_json_encode($formattedData),
        'error'
    );
}, 10, 1);
```

---

### `site_activated` (local) (Pro)
`fluent_cart_sl/site_activated` — Fires when a site is activated via the local API method

* **When it runs:** This action fires when a site is activated through the internal (local) license site management method.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Concerns/CanManageLicenseSites.php` (line 84)

#### Parameters:
`$data` *(array)*: Site activation data
* `site` *(\FluentCart\App\Models\LicenseSite)* — The activated site
* `license` *(\FluentCart\App\Models\License)* — The associated license
* `activation` *(\FluentCart\App\Models\LicenseActivation)* — The license activation record

#### Usage Example:
```php
// Hook when a site is activated via the local API method
add_action('fluent_cart_sl/site_activated', function ($data) {
    // Extract site, license, and activation models
    $site       = $data['site'];
    $license    = $data['license'];
    $activation = $data['activation'];

    // Log local site activation event
    fluent_cart_add_log(
        'Site Activated Locally',
        sprintf('Site %s activated for license #%d', $site->site_url, $license->id),
        'info'
    );
}, 10, 1);
```

---

### `site_license_deactivated` (Pro)
`fluent_cart_sl/site_license_deactivated` — Fires when a license is deactivated from a site (admin or customer)

* **When it runs:** This action fires when a license is deactivated from a specific site, either by an admin through the management interface or by the customer through their profile.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Concerns/CanManageLicenseSites.php` (lines 141, 177), `fluent-cart-pro/app/Modules/Licensing/Http/Controllers/CustomerProfileController.php` (line 192)

#### Parameters:
`$data` *(array)*: Site deactivation data
* `site` *(\FluentCart\App\Models\LicenseSite)* — The site being deactivated
* `license` *(\FluentCart\App\Models\License)* — The associated license

#### Usage Example:
```php
// Hook when a license is deactivated from a site (admin or customer)
add_action('fluent_cart_sl/site_license_deactivated', function ($data) {
    // Extract site and license model instances
    $site    = $data['site'];
    $license = $data['license'];

    // Log site license deactivation
    fluent_cart_add_log(
        'Site License Deactivated',
        sprintf('License #%d deactivated from site %s', $license->id, $site->site_url),
        'info'
    );
}, 10, 1);
```

---

## Bulk License Operations

### `before_deleting_licenses` (Pro)
`fluent_cart_sl/before_deleting_licenses` — Fires before licenses are bulk deleted by order

* **When it runs:** This action fires immediately before a collection of licenses is deleted as part of a bulk operation (e.g., when an order is deleted).
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Services/LicenseManager.php` (line 232)

#### Parameters:
`$data` *(array)*: Bulk deletion data
* `licenses` *(\Illuminate\Support\Collection)* — Collection of License models about to be deleted

#### Usage Example:
```php
// Hook before licenses are bulk deleted by order
add_action('fluent_cart_sl/before_deleting_licenses', function ($data) {
    // Extract collection of licenses about to be deleted
    $licenses = $data['licenses'];

    // Log each license in bulk deletion queue
    foreach ($licenses as $license) {
        fluent_cart_add_log('License Bulk Delete', sprintf('About to delete license #%d', $license->id), 'warning');
    }
}, 10, 1);
```

---

### `after_deleting_licenses` (Pro)
`fluent_cart_sl/after_deleting_licenses` — Fires after licenses are bulk deleted

* **When it runs:** This action fires immediately after a collection of licenses has been deleted.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Services/LicenseManager.php` (line 237)

#### Parameters:
`$data` *(array)*: Bulk deletion data
* `licenses` *(\Illuminate\Support\Collection)* — Collection of License models that were deleted

#### Usage Example:
```php
// Hook after licenses are bulk deleted
add_action('fluent_cart_sl/after_deleting_licenses', function ($data) {
    // Extract collection of deleted licenses
    $licenses = $data['licenses'];

    // Log completion of bulk license deletion
    fluent_cart_add_log('Licenses Bulk Deleted', sprintf('%d licenses were deleted', $licenses->count()), 'warning');
}, 10, 1);
```

---

### `before_updating_licenses_status` (Pro)
`fluent_cart_sl/before_updating_licenses_status` — Fires before a bulk license status update

* **When it runs:** This action fires immediately before a collection of licenses has their status updated in bulk.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Services/LicenseManager.php` (line 285)

#### Parameters:
`$data` *(array)*: Bulk status update data
* `licenses` *(\Illuminate\Support\Collection)* — Collection of License models about to be updated

#### Usage Example:
```php
// Hook before a bulk license status update
add_action('fluent_cart_sl/before_updating_licenses_status', function ($data) {
    // Extract collection of licenses about to be updated
    $licenses = $data['licenses'];

    // Log or validate before bulk status change
}, 10, 1);
```

---

### `before_updating_licenses_status_to_disabled` (Pro)
`fluent_cart_sl/before_updating_licenses_status_to_disabled` — Fires before licenses are bulk disabled

* **When it runs:** This action fires immediately before a collection of licenses is bulk-disabled.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Services/LicenseManager.php` (line 286)

#### Parameters:
`$data` *(array)*: Bulk disable data
* `licenses` *(\Illuminate\Support\Collection)* — Collection of License models about to be disabled

#### Usage Example:
```php
// Hook before licenses are bulk disabled
add_action('fluent_cart_sl/before_updating_licenses_status_to_disabled', function ($data) {
    // Extract collection of licenses about to be disabled
    $licenses = $data['licenses'];

    // Perform pre-disable checks
}, 10, 1);
```

---

### `after_updating_licenses_status` (Pro)
`fluent_cart_sl/after_updating_licenses_status` — Fires after a bulk license status update

* **When it runs:** This action fires immediately after a collection of licenses has had their status updated in bulk.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Services/LicenseManager.php` (line 290)

#### Parameters:
`$data` *(array)*: Bulk status update data
* `licenses` *(\Illuminate\Support\Collection)* — Collection of License models that were updated

#### Usage Example:
```php
// Hook after a bulk license status update
add_action('fluent_cart_sl/after_updating_licenses_status', function ($data) {
    // Extract collection of updated license models
    $licenses = $data['licenses'];

    // Log completion of bulk status update
    fluent_cart_add_log('Licenses Status Updated', sprintf('%d licenses updated', $licenses->count()), 'info');
}, 10, 1);
```

---

### `after_updating_licenses_status_to_disabled` (Pro)
`fluent_cart_sl/after_updating_licenses_status_to_disabled` — Fires after licenses are bulk disabled

* **When it runs:** This action fires immediately after a collection of licenses has been bulk-disabled.
* **Source:** `fluent-cart-pro/app/Modules/Licensing/Services/LicenseManager.php` (line 291)

#### Parameters:
`$data` *(array)*: Bulk disable data
* `licenses` *(\Illuminate\Support\Collection)* — Collection of License models that were disabled

#### Usage Example:
```php
// Hook after licenses are bulk disabled
add_action('fluent_cart_sl/after_updating_licenses_status_to_disabled', function ($data) {
    // Extract collection of disabled license models
    $licenses = $data['licenses'];

    // Log completion of bulk disable action
    fluent_cart_add_log('Licenses Bulk Disabled', sprintf('%d licenses disabled', $licenses->count()), 'warning');
}, 10, 1);
```

---

# Action Hooks: Orders

All hooks related to order lifecycle, status transitions, payments, shipping, refunds, and order items. These action hooks allow you to respond to key order events in FluentCart.

Each hook passes an associative array as its single parameter. The order value is always an `\FluentCart\App\Models\Order` model instance with the `customer`, `shipping_address`, and `billing_address` relationships eager-loaded (unless noted otherwise).

Amounts are in cents. All monetary values (`total`, `refunded_amount`, etc.) are stored as integers in the smallest currency unit. Use `Helper::toDecimal($amount)` to convert for display.

---

## Order Status Changes
Fired when the order status field changes (e.g. `processing` → `completed`). Both a dynamic, status-specific hook and a generic hook fire on every change.

### `order_status_changed_to_{status}`
`fluent_cart/order_status_changed_to_{$newStatus}` — Fires when the order status changes to a specific status

* **When it runs:** Fires inside `OrderStatusUpdated::afterDispatch()` whenever the order status type transitions to a new value. The `{$newStatus}` portion is replaced dynamically with the target status, so you can listen for a single status you care about.
* **Available dynamic variants:** `completed`, `canceled`, `processing`, `on-hold`, `failed`
* **Source:** `app/Events/Order/OrderStatusUpdated.php` (line 91)

#### Parameters:
`$data` *(array)*: Order status change data
```php
$data = [
    'order'       => $order,       // \FluentCart\App\Models\Order (with customer, addresses loaded)
    'old_status'  => 'processing', // Previous order status string
    'new_status'  => 'completed',  // New order status string (matches the dynamic suffix)
    'manageStock' => true,         // Whether stock management should be applied
    'activity'    => [             // Optional activity log context
        'title'   => '',
        'content' => '',
    ],
];
```

#### Usage Example:
```php
// Hook into order status change to 'completed'
add_action('fluent_cart/order_status_changed_to_completed', function ($data) {
    // Extract order model from event data
    $order = $data['order'];
    // Grant digital access when order completes
    grant_digital_access($order->customer_id, $order->id);
}, 10, 1);
```

---

### `order_status_changed`
`fluent_cart/order_status_changed` — Fires on any order status change

* **When it runs:** Fires immediately after the dynamic `order_status_changed_to_{$newStatus}` hook, on every order status transition regardless of the target status. Use this when you need to react to all status changes in a single callback.
* **Source:** `app/Events/Order/OrderStatusUpdated.php` (line 92)

#### Parameters:
`$data` *(array)*: Order status change data
```php
$data = [
    'order'       => $order,       // \FluentCart\App\Models\Order
    'old_status'  => 'processing', // Previous order status
    'new_status'  => 'completed',  // New order status
    'manageStock' => true,         // Whether stock management applies
    'activity'    => [
        'title'   => '',
        'content' => '',
    ],
];
```

#### Usage Example:
```php
// Hook into any order status change
add_action('fluent_cart/order_status_changed', function ($data) {
    // Extract order model from event data
    $order = $data['order'];
    // Log every status transition into FluentCart logs
    fluent_cart_add_log(
        'Order status changed',
        sprintf('Order #%d: %s -> %s', $order->id, $data['old_status'], $data['new_status']),
        'info'
    );
}, 10, 1);
```

---

## Payment Status Changes
Fired when the payment status field changes (e.g. `pending` → `paid`). Both a dynamic, status-specific hook and a generic hook fire on every change.

### `payment_status_changed_to_{status}`
`fluent_cart/payment_status_changed_to_{$newStatus}` — Fires when payment status changes to a specific status

* **When it runs:** Fires inside `OrderStatusUpdated::afterDispatch()` when the status change type is `payment_status`. The `{$newStatus}` suffix is replaced dynamically so you can target a single payment state.
* **Available dynamic variants:** `pending`, `paid`, `partially_paid`, `failed`, `refunded`, `partially_refunded`, `authorized`
* **Source:** `app/Events/Order/OrderStatusUpdated.php` (line 81)

#### Parameters:
`$data` *(array)*: Payment status change data
```php
$data = [
    'order'       => $order,     // \FluentCart\App\Models\Order
    'old_status'  => 'pending',  // Previous payment status
    'new_status'  => 'paid',     // New payment status (matches the dynamic suffix)
    'manageStock' => true,       // Whether stock management applies
    'activity'    => [
        'title'   => '',
        'content' => '',
    ],
];
```

#### Usage Example:
```php
// Hook into payment status change to 'paid'
add_action('fluent_cart/payment_status_changed_to_paid', function ($data) {
    // Extract order model from event data
    $order = $data['order'];
    // Trigger fulfillment workflow when payment is confirmed
    do_action('my_custom_fulfillment_start', $order->id);
}, 10, 1);
```

---

### `payment_status_changed`
`fluent_cart/payment_status_changed` — Fires on any payment status change

* **When it runs:** Fires immediately after the dynamic `payment_status_changed_to_{$newStatus}` hook, on every payment status transition. Use this when you need a single callback for all payment status changes.
* **Source:** `app/Events/Order/OrderStatusUpdated.php` (line 82)

#### Parameters:
`$data` *(array)*: Payment status change data
```php
$data = [
    'order'       => $order,     // \FluentCart\App\Models\Order
    'old_status'  => 'pending',  // Previous payment status
    'new_status'  => 'paid',     // New payment status
    'manageStock' => true,       // Whether stock management applies
    'activity'    => [
        'title'   => '',
        'content' => '',
    ],
];
```

#### Usage Example:
```php
// Hook into any payment status change
add_action('fluent_cart/payment_status_changed', function ($data) {
    // Extract order model from event data
    $order = $data['order'];
    // Send payment status update notification email if paid
    if ($data['new_status'] === 'paid') {
        wp_mail($order->customer->email, 'Payment Confirmed', 'Your payment has been received.');
    }
}, 10, 1);
```

---

## Shipping Status Changes
Fired when the shipping status field changes (e.g. `unshipped` → `shipped`). Both a dynamic, status-specific hook and a generic hook fire on every change.

### `shipping_status_changed_to_{status}`
`fluent_cart/shipping_status_changed_to_{$newStatus}` — Fires when shipping status changes to a specific status

* **When it runs:** Fires inside `OrderStatusUpdated::afterDispatch()` when the status change type is `shipping_status`. The `{$newStatus}` suffix is replaced dynamically so you can target a single shipping state.
* **Available dynamic variants:** `unshipped`, `shipped`, `delivered`, `unshippable`
* **Source:** `app/Events/Order/OrderStatusUpdated.php` (line 86)

#### Parameters:
`$data` *(array)*: Shipping status change data
```php
$data = [
    'order'       => $order,      // \FluentCart\App\Models\Order
    'old_status'  => 'unshipped', // Previous shipping status
    'new_status'  => 'shipped',   // New shipping status (matches the dynamic suffix)
    'manageStock' => true,        // Whether stock management applies
    'activity'    => [
        'title'   => '',
        'content' => '',
    ],
];
```

#### Usage Example:
```php
// Hook into shipping status change to 'shipped'
add_action('fluent_cart/shipping_status_changed_to_shipped', function ($data) {
    // Extract order model from event data
    $order = $data['order'];
    // Notify customer that their order has shipped via email
    wp_mail(
        $order->customer->email,
        'Your Order Has Shipped!',
        sprintf('Order #%d has been shipped.', $order->id)
    );
}, 10, 1);
```

---

### `shipping_status_changed`
`fluent_cart/shipping_status_changed` — Fires on any shipping status change

* **When it runs:** Fires immediately after the dynamic `shipping_status_changed_to_{$newStatus}` hook, on every shipping status transition. Use this when you need a single callback for all shipping status changes.
* **Source:** `app/Events/Order/OrderStatusUpdated.php` (line 87)

#### Parameters:
`$data` *(array)*: Shipping status change data
```php
$data = [
    'order'       => $order,      // \FluentCart\App\Models\Order
    'old_status'  => 'unshipped', // Previous shipping status
    'new_status'  => 'shipped',   // New shipping status
    'manageStock' => true,        // Whether stock management applies
    'activity'    => [
        'title'   => '',
        'content' => '',
    ],
];
```

#### Usage Example:
```php
// Hook into any shipping status change
add_action('fluent_cart/shipping_status_changed', function ($data) {
    // Extract order model from event data
    $order = $data['order'];
    // Log all shipping status transitions in system logs
    fluent_cart_add_log(
        'Shipping status changed',
        sprintf('Order #%d: %s -> %s', $order->id, $data['old_status'], $data['new_status']),
        'info'
    );
}, 10, 1);
```

---

## Refunds
Fired during the refund flow after transaction records have been created. The generic `order_refunded` hook fires on every refund, followed by either `order_fully_refunded` or `order_partially_refunded` depending on the refund type. Refund data includes the Order, OrderItem, OrderTransaction, and Customer models.

### `order_refunded`
`fluent_cart/order_refunded` — Fires after any refund (full or partial)

* **When it runs:** Fires inside `OrderRefund::afterDispatch()` after a refund transaction is recorded and the refund amount is calculated. This hook fires for both full and partial refunds. It fires before the type-specific hooks below.
* **Source:** `app/Events/Order/OrderRefund.php` (line 141)

#### Parameters:
`$data` *(array)*: Refund data
```php
$data = [
    'order'              => $order,          // \FluentCart\App\Models\Order
    'refunded_items'     => [],              // Array of OrderItem models (looked up from refundedItemIds)
    'new_refunded_items' => [],              // Raw refunded items array with restore_quantity info
    'refunded_amount'    => 5000,            // Newly refunded amount in cents
    'manage_stock'       => true,            // Whether stock should be restored
    'transaction'        => $transaction,    // \FluentCart\App\Models\OrderTransaction (the refund transaction)
    'customer'           => $customer,       // \FluentCart\App\Models\Customer
    'type'               => 'full',          // 'full' or 'partial'
];
```

#### Usage Example:
```php
// Hook into any order refund event (full or partial)
add_action('fluent_cart/order_refunded', function ($data) {
    // Extract order model and calculate formatted decimal refund amount
    $order = $data['order'];
    $amount = \FluentCart\App\Helpers\Helper::toDecimal($data['refunded_amount']);
    // Notify admin of any processed refund
    wp_mail(
        get_option('admin_email'),
        sprintf('Refund on Order #%d', $order->id),
        sprintf('A %s refund of %s has been processed.', $data['type'], $amount)
    );
}, 10, 1);
```

---

### `order_fully_refunded`
`fluent_cart/order_fully_refunded` — Fires only when an order is fully refunded

* **When it runs:** Fires inside `OrderRefund::afterDispatch()` immediately after the generic `order_refunded` hook, but only when the total refunded amount meets or exceeds the order's total paid amount (i.e. full refund).
* **Source:** `app/Events/Order/OrderRefund.php` (line 144)

#### Parameters:
`$data` *(array)*: Full refund data (identical structure to `order_refunded`)
```php
$data = [
    'order'              => $order,          // \FluentCart\App\Models\Order
    'refunded_items'     => [],              // Array of OrderItem models
    'new_refunded_items' => [],              // Raw refunded items with restore_quantity
    'refunded_amount'    => 10000,           // Refunded amount in cents
    'manage_stock'       => true,            // Whether stock should be restored
    'transaction'        => $transaction,    // \FluentCart\App\Models\OrderTransaction
    'customer'           => $customer,       // \FluentCart\App\Models\Customer
    'type'               => 'full',          // Always 'full' for this hook
];
```

#### Usage Example:
```php
// Hook into full order refund event
add_action('fluent_cart/order_fully_refunded', function ($data) {
    // Extract order model from event data
    $order = $data['order'];
    // Revoke digital access on full refund
    update_user_meta($order->customer_id, 'membership_active', false);
}, 10, 1);
```

---

### `order_partially_refunded`
`fluent_cart/order_partially_refunded` — Fires only when an order is partially refunded

* **When it runs:** Fires inside `OrderRefund::afterDispatch()` immediately after the generic `order_refunded` hook, but only when the total refunded amount is less than the order's total paid amount (i.e. partial refund).
* **Source:** `app/Events/Order/OrderRefund.php` (line 146)

#### Parameters:
`$data` *(array)*: Partial refund data (identical structure to `order_refunded`)
```php
$data = [
    'order'              => $order,          // \FluentCart\App\Models\Order
    'refunded_items'     => [],              // Array of OrderItem models
    'new_refunded_items' => [],              // Raw refunded items with restore_quantity
    'refunded_amount'    => 3000,            // Refunded amount in cents
    'manage_stock'       => true,            // Whether stock should be restored
    'transaction'        => $transaction,    // \FluentCart\App\Models\OrderTransaction
    'customer'           => $customer,       // \FluentCart\App\Models\Customer
    'type'               => 'partial',       // Always 'partial' for this hook
];
```

#### Usage Example:
```php
// Hook into partial order refund event
add_action('fluent_cart/order_partially_refunded', function ($data) {
    // Extract order and customer models from event data
    $order = $data['order'];
    $customer = $data['customer'];
    // Notify customer of partial refund via email
    wp_mail(
        $customer->email,
        'Partial Refund Processed',
        sprintf('A partial refund has been issued for Order #%d.', $order->id)
    );
}, 10, 1);
```

---

## Order Items
Hooks that fire when custom line items on an order are being deleted. These are useful for cleanup or audit logging on custom `OrderItem` records.

### `order/before_custom_items_deleted`
`fluent_cart/order/before_custom_items_deleted` — Fires before custom line items are deleted

* **When it runs:** Fires inside `OrderResource::updateOrderItems()` just before custom order items (flagged as `is_custom`) are permanently deleted from the database. Only fires if the filtered collection of custom items is not empty.
* **Source:** `api/Resource/OrderResource.php` (line 535)

#### Parameters:
* `$customItems` *(\Illuminate\Support\Collection)*: Collection of `\FluentCart\App\Models\OrderItem` models about to be deleted (only items where `is_custom` is `true`)
* `$order` *(\FluentCart\App\Models\Order)*: The parent order model

#### Usage Example:
```php
// Hook before custom order items are deleted
add_action('fluent_cart/order/before_custom_items_deleted', function ($customItems, $order) {
    // Archive custom items before they are removed from the database
    foreach ($customItems as $item) {
        fluent_cart_add_log(
            'Custom item removed',
            sprintf('Item "%s" removed from Order #%d', $item->title, $order->id),
            'info'
        );
    }
}, 10, 2);
```

---

### `order/after_custom_items_deleted`
`fluent_cart/order/after_custom_items_deleted` — Fires after custom line items are deleted

* **When it runs:** Fires inside `OrderResource::updateOrderItems()` immediately after custom order items have been permanently deleted from the database. The collection still holds the model instances (now removed from DB). Only fires if the collection is not empty.
* **Source:** `api/Resource/OrderResource.php` (line 541)

#### Parameters:
* `$customItems` *(\Illuminate\Support\Collection)*: Collection of `\FluentCart\App\Models\OrderItem` models that were just deleted
* `$order` *(\FluentCart\App\Models\Order)*: The parent order model

#### Usage Example:
```php
// Hook after custom order items are deleted
add_action('fluent_cart/order/after_custom_items_deleted', function ($customItems, $order) {
    // Recalculate order totals after custom items are removed
    $order->recalculateTotals();
}, 10, 2);
```

---

## Order Lifecycle
General lifecycle hooks that fire at key moments during an Order's existence: invoice generation, Customer changes, payment completion, license generation, and receipt viewing.

### `order/invoice_number_added`
`fluent_cart/order/invoice_number_added` — Fires after an invoice/receipt number is assigned to an order

* **When it runs:** Fires in two places:
  1. Inside the `Order::booted()` created callback, immediately after a new order is persisted to the database with an invoice number already set (when payment status is `paid` at creation time).
  2. Inside `Order::generateReceiptNumber()`, when a receipt number is generated for an existing order that did not previously have one.
* **Source:** `app/Models/Order.php` (lines 60 and 734)

#### Parameters:
`$data` *(array)*: Order data
```php
$data = [
    'order' => $order, // \FluentCart\App\Models\Order
];
```

#### Usage Example:
```php
// Hook when invoice/receipt number is assigned to an order
add_action('fluent_cart/order/invoice_number_added', function ($data) {
    // Extract order model from event data
    $order = $data['order'];
    // Sync invoice number to external accounting system
    sync_to_accounting($order->id, $order->invoice_no, $order->receipt_number);
}, 10, 1);
```

---

### `order_customer_changed`
`fluent_cart/order_customer_changed` — Fires when the customer assigned to an order changes

* **When it runs:** Fires inside `OrderController::changeCustomer()` after the order (and any child orders and subscriptions) have been reassigned to a new customer, and both the old and new customer stats have been recounted.
* **Source:** `app/Http/Controllers/OrderController.php` (line 427)

#### Parameters:
`$data` *(array)*: Customer change data
```php
$data = [
    'order'               => $order,        // \FluentCart\App\Models\Order
    'old_customer'        => $oldCustomer,  // \FluentCart\App\Models\Customer|null
    'new_customer'        => $newCustomer,  // \FluentCart\App\Models\Customer
    'connected_order_ids' => [123, 124],    // Array of all order IDs updated (parent + children)
];
```

#### Usage Example:
```php
// Hook when the customer assigned to an order changes
add_action('fluent_cart/order_customer_changed', function ($data) {
    // Extract order and customer models from event data
    $order = $data['order'];
    $oldCustomer = $data['old_customer'];
    $newCustomer = $data['new_customer'];
    // Notify the new customer about the order account transfer
    wp_mail(
        $newCustomer->email,
        'Order Transferred to Your Account',
        sprintf('Order #%d has been assigned to your account.', $order->id)
    );
}, 10, 1);
```

---

### `order/generateMissingLicenses`
`fluent_cart/order/generateMissingLicenses` — Fires when an admin triggers license generation for an order

* **When it runs:** Fires inside `OrderController::generateLicense()` when an admin requests license generation for an order that has fewer licenses than expected. This allows license modules to hook in and create the missing license keys.
* **Source:** `app/Http/Controllers/OrderController.php` (line 225)

#### Parameters:
`$data` *(array)*: Order data
```php
$data = [
    'order' => $order, // \FluentCart\App\Models\Order (with order_items and licenses loaded)
];
```

#### Usage Example:
```php
// Hook when admin requests missing license generation for an order
add_action('fluent_cart/order/generateMissingLicenses', function ($data) {
    // Extract order model from event data
    $order = $data['order'];
    // Generate licenses for each eligible order item
    foreach ($order->order_items as $item) {
        generate_license_key($order->id, $item->product_id);
    }
}, 10, 1);
```

---

### `order_placed_offline`
`fluent_cart/order_placed_offline` — Fires when an order is placed via Cash on Delivery or other offline payment

* **When it runs:** Fires inside `CodHandler::processPayment()` after the order and its transaction have been created for an offline/COD payment. The Order, Customer, and transaction data are all available at this point. The order has its `customer`, `shipping_address`, and `billing_address` relationships loaded.
* **Source:** `app/Modules/PaymentMethods/Cod/CodHandler.php` (line 55)

#### Parameters:
`$data` *(array)*: Offline order data
```php
$data = [
    'order'       => $order,                  // \FluentCart\App\Models\Order
    'customer'    => $order->customer ?? [],   // \FluentCart\App\Models\Customer or empty array
    'transaction' => $transaction ?? [],        // \FluentCart\App\Models\OrderTransaction or empty array
];
```

#### Usage Example:
```php
// Hook when an order is placed via Cash on Delivery or offline payment
add_action('fluent_cart/order_placed_offline', function ($data) {
    // Extract order model from event data
    $order = $data['order'];
    // Notify warehouse of new COD order
    wp_mail(
        'warehouse@example.com',
        sprintf('New COD Order #%d', $order->id),
        'A new Cash on Delivery order needs to be prepared for shipment.'
    );
}, 10, 1);
```

---

### `order_paid_done`
`fluent_cart/order_paid_done` — Main lifecycle hook when order payment completes (recommended for integrations)

* **When it runs:** Fires asynchronously via Action Scheduler after an order's payment is confirmed as paid. The `OrderPaid` event enqueues a `fluent_cart/order_paid_ansyc_private_handle` async action, which validates the order is still paid, then dispatches this hook. This is the recommended hook for third-party integrations because it runs outside the payment gateway request cycle, avoiding race conditions and timeouts. For subscription or renewal orders, the associated Subscription model is included in the data.
* **Note:** The `subscription` key is only present when the order type is subscription or renewal.
* **Source:** `app/Hooks/actions.php` (line 159)

#### Parameters:
`$data` *(array)*: Order payment completion data
```php
$data = [
    'order'        => $order,        // \FluentCart\App\Models\Order
    'transaction'  => $transaction,  // \FluentCart\App\Models\OrderTransaction (latest successful transaction)
    'customer'     => $customer,     // \FluentCart\App\Models\Customer
    'subscription' => $subscription, // \FluentCart\App\Models\Subscription (only for subscription/renewal orders)
];
```

#### Usage Example:
```php
// Main lifecycle hook when order payment completes (recommended for integrations)
add_action('fluent_cart/order_paid_done', function ($data) {
    // Extract order and customer models from event data
    $order = $data['order'];
    $customer = $data['customer'];

    // Grant membership access after payment
    update_user_meta($customer->user_id, 'membership_active', true);

    // Handle subscription orders differently if subscription instance exists
    if (!empty($data['subscription'])) {
        $subscription = $data['subscription'];
        update_user_meta($customer->user_id, 'subscription_id', $subscription->id);
    }
}, 10, 1);
```

---

### `order_paid_ansyc_private_handle`
`fluent_cart/order_paid_ansyc_private_handle` — Internal async handler that processes post-payment integrations

* **When it runs:** Enqueued by `OrderPaid::afterDispatch()` as an Action Scheduler async action. The handler in `app/Hooks/actions.php` validates the order, clears the scheduler meta, and then dispatches `fluent_cart/order_paid_done`. It is also dispatched manually in `IntegrationEventListener` for retry scenarios. You should generally hook into `order_paid_done` instead of this hook.
* **Source:** `app/Listeners/IntegrationEventListener.php` (line 360), `app/Hooks/actions.php` (line 126)

#### Parameters:
`$data` *(array)*: Order identifier
```php
$data = [
    'order_id' => 123, // int: The order ID to process
];
```

#### Usage Example:
```php
// Internal async handler (Not recommended for third-party use; use fluent_cart/order_paid_done instead)
add_action('fluent_cart/order_paid_ansyc_private_handle', function ($data) {
    // Extract order ID from event data
    $orderId = $data['order_id'];
    // Internal processing only
}, 10, 1);
```

---

### `order/receipt_viewed`
`fluent_cart/order/receipt_viewed` — Fires the first time a customer views their order receipt

* **When it runs:** Fires at the end of receipt rendering (both the `ReceiptRenderer` class and the `receipt_slip.php` view template) when the `$is_first_time` flag is `true`. This means it only fires once per order, the very first time the receipt page is loaded. Subsequent views do not trigger this hook. The data includes both the Order and OrderOperation models.
* **Source:** `app/Services/Renderer/Receipt/ReceiptRenderer.php` (line 151), `app/Views/invoice/receipt_slip.php` (line 482)

#### Parameters:
`$data` *(array)*: Receipt view data
```php
$data = [
    'order'           => $order,           // \FluentCart\App\Models\Order
    'order_operation' => $order_operation,  // \FluentCart\App\Models\OrderOperation
];
```

#### Usage Example:
```php
// Hook when customer views their order receipt for the first time
add_action('fluent_cart/order/receipt_viewed', function ($data) {
    // Extract order model from event data
    $order = $data['order'];
    // Track receipt view for analytics logging
    fluent_cart_add_log(
        'Receipt viewed',
        sprintf('Customer viewed receipt for Order #%d', $order->id),
        'info',
        ['module_name' => 'order', 'module_id' => $order->id]
    );
}, 10, 1);
```

---

# Action Hooks: Payments & Integrations

All hooks related to payment processing, payment gateway webhooks, third-party integrations, file storage drivers, and development logging. Many of these hooks provide Order, Customer, and OrderTransaction model instances.

---

## Payment Events

### `payment_{$paymentStatus}`
`fluent_cart/payment_{$paymentStatus}` — Fires after order creation when a transaction succeeds

* **When it runs:** This dynamic action fires during Order finalization, after the transaction has been recorded and the payment status is determined. It only fires when the transaction status is one of the recognized success statuses (e.g. `paid`, `pending`). The `{$paymentStatus}` portion is replaced with the order's actual payment status.
* **Available dynamic variants:**
  - `fluent_cart/payment_paid` -- payment completed successfully
  - `fluent_cart/payment_pending` -- payment is pending confirmation
* **Source:** `api/Resource/OrderResource.php`

#### Parameters:
`$data` *(array)*: Order, Customer, and OrderTransaction data
```php
$data = [
    'order'       => $order,       // \FluentCart\App\Models\Order instance
    'customer'    => $customer,    // \FluentCart\App\Models\Customer (via $order->customer)
    'transaction' => $transaction, // \FluentCart\App\Models\OrderTransaction (via $order->latest_transaction)
];
```

#### Usage Example:
```php
// Hook into successful payment for any order creation
add_action('fluent_cart/payment_paid', function ($data) {
    // Extract order and customer models from event data
    $order = $data['order'];
    $customer = $data['customer'];

    // Grant access after successful payment
    update_user_meta($customer->user_id, 'has_premium_access', true);

    // Log successful payment event
    fluent_cart_add_log(
        'Payment Received',
        'Order #' . $order->id . ' paid successfully.',
        'success'
    );
}, 10, 1);
```

---

### `payment_{$transactionType}_{$paymentStatus}`
`fluent_cart/payment_{$transactionType}_{$paymentStatus}` — Fires after order creation with both transaction type and payment status

* **When it runs:** This dynamic action fires immediately after `fluent_cart/payment_{$paymentStatus}` during Order finalization. It provides more granular filtering by combining the transaction type (e.g. `one_time`, `subscription`) with the payment status (e.g. `paid`, `pending`).
* **Available dynamic variants:**
  - `fluent_cart/payment_one_time_paid` -- one-time purchase paid
  - `fluent_cart/payment_subscription_paid` -- subscription payment paid
  - `fluent_cart/payment_one_time_pending` -- one-time purchase pending
  - `fluent_cart/payment_subscription_pending` -- subscription payment pending
* **Source:** `api/Resource/OrderResource.php`

#### Parameters:
`$data` *(array)*: Order, customer, and transaction data
```php
$data = [
    'order'       => $order,       // \FluentCart\App\Models\Order instance
    'customer'    => $customer,    // \FluentCart\App\Models\Customer (via $order->customer)
    'transaction' => $transaction, // \FluentCart\App\Models\OrderTransaction (via $order->latest_transaction)
];
```

#### Usage Example:
```php
// Hook into paid subscription payment events
add_action('fluent_cart/payment_subscription_paid', function ($data) {
    // Extract order and transaction models from event data
    $order = $data['order'];
    $transaction = $data['transaction'];

    // Handle subscription-specific logic after payment
    fluent_cart_add_log(
        'Subscription Payment',
        'Subscription payment received for Order #' . $order->id,
        'success'
    );
}, 10, 1);
```

---

### `after_payment_{$paymentStatus}`
`fluent_cart/payments/after_payment_{$paymentStatus}` — Fires in abstract gateway after payment processing completes

* **When it runs:** This dynamic action fires inside the abstract payment gateway base class after a payment has been processed, the `OrderTransaction` recorded, and the `Order` status updated. It runs after `changeOrderStatus()` and any automatic digital-product completion logic. The `{$paymentStatus}` is the resulting payment status (e.g. `paid`, `failed`).
* **Source:** `app/Modules/PaymentMethods/Core/AbstractPaymentGateway.php`

#### Parameters:
`$data` *(array)*: The order that was just processed
```php
$data = [
    'order' => $order, // \FluentCart\App\Models\Order instance with updated status
];
```

#### Usage Example:
```php
// Hook after any payment gateway completes payment processing
add_action('fluent_cart/payments/after_payment_paid', function ($data) {
    // Extract order model instance
    $order = $data['order'];

    // Trigger external fulfillment webhook after payment confirmation
    wp_remote_post('https://fulfillment.example.com/api/orders', [
        'body' => wp_json_encode([
            'order_id' => $order->id,
            'total'    => $order->total_amount,
        ]),
    ]);
}, 10, 1);
```

---

### `payment_success`
`fluent_cart/payment_success` — Fires when an Airwallex or Square payment succeeds

* **When it runs:** This action fires inside the Airwallex and Square gateway handlers when a payment intent or payment object is confirmed as successful. The order status is updated to `processing` and payment status to `paid` before this hook runs.
* **Source:** `app/Modules/PaymentMethods/AirwallexGateway/Airwallex.php`, `app/Modules/PaymentMethods/SquareGateway/Square.php`

#### Parameters:
`$data` *(array)*: The order and payment intent/payment data
```php
$data = [
    'order'          => $order,         // \FluentCart\App\Models\Order with updated status
    'payment_intent' => $paymentIntent, // Gateway-specific payment intent or payment object (array)
];
```

#### Usage Example:
```php
// Hook when Airwallex or Square payment succeeds
add_action('fluent_cart/payment_success', function ($data) {
    // Extract order and payment intent payload
    $order = $data['order'];
    $paymentIntent = $data['payment_intent'];

    // Log the gateway-specific payment reference ID
    fluent_cart_add_log(
        'Gateway Payment Success',
        'Payment intent ' . $paymentIntent['id'] . ' for Order #' . $order->id,
        'success'
    );
}, 10, 1);
```

---

### `payment_failed`
`fluent_cart/payment_failed` — Fires when an Airwallex payment fails

* **When it runs:** This action fires inside the Airwallex gateway handler when a payment intent is determined to have failed. The order status and payment status are both set to `failed` before this hook runs.
* **Source:** `app/Modules/PaymentMethods/AirwallexGateway/Airwallex.php`

#### Parameters:
`$data` *(array)*: The order and failed payment intent data
```php
$data = [
    'order'          => $order,         // \FluentCart\App\Models\Order with failed status
    'payment_intent' => $paymentIntent, // Airwallex payment intent object (array)
];
```

#### Usage Example:
```php
// Hook when an Airwallex payment fails
add_action('fluent_cart/payment_failed', function ($data) {
    // Extract order and failed payment intent payload
    $order = $data['order'];
    $paymentIntent = $data['payment_intent'];

    // Notify admin via email about failed payment
    wp_mail(
        get_option('admin_email'),
        'Payment Failed - Order #' . $order->id,
        'Airwallex payment intent ' . $paymentIntent['id'] . ' failed.'
    );
}, 10, 1);
```

---

## Payment Gateway Registration

### `register_payment_methods`
`fluent_cart/register_payment_methods` — Register custom payment gateways

* **When it runs:** This action fires during initialization after all built-in payment gateways (Stripe, PayPal, Razorpay, Paystack, COD, Square, Airwallex) have been registered. Use this hook to register your own custom payment gateway with the gateway manager.
* **Source:** `app/Hooks/Handlers/GlobalPaymentHandler.php`

#### Parameters:
`$data` *(array)*: Contains the gateway manager instance
```php
$data = [
    'gatewayManager' => $gateway, // GatewayManager instance for registering gateways
];
```

#### Usage Example:
```php
// Hook to register custom payment gateways with gateway manager
add_action('fluent_cart/register_payment_methods', function ($data) {
    // Extract gateway manager instance
    $gatewayManager = $data['gatewayManager'];

    // Register a custom payment gateway class
    $gatewayManager->register('my_gateway', new MyCustomPaymentGateway());
}, 10, 1);
```

---

### `after_render_payment_method_{$route}`
`fluent-cart/after_render_payment_method_{$route}` — Fires after a payment method UI renders on the checkout page

* **When it runs:** This action fires after a payment method's frontend UI (logo or radio button) has been rendered on the checkout form. The `{$route}` is the gateway's route identifier. Note that this hook uses a hyphenated prefix (`fluent-cart/`) rather than the usual underscored prefix.
* **Available dynamic variants:** `fluent-cart/after_render_payment_method_stripe`, `fluent-cart/after_render_payment_method_paypal`, `fluent-cart/after_render_payment_method_square`, `fluent-cart/after_render_payment_method_airwallex`, `fluent-cart/after_render_payment_method_offline_payment`, `fluent-cart/after_render_payment_method_razorpay`, `fluent-cart/after_render_payment_method_paystack`
* **Source:** `app/Modules/PaymentMethods/Core/AbstractPaymentGateway.php`

#### Parameters: None.

#### Usage Example:
```php
// Hook after Stripe payment method UI renders on checkout form
add_action('fluent-cart/after_render_payment_method_stripe', function () {
    // Output custom security note below Stripe payment option
    echo '<p class="payment-note">Secure payments powered by Stripe.</p>';
}, 10, 0);
```

---

## Stripe Webhooks

### `stripe/webhook_{$eventType}`
`fluent_cart/payments/stripe/webhook_{$eventType}` — Fires for each Stripe webhook event

* **When it runs:** This dynamic action fires during Stripe webhook (IPN) processing after the event has been verified and the associated Order has been found. The `{$eventType}` is the Stripe event type with dots replaced by underscores (e.g. `invoice.payment_succeeded` becomes `invoice_payment_succeeded`).
* **Available dynamic variants:** `webhook_invoice_payment_succeeded`, `webhook_invoice_payment_failed`, `webhook_charge_refunded`, `webhook_customer_subscription_deleted`, `webhook_customer_subscription_updated`, `webhook_payment_intent_succeeded`, `webhook_payment_intent_payment_failed`
* **Source:** `app/Modules/PaymentMethods/StripeGateway/Webhook/IPN.php`

#### Parameters:
`$data` *(array)*: The Stripe event object and associated order
```php
$data = [
    'event' => $event, // Stripe Event object (contains type, data, etc.)
    'order' => $order, // \FluentCart\App\Models\Order instance (may be WP_Error if not found)
];
```

#### Usage Example:
```php
// Hook into Stripe charge refunded webhook event
add_action('fluent_cart/payments/stripe/webhook_charge_refunded', function ($data) {
    // Extract Stripe event object and order model
    $event = $data['event'];
    $order = $data['order'];

    // Exit early if order lookup failed
    if (is_wp_error($order)) {
        return;
    }

    $charge = $event->data->object;

    // Log custom refund webhook event
    fluent_cart_add_log(
        'Stripe Refund Webhook',
        'Charge ' . $charge->id . ' refunded for Order #' . $order->id,
        'info'
    );
}, 10, 1);
```

---

## PayPal Webhooks

### `paypal_webhook_received`
`fluent_cart/paypal_webhook_received` — Fires when raw PayPal webhook data is received before processing

* **When it runs:** This action fires early in PayPal webhook processing, after the webhook type has been validated against the list of supported events but before any event-specific handling occurs. Use this to log or inspect all incoming PayPal webhook payloads.
* **Source:** `app/Modules/PaymentMethods/PayPalGateway/IPN.php`

#### Parameters:
`$data` *(array)*: The parsed and raw webhook data
```php
$data = [
    'data' => $data,      // Parsed webhook payload (array)
    'raw'  => $post_data, // Raw POST body string
];
```

#### Usage Example:
```php
// Hook when raw PayPal webhook data is received before processing
add_action('fluent_cart/paypal_webhook_received', function ($data) {
    // Log all incoming raw PayPal webhooks for debugging
    error_log('PayPal webhook received: ' . wp_json_encode($data['data']));
}, 10, 1);
```

---

### `paypal/webhook_subscription_payment_received`
`fluent_cart/payments/paypal/webhook_subscription_payment_received` — Fires when a PayPal recurring subscription payment is received

* **When it runs:** This action fires when a PayPal `PAYMENT.SALE.COMPLETED` webhook is received and the resource contains a `billing_agreement_id`, indicating it is a recurring subscription payment rather than a one-time purchase.
* **Source:** `app/Modules/PaymentMethods/PayPalGateway/IPN.php`

#### Parameters:
`$data` *(array)*: The charge resource and billing agreement ID
```php
$data = [
    'charge'                 => $resource,           // PayPal sale resource object (array)
    'vendor_subscription_id' => $billingAgreementId, // PayPal billing agreement ID (string)
];
```

#### Usage Example:
```php
// Hook when a PayPal recurring subscription payment is received
add_action('fluent_cart/payments/paypal/webhook_subscription_payment_received', function ($data) {
    // Extract PayPal charge resource and billing agreement ID
    $charge = $data['charge'];
    $billingAgreementId = $data['vendor_subscription_id'];

    // Log recurring payment event
    fluent_cart_add_log(
        'PayPal Recurring Payment',
        'Billing agreement ' . $billingAgreementId . ' payment received.',
        'success'
    );
}, 10, 1);
```

---

### `paypal/webhook_payment_capture_completed`
`fluent_cart/payments/paypal/webhook_payment_capture_completed` — Fires when a PayPal one-time payment capture completes

* **When it runs:** This action fires when a PayPal `PAYMENT.SALE.COMPLETED` webhook arrives without a billing agreement ID (one-time payment), or when a `PAYMENT.CAPTURE.COMPLETED` event is received. Both indicate a successful one-time payment capture.
* **Source:** `app/Modules/PaymentMethods/PayPalGateway/IPN.php`

#### Parameters:
`$data` *(array)*: The charge resource from PayPal
```php
$data = [
    'charge' => $resource, // PayPal capture/sale resource object (array)
];
```

#### Usage Example:
```php
// Hook when a PayPal one-time payment capture completes
add_action('fluent_cart/payments/paypal/webhook_payment_capture_completed', function ($data) {
    // Extract PayPal charge capture resource
    $charge = $data['charge'];

    // Handle one-time payment capture confirmation log
    fluent_cart_add_log(
        'PayPal Capture Completed',
        'Capture completed for resource: ' . wp_json_encode($charge),
        'success'
    );
}, 10, 1);
```

---

### `paypal/webhook_payment_sale_refunded`
`fluent_cart/payments/paypal/webhook_payment_sale_refunded` — Fires when a PayPal recurring sale is refunded

* **When it runs:** This action fires when a PayPal `PAYMENT.SALE.REFUNDED` webhook is received, indicating that a refund has been issued for a recurring/subscription payment sale.
* **Source:** `app/Modules/PaymentMethods/PayPalGateway/IPN.php`

#### Parameters:
`$data` *(array)*: The refund resource from PayPal
```php
$data = [
    'refund' => $resource, // PayPal refund resource object (array)
];
```

#### Usage Example:
```php
// Hook when a PayPal recurring sale is refunded
add_action('fluent_cart/payments/paypal/webhook_payment_sale_refunded', function ($data) {
    // Extract PayPal refund resource object
    $refund = $data['refund'];

    // Log recurring payment sale refund event
    fluent_cart_add_log(
        'PayPal Sale Refund',
        'Recurring payment sale refunded: ' . wp_json_encode($refund),
        'info'
    );
}, 10, 1);
```

---

### `paypal/webhook_payment_capture_refunded`
`fluent_cart/payments/paypal/webhook_payment_capture_refunded` — Fires when a PayPal one-time payment capture is refunded

* **When it runs:** This action fires when a PayPal `PAYMENT.CAPTURE.REFUNDED` webhook is received, indicating that a refund has been issued for a one-time payment capture.
* **Source:** `app/Modules/PaymentMethods/PayPalGateway/IPN.php`

#### Parameters:
`$data` *(array)*: The refund resource from PayPal
```php
$data = [
    'refund' => $resource, // PayPal refund resource object (array)
];
```

#### Usage Example:
```php
// Hook when a PayPal one-time payment capture is refunded
add_action('fluent_cart/payments/paypal/webhook_payment_capture_refunded', function ($data) {
    // Extract PayPal capture refund resource object
    $refund = $data['refund'];

    // Log one-time payment refund event
    fluent_cart_add_log(
        'PayPal Capture Refund',
        'One-time payment capture refunded: ' . wp_json_encode($refund),
        'info'
    );
}, 10, 1);
```

---

### `paypal/webhook_{$eventType}` (disputes)
`fluent_cart/payments/paypal/webhook_{$eventType}` — Fires for PayPal customer dispute events

* **When it runs:** This dynamic action fires when a PayPal dispute-related webhook is received. The `{$eventType}` is the PayPal event type converted to lowercase with dots replaced by underscores.
* **Available dynamic variants:** `webhook_customer_dispute_created`, `webhook_customer_dispute_updated`, `webhook_customer_dispute_resolved`
* **Source:** `app/Modules/PaymentMethods/PayPalGateway/IPN.php`

#### Parameters:
`$data` *(array)*: The dispute resource from PayPal
```php
$data = [
    'dispute' => $resource, // PayPal dispute resource object (array)
];
```

#### Usage Example:
```php
// Hook when a PayPal customer dispute is created
add_action('fluent_cart/payments/paypal/webhook_customer_dispute_created', function ($data) {
    // Extract dispute payload
    $dispute = $data['dispute'];

    // Alert admin about a new PayPal customer dispute
    wp_mail(
        get_option('admin_email'),
        'PayPal Dispute Created',
        'A customer has opened a dispute. Details: ' . wp_json_encode($dispute)
    );
}, 10, 1);
```

---

## Mollie Webhooks (Pro)

### `mollie/webhook_subscription_payment_{$status}` (Pro)
`fluent_cart/payments/mollie/webhook_subscription_payment_{$status}` — Fires for each Mollie subscription payment status change

* **When it runs:** This dynamic action fires during Mollie webhook (IPN) processing when a subscription payment status is determined. The `{$status}` is replaced with the Mollie payment status (`paid`, `failed`, `expired`, `canceled`).
* **Available dynamic variants:** `webhook_subscription_payment_paid`, `webhook_subscription_payment_failed`, `webhook_subscription_payment_expired`, `webhook_subscription_payment_canceled`
* **Source:** `fluent-cart-pro/app/Modules/PaymentMethods/MollieGateway/Webhook/MollieIPN.php`

#### Parameters:
* `$molliePayment` *(object)* — The Mollie Payment object from the API
* `$order` *(\FluentCart\App\Models\Order)* — The Order model instance associated with this payment

#### Usage Example:
```php
// Hook for successful Mollie subscription payment (Pro)
add_action('fluent_cart/payments/mollie/webhook_subscription_payment_paid', function ($molliePayment, $order) {
    // Handle successful Mollie subscription payment log
    fluent_cart_add_log(
        'Mollie Subscription Payment',
        'Subscription payment received for Order #' . $order->id . ' (Mollie ID: ' . $molliePayment->id . ')',
        'success'
    );
}, 10, 2);
```

---

### `mollie/webhook_payment_{$status}` (Pro)
`fluent_cart/payments/mollie/webhook_payment_{$status}` — Fires for each Mollie one-time payment status change

* **When it runs:** This dynamic action fires during Mollie webhook processing when a one-time (non-subscription) payment status is determined. The `{$status}` is replaced with the Mollie payment status.
* **Available dynamic variants:** `webhook_payment_paid`, `webhook_payment_failed`, `webhook_payment_expired`, `webhook_payment_canceled`
* **Source:** `fluent-cart-pro/app/Modules/PaymentMethods/MollieGateway/Webhook/MollieIPN.php`

#### Parameters:
* `$molliePayment` *(object)* — The Mollie Payment object from the API
* `$order` *(\FluentCart\App\Models\Order)* — The Order model instance associated with this payment

#### Usage Example:
```php
// Hook for successful Mollie one-time payment (Pro)
add_action('fluent_cart/payments/mollie/webhook_payment_paid', function ($molliePayment, $order) {
    // Trigger external fulfillment for Mollie order
    wp_remote_post('https://fulfillment.example.com/api/orders', [
        'body' => wp_json_encode([
            'order_id'   => $order->id,
            'mollie_id'  => $molliePayment->id,
            'amount'     => $molliePayment->amount->value,
            'currency'   => $molliePayment->amount->currency,
        ]),
    ]);
}, 10, 2);
```

---

### `payment_failed` (Mollie) (Pro)
`fluent_cart/payment_failed` — Fires when a Mollie payment fails, is canceled, or expires

* **When it runs:** This action fires inside the Mollie IPN handler when a payment is determined to have failed, been canceled, or expired. The order status and payment status are updated before this hook runs.
* **Source:** `fluent-cart-pro/app/Modules/PaymentMethods/MollieGateway/Webhook/MollieIPN.php`

#### Parameters:
`$data` *(array)*: Payment failure data
```php
$data = [
    'order'              => $order,              // \FluentCart\App\Models\Order — with updated failed status
    'transaction'        => $transactionModel,   // \FluentCart\App\Models\OrderTransaction
    'old_payment_status' => $oldStatus,          // string — previous payment status
    'new_payment_status' => 'failed',            // string — new payment status
    'reason'             => $reason,             // string — 'failed', 'canceled', or 'expired'
];
```

#### Usage Example:
```php
// Hook when a Mollie payment fails, is canceled, or expires (Pro)
add_action('fluent_cart/payment_failed', function ($data) {
    // Extract order, transaction, and failure reason
    $order       = $data['order'];
    $transaction = $data['transaction'];
    $oldStatus   = $data['old_payment_status'];
    $newStatus   = $data['new_payment_status'];
    $reason      = $data['reason'];

    // Only handle Mollie failures in this callback
    if ($order->payment_method !== 'mollie') {
        return;
    }

    // Send email alert to admin regarding Mollie failure
    wp_mail(
        get_option('admin_email'),
        'Mollie Payment Failed - Order #' . $order->id,
        sprintf(
            "Payment for Order #%d has %s.\nPrevious status: %s\nNew status: %s\nTransaction ID: %s",
            $order->id,
            $reason,
            $oldStatus,
            $newStatus,
            $transaction->id
        )
    );
}, 10, 1);
```

---

## Paddle Webhooks (Pro)

### `paddle_webhook_received` (Pro)
`fluent_cart/paddle_webhook_received` — Fires when raw Paddle webhook data is received before processing

* **When it runs:** This action fires early in Paddle webhook processing, after the event type has been extracted from the payload but before any event-specific handling occurs. Use this to log or inspect all incoming Paddle webhook payloads for debugging purposes.
* **Source:** `fluent-cart-pro/app/Modules/PaymentMethods/PaddleGateway/Webhook/IPN.php`

#### Parameters:
* `$eventType` *(string)* — The Paddle event type (e.g. `transaction.paid`, `subscription.created`)
* `$data` *(array)* — The parsed webhook payload
* `$raw` *(string)* — The raw POST body string
* `$order` *(\FluentCart\App\Models\Order|null)* — The associated Order model instance, or `null` if not resolved

#### Usage Example:
```php
// Hook when raw Paddle webhook data is received before processing (Pro)
add_action('fluent_cart/paddle_webhook_received', function ($eventType, $data, $raw, $order) {
    // Log all incoming Paddle webhooks for debugging
    fluent_cart_add_log(
        'Paddle Webhook Received',
        sprintf(
            'Event: %s | Order: %s | Payload size: %d bytes',
            $eventType,
            $order ? '#' . $order->id : 'N/A',
            strlen($raw)
        ),
        'info'
    );
}, 10, 4);
```

---

### `paddle/webhook_{$eventType}` (Pro)
`fluent_cart/payments/paddle/webhook_{$eventType}` — Fires for each Paddle webhook event

* **When it runs:** This dynamic action fires during Paddle webhook (IPN) processing after the event has been received and the associated order has been resolved (if applicable). The `{$eventType}` is the Paddle event type with dots replaced by underscores.
* **Available dynamic variants:** `webhook_transaction_paid`, `webhook_transaction_completed`, `webhook_transaction_payment_failed`, `webhook_transaction_refunded`, `webhook_adjustment_created`, `webhook_adjustment_updated`, `webhook_subscription_created`, `webhook_subscription_activated`, `webhook_subscription_updated`, `webhook_subscription_canceled`, `webhook_subscription_paused`, `webhook_subscription_resumed`, `webhook_subscription_past_due`
* **Source:** `fluent-cart-pro/app/Modules/PaymentMethods/PaddleGateway/Webhook/IPN.php`

#### Parameters:
* `$eventType` *(string)* — The Paddle event type with dots replaced by underscores
* `$data` *(array)* — The parsed webhook payload
* `$raw` *(string)* — The raw POST body string
* `$order` *(\FluentCart\App\Models\Order|null)* — The associated Order model instance, or `null` if not resolved

#### Usage Example:
```php
// Hook when a Paddle transaction payment succeeds (Pro)
add_action('fluent_cart/payments/paddle/webhook_transaction_paid', function ($eventType, $data, $raw, $order) {
    if (!$order) {
        return;
    }

    // Handle successful Paddle transaction payment
    fluent_cart_add_log(
        'Paddle Transaction Paid',
        'Paddle payment completed for Order #' . $order->id,
        'success'
    );
}, 10, 4);

// Hook when a Paddle subscription is canceled (Pro)
add_action('fluent_cart/payments/paddle/webhook_subscription_canceled', function ($eventType, $data, $raw, $order) {
    if (!$order) {
        return;
    }

    // Alert admin about Paddle subscription cancellation via email
    wp_mail(
        get_option('admin_email'),
        'Paddle Subscription Canceled - Order #' . $order->id,
        'A Paddle subscription has been canceled. Event data: ' . wp_json_encode($data)
    );
}, 10, 4);

// Hook when a Paddle transaction is refunded (Pro)
add_action('fluent_cart/payments/paddle/webhook_transaction_refunded', function ($eventType, $data, $raw, $order) {
    if (!$order) {
        return;
    }

    // Track Paddle refund event
    fluent_cart_add_log(
        'Paddle Refund',
        'Paddle transaction refunded for Order #' . $order->id,
        'warning'
    );
}, 10, 4);
```

---

## Integrations

### `register_integration_action`
`fluent_cart/register_integration_action` — Register custom integration actions during initialization

* **When it runs:** This action fires during WordPress `init` to allow registration of custom integration actions. Use this hook to register your integration provider so it appears in the FluentCart integration action settings.
* **Source:** `app/Modules/IntegrationActions/GlobalIntegrationActionHandler.php`

#### Parameters: None.

#### Usage Example:
```php
// Hook to register custom integration actions during initialization
add_action('fluent_cart/register_integration_action', function () {
    // Register a custom integration action provider via filter
    add_filter('fluent_cart/integration/get_global_integration_actions', function ($actions) {
        $actions['my_crm'] = [
            'title'    => 'My CRM',
            'logo'     => plugin_dir_url(__FILE__) . 'logo.png',
            'handler'  => 'MyCrmIntegrationHandler',
        ];
        return $actions;
    });
}, 10, 0);
```

---

### `authenticate_global_credentials_{$settingsKey}`
`fluent_cart/integration/authenticate_global_credentials_{$settingsKey}` — Verify integration credentials for a specific provider

* **When it runs:** This dynamic action fires when a user clicks the "Verify" or "Authenticate" button for an integration's global credentials in the FluentCart admin settings. The `{$settingsKey}` is the integration provider's settings key (e.g. `mailchimp`, `activecampaign`).
* **Source:** `app/Modules/Integrations/GlobalIntegrationSettings.php`

#### Parameters:
`$data` *(array)*: The settings key and integration configuration
```php
$data = [
    'settings_key' => $settingsKey, // string — Integration provider key
    'integration'  => $integration, // array — Integration settings data (unslashed)
];
```

#### Usage Example:
```php
// Hook to verify integration credentials for a specific provider
add_action('fluent_cart/integration/authenticate_global_credentials_my_crm', function ($data) {
    // Extract API key from integration settings payload
    $apiKey = $data['integration']['api_key'] ?? '';

    // Verify the API key with the external service endpoint
    $response = wp_remote_get('https://api.mycrm.com/verify', [
        'headers' => ['Authorization' => 'Bearer ' . $apiKey],
    ]);

    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        wp_send_json_error(['message' => 'Invalid API credentials.'], 400);
    }

    wp_send_json_success(['message' => 'Credentials verified successfully.']);
}, 10, 1);
```

---

### `save_global_integration_settings_{$settingsKey}`
`fluent_cart/integration/save_global_integration_settings_{$settingsKey}` — Save integration settings for a specific provider

* **When it runs:** This dynamic action fires when a user saves the global integration settings for a specific provider. The `{$settingsKey}` is the integration provider's settings key. The handler is expected to persist the settings and send a JSON response.
* **Source:** `app/Modules/Integrations/GlobalIntegrationSettings.php`

#### Parameters:
`$data` *(array)*: The settings key and integration configuration
```php
$data = [
    'settings_key' => $settingsKey, // string — Integration provider key
    'integration'  => $integration, // array — Integration settings data (unslashed)
];
```

#### Usage Example:
```php
// Hook to save integration settings for a specific provider
add_action('fluent_cart/integration/save_global_integration_settings_my_crm', function ($data) {
    // Extract integration settings array
    $settings = $data['integration'];

    // Persist integration settings into FluentCart options
    fluent_cart_update_option('my_crm_settings', $settings);

    wp_send_json_success([
        'message' => 'Settings saved successfully.',
    ]);
}, 10, 1);
```

---

### `integration/chained_{$route}`
`fluent_cart/integration/chained_{$route}` — Fires for chained data requests in cascading dropdowns

* **When it runs:** This dynamic action fires when the integration settings UI requests chained/dependent data for cascading dropdown fields. For example, after selecting a mailing list, this hook loads the available tags or groups for that list. The `{$route}` is the integration's route identifier.
* **Source:** `app/Modules/Integrations/GlobalIntegrationSettings.php`

#### Parameters:
`$data` *(array)*: The request data for the chained lookup
```php
$data = [
    'data' => $requestData, // array — Request data array (contains route, selected values, etc.)
];
```

#### Usage Example:
```php
// Hook for chained data requests in cascading dropdowns
add_action('fluent_cart/integration/chained_my_crm', function ($data) {
    // Extract request data and list ID
    $requestData = $data['data'];
    $listId = $requestData['list_id'] ?? '';

    // Fetch tags for the selected mailing list
    $tags = my_crm_get_tags($listId);

    wp_send_json_success([
        'tags' => $tags,
    ]);
}, 10, 1);
```

---

### `integration/run/{$provider}`
`fluent_cart/integration/run/{$provider}` — Execute a specific integration feed for a provider

* **When it runs:** This dynamic action fires when an integration feed needs to be executed for a specific provider, both in real-time (synchronous) and async (via scheduled actions) processing. The `{$provider}` is the integration provider's slug (e.g. `mailchimp`, `activecampaign`).
* **Source:** `app/Listeners/IntegrationEventListener.php`

#### Parameters:
`$integrationArray` *(array)*: The full integration feed configuration and context
```php
$integrationArray = [
    'provider'   => 'mailchimp',  // string — Integration provider slug
    'order'      => $order,       // \FluentCart\App\Models\Order instance
    'event_data' => $data,        // array — Event trigger data (may include subscription)
    'feed'       => [],           // array — Feed configuration array
];
```

#### Usage Example:
```php
// Hook to execute a specific integration feed for a provider
add_action('fluent_cart/integration/run/my_crm', function ($integrationArray) {
    // Extract order, feed config, and customer model
    $order = $integrationArray['order'];
    $feed = $integrationArray['feed'] ?? [];
    $customer = $order->customer;

    // Push customer data to external CRM via HTTP request
    wp_remote_post('https://api.mycrm.com/contacts', [
        'headers' => [
            'Authorization' => 'Bearer ' . fluent_cart_get_option('my_crm_api_key'),
            'Content-Type'  => 'application/json',
        ],
        'body' => wp_json_encode([
            'email' => $customer->email,
            'name'  => $customer->full_name,
            'tags'  => $feed['tags'] ?? [],
        ]),
    ]);
}, 10, 1);
```

---

### `global_notify_completed`
`fluent_cart/integrations/global_notify_completed` — Fires after all synchronous global notification feeds have completed

* **When it runs:** This action fires after all sync (non-async) global notification integration feeds have been processed for an order. It does not fire if there are async feeds still pending.
* **Source:** `app/Modules/Integrations/GlobalNotificationHandler.php`

#### Parameters:
* `$order` *(\FluentCart\App\Models\Order)* — The Order model instance
* `$feeds` *(array)* — Array of feed configurations that were processed

#### Usage Example:
```php
// Hook after all synchronous global notification feeds have completed
add_action('fluent_cart/integrations/global_notify_completed', function ($order, $feeds) {
    // Log completion of synchronous integrations for order
    fluent_cart_add_log(
        'Integrations Complete',
        count($feeds) . ' integration feeds processed for Order #' . $order->id,
        'info'
    );
}, 10, 2);
```

---

### `reindex_integration_feeds`
`fluent_cart/reindex_integration_feeds` — Fires when integration feeds need to be re-indexed

* **When it runs:** This action fires after integration feed configurations are saved or updated, both at the global level (via `IntegrationController`) and at the product level (via `ProductIntegrationsController`).
* **Source:** `app/Http/Controllers/IntegrationController.php`, `app/Http/Controllers/ProductIntegrationsController.php`

#### Parameters:
`$data` *(array)*: Empty array `[]`

#### Usage Example:
```php
// Hook when integration feeds need to be re-indexed
add_action('fluent_cart/reindex_integration_feeds', function ($data) {
    // Clear cached integration feed transient
    delete_transient('my_plugin_integration_cache');
}, 10, 1);
```

---

## Storage Drivers

### `register_storage_drivers`
`fluent_cart/register_storage_drivers` — Register custom file storage drivers

* **When it runs:** This action fires during WordPress `init` at priority 9, after the built-in Local and S3 storage drivers have been initialized. Use this hook to register a custom file storage driver (e.g. Google Cloud Storage, Azure Blob Storage) for digital product file delivery.
* **Source:** `app/Hooks/Handlers/GlobalStorageHandler.php`

#### Parameters: None.

#### Usage Example:
```php
// Hook to register custom file storage drivers
add_action('fluent_cart/register_storage_drivers', function () {
    // Register custom storage driver via filter
    add_filter('fluent_cart/storage_drivers', function ($drivers) {
        $drivers['gcs'] = [
            'title'   => 'Google Cloud Storage',
            'handler' => new MyGcsStorageDriver(),
        ];
        return $drivers;
    });
}, 10, 0);
```

---

## Development Logging

### `dev_log`
`fluent_cart/dev_log` — Fires for development and debug logging (requires `FLUENT_CART_DEV_MODE`)

* **When it runs:** This action fires at various points during payment gateway webhook processing (primarily in the PayPal IPN handler) when the `FLUENT_CART_DEV_MODE` constant is defined. It provides detailed diagnostic data for debugging webhook failures, signature verification issues, and missing transaction references.
* **Source:** `app/Modules/PaymentMethods/PayPalGateway/IPN.php` (multiple call sites)

#### Parameters:
`$data` *(array)*: Logging context with raw data and metadata
```php
$data = [
    'raw_data'    => $rawData,     // mixed — Raw webhook payload or resource data
    'status'      => 'failed',     // string — Log status: 'failed', 'received', etc.
    'title'       => 'Log title',  // string — Human-readable log title
    'log_type'    => 'webhook',    // string — Type of log entry
    'module_type' => 'paypal_ipn', // string — Module identifier
    'module_name' => 'PayPal',     // string — Display name of the module
];
```

#### Usage Example:
```php
// Hook for development and debug logging (requires FLUENT_CART_DEV_MODE)
add_action('fluent_cart/dev_log', function ($data) {
    // Format detailed diagnostic log entry string
    $logEntry = sprintf(
        "[%s] [%s] %s - %s\n%s\n\n",
        gmdate('Y-m-d H:i:s'),
        $data['status'] ?? 'unknown',
        $data['module_name'] ?? 'General',
        $data['title'] ?? 'No title',
        wp_json_encode($data['raw_data'] ?? [], JSON_PRETTY_PRINT)
    );

    // Write diagnostic entry to debug log file
    error_log($logEntry, 3, WP_CONTENT_DIR . '/fluent-cart-debug.log');
}, 10, 1);
```

---

# Action Hooks: Products & Coupons

Action hooks for Product lifecycle management, single product page rendering, product card display, and admin Coupon operations.

---

## Product Lifecycle
Hooks that fire during product create/update/duplicate operations in the admin.

### `product_duplicated`
`fluent_cart/product_duplicated` — Fired after a product is duplicated

* **When it runs:** This action fires after a Product has been fully duplicated, including all variants, taxonomy terms, and post meta. The database transaction has already been committed when this hook runs.
* **Source:** `app/Models/Product.php`

#### Parameters:
`$data` *(array)*: Duplication result data
```php
$data = [
    'original_product_id' => 123,        // int — The source product's post ID
    'new_product_id'      => 456,        // int — The newly created product's post ID
    'options'             => [
        'import_stock_management'   => true,  // bool — Whether stock settings were copied
        'import_license_settings'   => true,  // bool — Whether license settings were copied
        'import_downloadable_files' => false, // bool — Whether downloadable files were copied
    ],
];
```

#### Usage Example:
```php
// Hook after a product is duplicated in admin
add_action('fluent_cart/product_duplicated', function($data) {
    // Extract original and new product post IDs
    $originalId = $data['original_product_id'];
    $newId      = $data['new_product_id'];

    // Copy custom post meta that core duplication doesn't handle
    $custom = get_post_meta($originalId, '_my_custom_field', true);
    if ($custom) {
        update_post_meta($newId, '_my_custom_field', $custom);
    }
}, 10, 1);
```

---

### `product_updated`
`fluent_cart/product_updated` — Fired when a product is updated via the admin API

* **When it runs:** This action fires after a product has been successfully updated through the admin REST API (`ProductController`). It runs after `ProductResource::update()` has persisted all changes, including variants and product details.
* **Source:** `app/Http/Controllers/ProductController.php`

#### Parameters:
`$data` *(array)*: Contains the raw request data and the updated Product model
```php
$data = [
    'data'    => [              // array — Sanitized request payload
        'title'   => 'Product Name',
        'detail'  => [
            'variation_type' => 'simple',
            // ... other product detail fields
        ],
        'variants' => [
            // ... variant data
        ],
    ],
    'product' => $product,      // \FluentCart\App\Models\Product — The updated Product instance
];
```

#### Usage Example:
```php
// Hook when a product is updated via the admin API
add_action('fluent_cart/product_updated', function($data) {
    // Extract updated Product model instance
    $product = $data['product'];

    // Sync product data to an external inventory system
    do_action('my_plugin/sync_inventory', [
        'product_id' => $product->ID,
        'title'      => $product->post_title,
    ]);

    // Clear cached product data from object cache
    wp_cache_delete('fct_product_' . $product->ID, 'fluent_cart');
}, 10, 1);
```

---

## Single Product Page Rendering
Hooks that fire during the server-side rendering of a single product page. All rendering hooks use output buffering -- your callback should `echo` HTML directly rather than return a value.

### `render_product_header`
`fluent_cart/product/render_product_header` — Before the single product page content

* **When it runs:** This action fires at the very top of a single product page, before the main post content is rendered. Output is captured via `ob_start()` / `ob_get_clean()` and prepended to the product content.
* **Source:** `app/Modules/Templating/TemplateActions.php`

#### Parameters:
* `$postId` *(int)*: The product's WordPress post ID

#### Usage Example:
```php
// Hook before single product page content is rendered
add_action('fluent_cart/product/render_product_header', function($postId) {
    // Render custom promotional banner HTML above product content
    echo '<div class="my-promo-banner">Free shipping on this item!</div>';
}, 10, 1);
```

---

### `after_product_content`
`fluent_cart/product/after_product_content` — After the single product page content

* **When it runs:** This action fires immediately after the main product content on a single product page. Output is captured via `ob_start()` / `ob_get_clean()` and appended to the product content.
* **Source:** `app/Modules/Templating/TemplateActions.php`

#### Parameters:
* `$postId` *(int)*: The product's WordPress post ID

#### Usage Example:
```php
// Hook after single product page content is rendered
add_action('fluent_cart/product/after_product_content', function($postId) {
    // Render trust badges section below product content
    echo '<div class="trust-badges">';
    echo '<span>30-day money back guarantee</span>';
    echo '</div>';
}, 10, 1);
```

---

### `product_archive`
`fluent_cart/template/product_archive` — Render the product archive/taxonomy page

* **When it runs:** This action fires when a product taxonomy archive page (category, tag, etc.) is being rendered. It is triggered inside `renderMainContent()` when the current page is a taxonomy page for `fluent-products`.
* **Parameters:** None.
* **Source:** `app/Modules/Templating/TemplateActions.php`

#### Usage Example:
```php
// Hook to render custom product archive or taxonomy page
add_action('fluent_cart/template/product_archive', function() {
    // Render custom product archive wrapper and layout
    echo '<div class="my-custom-archive">';
    echo '</div>';
}, 10, 0);
```

---

### `before_price_block`
`fluent_cart/product/single/before_price_block` — Before the price block on a single product page

* **When it runs:** This action fires immediately before the price wrapper `<div>` is rendered on a single product page. It fires in two contexts: once for simple products showing a single price, and once for multi-variant products showing the selected variant's price.
* **Source:** `app/Services/Renderer/ProductRenderer.php`

#### Parameters:
`$data` *(array)*: Price block context
```php
$data = [
    'product'       => $product,      // \FluentCart\App\Models\Product — The current product
    'current_price' => 5000,          // int — Price in cents
    'scope'         => 'price_range', // string — 'price_range' for simple products, 'product_variant_price' for variant pricing
];
```

#### Usage Example:
```php
// Hook before price block wrapper on single product page
add_action('fluent_cart/product/single/before_price_block', function($data) {
    // Render price label if scope is price_range
    if ($data['scope'] === 'price_range') {
        echo '<div class="price-label">Our Price:</div>';
    }
}, 10, 1);
```

---

### `after_price` (single & card)
`fluent_cart/product/after_price` — Inline after the price is rendered

* **When it runs:** This action fires inline immediately after a price value is echoed, while still inside the price `<span>` or `<div>`. It fires in multiple contexts: simple product prices, price ranges, individual variant prices, and product cards. Use the `scope` key to distinguish between contexts.
* **Source:** `app/Services/Renderer/ProductRenderer.php`, `app/Services/Renderer/ProductCardRender.php`

#### Parameters:
`$data` *(array)*: Price context
```php
$data = [
    'product'       => $product,      // \FluentCart\App\Models\Product — The current product
    'current_price' => 5000,          // int — Price in cents
    'scope'         => 'price_range', // string — 'price_range', 'product_variant_price', or 'product_card'
];
```

#### Usage Example:
```php
// Hook inline after price value is rendered
add_action('fluent_cart/product/after_price', function($data) {
    // Display per-unit label next to variant price
    if ($data['scope'] === 'product_variant_price') {
        echo '<span class="per-unit"> / unit</span>';
    }

    // Display sale badge on archive product cards
    if ($data['scope'] === 'product_card') {
        echo '<span class="sale-badge">Sale</span>';
    }
}, 10, 1);
```

---

### `after_price_block`
`fluent_cart/product/single/after_price_block` — After the price block wrapper closes on a single product page

* **When it runs:** This action fires immediately after the closing `</div>` of the price block on a single product page. Like `before_price_block`, it fires in two contexts: simple product pricing and variant pricing.
* **Source:** `app/Services/Renderer/ProductRenderer.php`

#### Parameters:
`$data` *(array)*: Price block context (same structure as `before_price_block`)

#### Usage Example:
```php
// Hook after price block wrapper closes on single product page
add_action('fluent_cart/product/single/after_price_block', function($data) {
    // Calculate and display monthly installment pricing note
    $monthly = \FluentCart\App\Helpers\Helper::toDecimal(intval($data['current_price'] / 3));
    echo '<p class="installment-info">Or 3 payments of ' . esc_html($monthly) . '</p>';
}, 10, 1);
```

---

### `before_price_range_block`
`fluent_cart/product/single/before_price_range_block` — Before the price range block for multi-variant products

* **When it runs:** This action fires before the min-max price range `<div>` is rendered on multi-variant products (products with more than one variant that show a "from X - Y" price range). It does not fire for simple products.
* **Source:** `app/Services/Renderer/ProductRenderer.php`

#### Parameters:
`$data` *(array)*: Price range context
```php
$data = [
    'product'       => $product,      // \FluentCart\App\Models\Product — The current product
    'current_price' => 2000,          // int — Minimum price in cents
    'scope'         => 'price_range',
];
```

#### Usage Example:
```php
// Hook before price range block on multi-variant products
add_action('fluent_cart/product/single/before_price_range_block', function($data) {
    // Render intro note above price range
    echo '<div class="pricing-note">Choose a plan below:</div>';
}, 10, 1);
```

---

### `after_price_range_block`
`fluent_cart/product/single/after_price_range_block` — After the price range block for multi-variant products

* **When it runs:** This action fires after the closing `</div>` of the min-max price range block on multi-variant products. It does not fire for simple products.
* **Source:** `app/Services/Renderer/ProductRenderer.php`

#### Parameters:
`$data` *(array)*: Price range context (same structure as `before_price_range_block`)

#### Usage Example:
```php
// Hook after price range block on multi-variant products
add_action('fluent_cart/product/single/after_price_range_block', function($data) {
    // Render bulk discount notice below price range
    echo '<p class="bulk-discount">Bulk discounts available for 10+ licenses.</p>';
}, 10, 1);
```

---

### `before_variant_item`
`fluent_cart/product/single/before_variant_item` — Before each variant item in the variant list

* **When it runs:** This action fires before each individual `ProductVariation` option is rendered in the variant selection list. It fires once per variant, inside the `foreach` loop that iterates over sorted variants. It fires in both the standard variant list and the tabbed (subscription/onetime) variant layout.
* **Source:** `app/Services/Renderer/ProductRenderer.php`

#### Parameters:
`$data` *(array)*: Variant item context
```php
$data = [
    'product' => $product,               // \FluentCart\App\Models\Product — The current product
    'variant' => $variant,               // \FluentCart\App\Models\ProductVariation — The current variant being rendered
    'scope'   => 'product_variant_item',
];
```

#### Usage Example:
```php
// Hook before each variant option in variant selection list
add_action('fluent_cart/product/single/before_variant_item', function($data) {
    // Extract variant model instance from event data
    $variant = $data['variant'];

    // Render a "Most Popular" badge for target variant ID
    if ($variant->id === 42) {
        echo '<div class="popular-badge">Most Popular</div>';
    }
}, 10, 1);
```

---

### `after_variant_item`
`fluent_cart/product/single/after_variant_item` — After each variant item in the variant list

* **When it runs:** This action fires after each individual variant option is rendered in the variant selection list. It fires once per variant, immediately after `renderVariationItem()` completes. It fires in both the standard variant list and the tabbed variant layout.
* **Source:** `app/Services/Renderer/ProductRenderer.php`

#### Parameters:
`$data` *(array)*: Variant item context (same structure as `before_variant_item`)

#### Usage Example:
```php
// Hook after each variant option in variant selection list
add_action('fluent_cart/product/single/after_variant_item', function($data) {
    // Extract variant model instance from event data
    $variant = $data['variant'];

    // Display low stock warning if quantity is low
    if ($variant->stock_quantity > 0 && $variant->stock_quantity < 10) {
        echo '<span class="low-stock">Only ' . esc_html($variant->stock_quantity) . ' left!</span>';
    }
}, 10, 1);
```

---

### `before_quantity_block`
`fluent_cart/product/single/before_quantity_block` — Before the quantity selector on a single product page

* **When it runs:** This action fires immediately before the quantity input container is rendered on a single product page. It only fires if the product allows quantity selection (not hidden by sold-individually or other conditions).
* **Source:** `app/Services/Renderer/ProductRenderer.php`

#### Parameters:
`$data` *(array)*: Quantity block context
```php
$data = [
    'product' => $product,                   // \FluentCart\App\Models\Product — The current product
    'scope'   => 'product_quantity_block',
];
```

#### Usage Example:
```php
// Hook before quantity selector container on single product page
add_action('fluent_cart/product/single/before_quantity_block', function($data) {
    // Render quantity selection guidance note
    echo '<p class="quantity-hint">Select your desired quantity:</p>';
}, 10, 1);
```

---

### `after_quantity_block`
`fluent_cart/product/single/after_quantity_block` — After the quantity selector on a single product page

* **When it runs:** This action fires immediately after the quantity input container is rendered on a single product page, after the closing `</div>` of the quantity wrapper.
* **Source:** `app/Services/Renderer/ProductRenderer.php`

#### Parameters:
`$data` *(array)*: Quantity block context (same structure as `before_quantity_block`)

#### Usage Example:
```php
// Hook after quantity selector container on single product page
add_action('fluent_cart/product/single/after_quantity_block', function($data) {
    // Display bulk pricing table after quantity input wrapper
    echo '<div class="bulk-pricing">';
    echo '<small>Buy 5+ and save 10% &bull; Buy 10+ and save 20%</small>';
    echo '</div>';
}, 10, 1);
```

---

## Product Card Rendering (Archive / Group Pages)
Hooks that fire during server-side rendering of product cards on archive pages, product group blocks, and shop listings. All rendering hooks use output buffering -- your callback should `echo` HTML directly.

### `group/before_image_block`
`fluent_cart/product/group/before_image_block` — Before the product card image

* **When it runs:** This action fires before the product card image link and `<img>` tag are rendered inside a product card on archive or group pages.
* **Source:** `app/Services/Renderer/ProductCardRender.php`

#### Parameters:
`$data` *(array)*: Product card context
```php
$data = [
    'product' => $product,        // \FluentCart\App\Models\Product — The current product
    'scope'   => 'product_card',
];
```

#### Usage Example:
```php
// Hook before product card image link on archive/group pages
add_action('fluent_cart/product/group/before_image_block', function($data) {
    // Extract product model instance
    $product = $data['product'];
    $created = strtotime($product->post_date);

    // Render "New" ribbon badge if created within last 30 days
    if ($created > strtotime('-30 days')) {
        echo '<span class="new-ribbon">New</span>';
    }
}, 10, 1);
```

---

### `group/after_image_block`
`fluent_cart/product/group/after_image_block` — After the product card image

* **When it runs:** This action fires immediately after the product card image link closes, before the rest of the card content (title, price, button) is rendered.
* **Source:** `app/Services/Renderer/ProductCardRender.php`

#### Parameters:
`$data` *(array)*: Product card context (same structure as `group/before_image_block`)

#### Usage Example:
```php
// Hook after product card image link on archive/group pages
add_action('fluent_cart/product/group/after_image_block', function($data) {
    // Render quick-view button overlay after image
    echo '<button class="quick-view-btn" data-product="' . esc_attr($data['product']->ID) . '">Quick View</button>';
}, 10, 1);
```

---

### `group/before_price_block`
`fluent_cart/product/group/before_price_block` — Before the price section in product cards

* **When it runs:** This action fires before the price wrapper `<div class="fct-product-card-prices">` is rendered inside a product card on archive or group pages.
* **Source:** `app/Services/Renderer/ProductCardRender.php`

#### Parameters:
`$data` *(array)*: Product card price context
```php
$data = [
    'product'       => $product,       // \FluentCart\App\Models\Product — The current product
    'current_price' => 2000,           // int — Minimum price in cents
    'scope'         => 'product_card',
];
```

#### Usage Example:
```php
// Hook before price section in product card
add_action('fluent_cart/product/group/before_price_block', function($data) {
    // Render price prefix label on product card
    echo '<span class="price-prefix">Starting at</span>';
}, 10, 1);
```

---

### `group/after_price_block`
`fluent_cart/product/group/after_price_block` — After the price section in product cards

* **When it runs:** This action fires immediately after the closing `</div>` of the product card price wrapper, after prices and the inline `fluent_cart/product/after_price` hook have been rendered.
* **Source:** `app/Services/Renderer/ProductCardRender.php`

#### Parameters:
`$data` *(array)*: Product card price context (same structure as `group/before_price_block`)

#### Usage Example:
```php
// Hook after price section in product card
add_action('fluent_cart/product/group/after_price_block', function($data) {
    // Display custom feature list meta below price on product card
    $features = get_post_meta($data['product']->ID, '_card_features', true);
    if ($features) {
        echo '<ul class="card-features">';
        foreach ((array) $features as $feature) {
            echo '<li>' . esc_html($feature) . '</li>';
        }
        echo '</ul>';
    }
}, 10, 1);
```

---

## Coupons
Hooks that fire during Coupon create and update operations in the admin.

### `coupon_created`
`fluent_cart/coupon_created` — Fired after a new coupon is created via the admin

* **When it runs:** This action fires after a Coupon has been successfully created through the admin REST API. It runs after `CouponResource::create()` has persisted the coupon and after the activity log entry has been recorded.
* **Source:** `app/Http/Controllers/CouponsController.php`

#### Parameters:
`$data` *(array)*: Coupon creation data
```php
$data = [
    'data'   => [                // array — Sanitized request payload
        'title'      => 'SAVE20',
        'type'       => 'percentage',          // 'percentage' or 'fixed'
        'amount'     => 2000,                  // int — Discount amount in cents (or percentage value)
        'start_date' => '2026-01-01 00:00:00', // string|null — GMT start date
        'end_date'   => '2026-12-31 23:59:59', // string|null — GMT end date
        'conditions' => [
            'is_recurring' => 'no',
            // ... other condition fields
        ],
    ],
    'coupon' => $coupon,          // \FluentCart\App\Models\Coupon — The newly created Coupon instance
];
```

#### Usage Example:
```php
// Hook after a new coupon is created via admin REST API
add_action('fluent_cart/coupon_created', function($data) {
    // Extract newly created Coupon model instance
    $coupon = $data['coupon'];

    // Notify marketing team via email about new coupon
    wp_mail(
        'marketing@example.com',
        'New Coupon Created: ' . $coupon->title,
        'A new coupon has been created with code: ' . $coupon->title
    );
}, 10, 1);
```

---

### `coupon_updated`
`fluent_cart/coupon_updated` — Fired after a coupon is updated via the admin

* **When it runs:** This action fires after a Coupon has been successfully updated through the admin REST API. It runs after `CouponResource::update()` has persisted the changes, but before the activity log entry is recorded.
* **Source:** `app/Http/Controllers/CouponsController.php`

#### Parameters:
`$data` *(array)*: Coupon update data
```php
$data = [
    'data'   => [                // array — Sanitized request payload
        'title'      => 'SAVE20',
        'type'       => 'percentage',
        'amount'     => 2500,
        'start_date' => '2026-01-01 00:00:00',
        'end_date'   => '2026-12-31 23:59:59',
        'conditions' => [
            'is_recurring' => 'no',
            // ... other condition fields
        ],
    ],
    'coupon' => $coupon,          // \FluentCart\App\Models\Coupon — The updated Coupon instance
];
```

#### Usage Example:
```php
// Hook after a coupon is updated via admin REST API
add_action('fluent_cart/coupon_updated', function($data) {
    // Extract updated Coupon model instance
    $coupon = $data['coupon'];

    // Clear coupon validation cache when a coupon is modified
    wp_cache_delete('fct_coupon_' . $coupon->id, 'fluent_cart');

    // Sync updated coupon to external promotion platform
    do_action('my_plugin/sync_coupon', $coupon);
}, 10, 1);
```

---

# Action Hooks: Subscriptions

Action hooks for Subscription lifecycle management, status transitions, and scheduled reminder notifications. These hooks let you react to subscription state changes, send custom notifications, and integrate with external systems. Most hooks pass the related Order and Customer models as well.

---

## Subscription Status Changes

### `subscription_status_changed`
`fluent_cart/payments/subscription_status_changed` — Fires on any subscription status transition

* **When it runs:** This action fires whenever a Subscription's status changes from one value to another (e.g., `pending` to `active`, `active` to `cancelled`, etc.). It does not fire when other subscription data changes without a status transition. This is the generic handler -- for status-specific hooks, see status-specific hooks below.
* **Source:** `app/Modules/Subscriptions/Services/SubscriptionService.php`

#### Parameters:
`$data` *(array)*: Subscription status change data
```php
$data = [
    'subscription' => $subscriptionModel,        // \FluentCart\App\Models\Subscription
    'order'        => $subscriptionModel->order,   // \FluentCart\App\Models\Order
    'customer'     => $subscriptionModel->customer,// \FluentCart\App\Models\Customer
    'old_status'   => 'pending',                  // string — previous status
    'new_status'   => 'active',                   // string — current status after update
];
```

#### Usage Example:
```php
// Hook into any subscription status change
add_action('fluent_cart/payments/subscription_status_changed', function ($data) {
    // Extract subscription model and status values
    $subscription = $data['subscription'];
    $oldStatus    = $data['old_status'];
    $newStatus    = $data['new_status'];

    // Log every status transition into FluentCart logs
    fluent_cart_add_log(
        'Subscription Status Changed',
        sprintf('Subscription #%d changed from %s to %s', $subscription->id, $oldStatus, $newStatus),
        'info'
    );
}, 10, 1);
```

---

### `subscription_active`
`fluent_cart/payments/subscription_active` — Fires when a subscription becomes active

* **When it runs:** This action fires when a subscription's status transitions to `active`. This may occur after initial payment, after reactivation, or when moving from trialing to active.
* **Source:** `app/Modules/Subscriptions/Services/SubscriptionService.php`

#### Parameters:
`$data` *(array)*: Subscription data
```php
$data = [
    'subscription' => $subscriptionModel,        // \FluentCart\App\Models\Subscription
    'order'        => $subscriptionModel->order,   // \FluentCart\App\Models\Order
    'customer'     => $subscriptionModel->customer,// \FluentCart\App\Models\Customer
    'old_status'   => 'pending',                  // string — previous status
    'new_status'   => 'active',                   // string — always 'active'
];
```

#### Usage Example:
```php
// Hook when a subscription becomes active
add_action('fluent_cart/payments/subscription_active', function ($data) {
    // Extract customer model from event data
    $customer = $data['customer'];

    // Grant premium access when subscription activates
    update_user_meta($customer->user_id, 'premium_member', true);
}, 10, 1);
```

---

### `subscription_canceled`
`fluent_cart/payments/subscription_canceled` — Fires when a subscription is cancelled

* **When it runs:** This action fires when a subscription's status transitions to `canceled`. The `canceled_at` timestamp is automatically set if not already provided.
* **Source:** `app/Modules/Subscriptions/Services/SubscriptionService.php`

#### Parameters:
`$data` *(array)*: Subscription data
```php
$data = [
    'subscription' => $subscriptionModel,        // \FluentCart\App\Models\Subscription
    'order'        => $subscriptionModel->order,   // \FluentCart\App\Models\Order
    'customer'     => $subscriptionModel->customer,// \FluentCart\App\Models\Customer
    'old_status'   => 'active',                   // string — previous status
    'new_status'   => 'canceled',                 // string — always 'canceled'
];
```

#### Usage Example:
```php
// Hook when a subscription is cancelled
add_action('fluent_cart/payments/subscription_canceled', function ($data) {
    // Extract subscription and customer models from event data
    $subscription = $data['subscription'];
    $customer     = $data['customer'];

    // Revoke premium access on cancellation
    update_user_meta($customer->user_id, 'premium_member', false);

    // Notify store administrator via email
    wp_mail(
        get_option('admin_email'),
        'Subscription Cancelled',
        sprintf('Subscription #%d for %s has been cancelled.', $subscription->id, $customer->email)
    );
}, 10, 1);
```

---

### `subscription_paused`
`fluent_cart/payments/subscription_paused` — Fires when a subscription is paused

* **When it runs:** This action fires when a subscription's status transitions to `paused`. The subscription remains in the system but billing is temporarily halted.
* **Source:** `app/Modules/Subscriptions/Services/SubscriptionService.php`

#### Parameters:
`$data` *(array)*: Subscription data
```php
$data = [
    'subscription' => $subscriptionModel,        // \FluentCart\App\Models\Subscription
    'order'        => $subscriptionModel->order,   // \FluentCart\App\Models\Order
    'customer'     => $subscriptionModel->customer,// \FluentCart\App\Models\Customer
    'old_status'   => 'active',                   // string — previous status
    'new_status'   => 'paused',                   // string — always 'paused'
];
```

#### Usage Example:
```php
// Hook when a subscription is paused
add_action('fluent_cart/payments/subscription_paused', function ($data) {
    // Extract subscription model from event data
    $subscription = $data['subscription'];

    // Temporarily suspend feature access for paused customer
    update_user_meta($data['customer']->user_id, 'subscription_paused', true);
}, 10, 1);
```

---

### `subscription_expired`
`fluent_cart/payments/subscription_expired` — Fires when a subscription expires

* **When it runs:** This action fires when a subscription's status transitions to `expired`. After this hook fires, the system also stores a `validity_expired_at` meta value and dispatches the `SubscriptionValidityExpired` event.
* **Source:** `app/Modules/Subscriptions/Services/SubscriptionService.php`

#### Parameters:
`$data` *(array)*: Subscription data
```php
$data = [
    'subscription' => $subscriptionModel,        // \FluentCart\App\Models\Subscription
    'order'        => $subscriptionModel->order,   // \FluentCart\App\Models\Order
    'customer'     => $subscriptionModel->customer,// \FluentCart\App\Models\Customer
    'old_status'   => 'active',                   // string — previous status
    'new_status'   => 'expired',                  // string — always 'expired'
];
```

#### Usage Example:
```php
// Hook when a subscription expires
add_action('fluent_cart/payments/subscription_expired', function ($data) {
    // Extract customer model from event data
    $customer = $data['customer'];

    // Remove premium access from customer user account
    update_user_meta($customer->user_id, 'premium_member', false);

    // Send expiration notification email to the customer
    wp_mail(
        $customer->email,
        'Your Subscription Has Expired',
        'Your subscription has expired. Please renew to continue using premium features.'
    );
}, 10, 1);
```

---

### `subscription_failing`
`fluent_cart/payments/subscription_failing` — Fires when a subscription payment is failing

* **When it runs:** This action fires when a subscription's status transitions to `failing`, indicating that a renewal payment attempt has failed. The subscription is still technically active but requires payment attention.
* **Source:** `app/Modules/Subscriptions/Services/SubscriptionService.php`

#### Parameters:
`$data` *(array)*: Subscription data
```php
$data = [
    'subscription' => $subscriptionModel,        // \FluentCart\App\Models\Subscription
    'order'        => $subscriptionModel->order,   // \FluentCart\App\Models\Order
    'customer'     => $subscriptionModel->customer,// \FluentCart\App\Models\Customer
    'old_status'   => 'active',                   // string — previous status
    'new_status'   => 'failing',                  // string — always 'failing'
];
```

#### Usage Example:
```php
// Hook when a subscription renewal payment is failing
add_action('fluent_cart/payments/subscription_failing', function ($data) {
    // Extract subscription and customer models from event data
    $subscription = $data['subscription'];
    $customer     = $data['customer'];

    // Alert the customer about the payment failure via email
    wp_mail(
        $customer->email,
        'Payment Failed for Your Subscription',
        sprintf('We were unable to process payment for subscription #%d. Please update your payment method.', $subscription->id)
    );
}, 10, 1);
```

---

### `subscription_expiring`
`fluent_cart/payments/subscription_expiring` — Fires when a subscription is marked as expiring soon

* **When it runs:** This action fires when a subscription's status transitions to `expiring`, indicating that the subscription is approaching its end-of-term and will not be renewed.
* **Source:** `app/Modules/Subscriptions/Services/SubscriptionService.php`

#### Parameters:
`$data` *(array)*: Subscription data
```php
$data = [
    'subscription' => $subscriptionModel,        // \FluentCart\App\Models\Subscription
    'order'        => $subscriptionModel->order,   // \FluentCart\App\Models\Order
    'customer'     => $subscriptionModel->customer,// \FluentCart\App\Models\Customer
    'old_status'   => 'active',                   // string — previous status
    'new_status'   => 'expiring',                 // string — always 'expiring'
];
```

#### Usage Example:
```php
// Hook when a subscription is marked as expiring soon
add_action('fluent_cart/payments/subscription_expiring', function ($data) {
    // Extract subscription and customer models from event data
    $subscription = $data['subscription'];
    $customer     = $data['customer'];

    // Send a win-back offer email before subscription fully expires
    wp_mail(
        $customer->email,
        'Your Subscription is About to Expire',
        'Renew now and get 10% off your next billing cycle!'
    );
}, 10, 1);
```

---

### `subscription_completed`
`fluent_cart/payments/subscription_completed` — Fires when a subscription completes all billing cycles

* **When it runs:** This action fires when a subscription's status transitions to `completed`. This occurs when the subscription has reached its end-of-term (EOT) -- i.e., the `bill_count` has met or exceeded `bill_times`. The `next_billing_date` is set to `NULL` and `canceled_at` is cleared.
* **Source:** `app/Modules/Subscriptions/Services/SubscriptionService.php`

#### Parameters:
`$data` *(array)*: Subscription data
```php
$data = [
    'subscription' => $subscriptionModel,        // \FluentCart\App\Models\Subscription
    'order'        => $subscriptionModel->order,   // \FluentCart\App\Models\Order
    'customer'     => $subscriptionModel->customer,// \FluentCart\App\Models\Customer
    'old_status'   => 'active',                   // string — previous status
    'new_status'   => 'completed',                // string — always 'completed'
];
```

#### Usage Example:
```php
// Hook when a subscription completes all required billing cycles
add_action('fluent_cart/payments/subscription_completed', function ($data) {
    // Extract subscription and customer models from event data
    $subscription = $data['subscription'];
    $customer     = $data['customer'];

    // Thank the customer for completing their full subscription term
    wp_mail(
        $customer->email,
        'Subscription Complete',
        sprintf('Your subscription #%d has completed all %d billing cycles. Thank you!', $subscription->id, $subscription->bill_times)
    );
}, 10, 1);
```

---

### `subscription_trialing`
`fluent_cart/payments/subscription_trialing` — Fires when a subscription enters trial status

* **When it runs:** This action fires when a subscription's status transitions to `trialing`. The subscription is in a free trial period and will transition to `active` (with billing) when the trial ends.
* **Source:** `app/Modules/Subscriptions/Services/SubscriptionService.php`

#### Parameters:
`$data` *(array)*: Subscription data
```php
$data = [
    'subscription' => $subscriptionModel,        // \FluentCart\App\Models\Subscription
    'order'        => $subscriptionModel->order,   // \FluentCart\App\Models\Order
    'customer'     => $subscriptionModel->customer,// \FluentCart\App\Models\Customer
    'old_status'   => 'pending',                  // string — previous status
    'new_status'   => 'trialing',                 // string — always 'trialing'
];
```

#### Usage Example:
```php
// Hook when a subscription enters trial status
add_action('fluent_cart/payments/subscription_trialing', function ($data) {
    // Extract subscription and customer models from event data
    $subscription = $data['subscription'];
    $customer     = $data['customer'];

    // Grant trial access to customer account
    update_user_meta($customer->user_id, 'trial_active', true);

    // Send trial welcome email to customer
    wp_mail(
        $customer->email,
        'Your Free Trial Has Started',
        sprintf('Enjoy your trial! Your first payment will be on %s.', $subscription->next_billing_date)
    );
}, 10, 1);
```

---

## Subscription Data Updates

### `subscription_data_updated`
`fluent_cart/subscription/data_updated` — Fires when subscription data changes without a status transition

* **When it runs:** This action fires when Subscription attributes are modified but the status remains the same. Examples include billing amount changes, next payment date adjustments, or metadata updates. It only fires when there are actual dirty (changed) fields on the model.
* **Source:** `app/Modules/Subscriptions/Services/SubscriptionService.php`

#### Parameters:
`$data` *(array)*: Subscription update data
```php
$data = [
    'subscription' => $subscriptionModel, // \FluentCart\App\Models\Subscription (already saved)
    'updated_data' => [
        // Only the fields that actually changed (dirty attributes), e.g.:
        'recurring_total'   => 2999,                  // int — new amount in cents
        'next_billing_date' => '2025-03-15 00:00:00', // string — updated billing date
    ],
];
```

#### Usage Example:
```php
// Hook when subscription data changes without a status transition
add_action('fluent_cart/subscription/data_updated', function ($data) {
    // Extract subscription model and modified attributes map
    $subscription = $data['subscription'];
    $updatedData  = $data['updated_data'];

    // Log billing amount changes if total was modified
    if (isset($updatedData['recurring_total'])) {
        fluent_cart_add_log(
            'Subscription Amount Changed',
            sprintf(
                'Subscription #%d recurring total changed to %s',
                $subscription->id,
                number_format($updatedData['recurring_total'] / 100, 2)
            ),
            'info'
        );
    }

    // Sync next billing date with external calendar if modified
    if (isset($updatedData['next_billing_date'])) {
        do_action('my_plugin/sync_billing_date', $subscription->id, $updatedData['next_billing_date']);
    }
}, 10, 1);
```

---

## Reminders & Notifications

### `subscription_renewal_reminder`
`fluent_cart/subscription_renewal_reminder` — Fires when a subscription renewal reminder is due

* **When it runs:** This action fires on a scheduled basis (via Action Scheduler) when a subscription's next billing date is approaching. The reminder system supports multiple billing cycles (`yearly`, `monthly`, `quarterly`, `half_yearly`) and configurable "days before" thresholds. Only fires for subscriptions with `active` or `trialing` status. The stage name indicates how many days before renewal (e.g., `before_30`, `before_7`).
* **Source:** `app/Services/Reminders/SubscriptionReminderService.php`

#### Parameters:
`$data` *(array)*: Renewal reminder data
```php
$data = [
    'subscription' => $subscription,           // \FluentCart\App\Models\Subscription
    'order'        => $subscription->order,    // \FluentCart\App\Models\Order
    'customer'     => $subscription->customer, // \FluentCart\App\Models\Customer
    'reminder'     => [
        'stage'         => 'before_30',            // string — e.g., 'before_30', 'before_7'
        'billing_cycle' => 'yearly',               // string — 'yearly', 'monthly', 'quarterly', 'half_yearly'
        'billing_date'  => '2025-03-15 00:00:00', // string — GMT formatted next billing date
    ],
];
```

#### Usage Example:
```php
// Hook when a scheduled subscription renewal reminder is due
add_action('fluent_cart/subscription_renewal_reminder', function ($data) {
    // Extract subscription, customer, and reminder metadata
    $subscription = $data['subscription'];
    $customer     = $data['customer'];
    $reminder     = $data['reminder'];

    // Send a custom renewal reminder email to the subscriber
    wp_mail(
        $customer->email,
        'Subscription Renewal Coming Up',
        sprintf(
            'Your %s subscription #%d will renew on %s.',
            $reminder['billing_cycle'],
            $subscription->id,
            date('F j, Y', strtotime($reminder['billing_date']))
        )
    );
}, 10, 1);
```

---

### `subscription_trial_end_reminder`
`fluent_cart/subscription_trial_end_reminder` — Fires when a trial ending reminder is due

* **When it runs:** This action fires on a scheduled basis when a trialing subscription's trial period is about to end. Only fires for subscriptions with `trialing` status (excluding simulated trials). The stage name indicates how many days before the trial ends (e.g., `trial_end_3`, `trial_end_1`). Configurable via the `trial_end_reminder_days` store setting.
* **Source:** `app/Services/Reminders/SubscriptionReminderService.php`

#### Parameters:
`$data` *(array)*: Trial end reminder data
```php
$data = [
    'subscription' => $subscription,           // \FluentCart\App\Models\Subscription
    'order'        => $subscription->order,    // \FluentCart\App\Models\Order
    'customer'     => $subscription->customer, // \FluentCart\App\Models\Customer
    'reminder'     => [
        'stage'          => 'trial_end_3',         // string — e.g., 'trial_end_3', 'trial_end_1'
        'trial_end_date' => '2025-02-01 00:00:00',// string — GMT formatted trial end date
    ],
];
```

#### Usage Example:
```php
// Hook when a trial ending reminder is due
add_action('fluent_cart/subscription_trial_end_reminder', function ($data) {
    // Extract subscription, customer, and reminder metadata
    $subscription = $data['subscription'];
    $customer     = $data['customer'];
    $reminder     = $data['reminder'];

    // Notify customer that their trial is ending soon via email
    wp_mail(
        $customer->email,
        'Your Free Trial is Ending Soon',
        sprintf(
            'Your trial for subscription #%d ends on %s. After that, you will be billed %s.',
            $subscription->id,
            date('F j, Y', strtotime($reminder['trial_end_date'])),
            number_format($subscription->recurring_total / 100, 2)
        )
    );
}, 10, 1);
```

---

### `invoice_reminder_overdue`
`fluent_cart/invoice_reminder_overdue` — Fires when an overdue invoice reminder is triggered

* **When it runs:** This action fires on a scheduled basis when an Order with an outstanding balance has passed its due date by a configured number of days. The stage name indicates how many days overdue (e.g., `overdue_1`, `overdue_3`, `overdue_7`). Only fires for orders with `pending`, `partially_paid`, `failed`, or `authorized` payment statuses. The overdue days are configurable via the `invoice_reminder_overdue_days` store setting (defaults to `1,3,7`).
* **Source:** `app/Services/Reminders/InvoiceReminderService.php`

#### Parameters:
`$data` *(array)*: Invoice overdue reminder data
```php
$data = [
    'order'    => $order,           // \FluentCart\App\Models\Order
    'customer' => $order->customer, // \FluentCart\App\Models\Customer
    'reminder' => [
        'stage'        => 'overdue_3',                             // string — e.g., 'overdue_1', 'overdue_3', 'overdue_7'
        'order_id'     => 123,                                     // int — order ID
        'order_ref'    => 'INV-00123',                             // string — invoice number or '#123' fallback
        'due_at'       => '2025-01-15 00:00:00',                   // string — GMT formatted due date
        'due_amount'   => 5000,                                    // int — outstanding amount in cents
        'payment_link' => 'https://example.com/checkout/pay/uuid', // string — customer payment URL
    ],
];
```

#### Usage Example:
```php
// Hook when an overdue invoice reminder is triggered
add_action('fluent_cart/invoice_reminder_overdue', function ($data) {
    // Extract order, customer, and overdue reminder details
    $order    = $data['order'];
    $customer = $data['customer'];
    $reminder = $data['reminder'];

    // Send a payment reminder with a direct payment link
    wp_mail(
        $customer->email,
        sprintf('Payment Overdue for %s', $reminder['order_ref']),
        sprintf(
            "Your payment of %s for order %s is overdue.\n\nPay now: %s",
            number_format($reminder['due_amount'] / 100, 2),
            $reminder['order_ref'],
            $reminder['payment_link']
        )
    );
}, 10, 1);
```

---

### `invoice_reminder_due`
`fluent_cart/invoice_reminder_due` — Fires when an invoice due-date reminder is triggered

* **When it runs:** This action fires on a scheduled basis when an order with an outstanding balance has reached its due date (stage `before_0`). This is the on-due-date notification, as opposed to the overdue reminders that fire after the due date has passed. Shares the same parameter structure as the overdue reminder.
* **Note:** This hook is currently defined in the codebase but the queueing logic for the `before_0` stage is commented out pending the full invoice feature deployment. It is documented here for forward compatibility.
* **Source:** `app/Services/Reminders/InvoiceReminderService.php`

#### Parameters:
`$data` *(array)*: Invoice due reminder data
```php
$data = [
    'order'    => $order,           // \FluentCart\App\Models\Order
    'customer' => $order->customer, // \FluentCart\App\Models\Customer
    'reminder' => [
        'stage'        => 'before_0',                              // string — always 'before_0' for due-date reminders
        'order_id'     => 123,                                     // int — order ID
        'order_ref'    => 'INV-00123',                             // string — invoice number or '#123' fallback
        'due_at'       => '2025-01-15 00:00:00',                   // string — GMT formatted due date
        'due_amount'   => 5000,                                    // int — outstanding amount in cents
        'payment_link' => 'https://example.com/checkout/pay/uuid', // string — customer payment URL
    ],
];
```

#### Usage Example:
```php
// Hook when an invoice due-date reminder is triggered
add_action('fluent_cart/invoice_reminder_due', function ($data) {
    // Extract order, customer, and due reminder details
    $order    = $data['order'];
    $customer = $data['customer'];
    $reminder = $data['reminder'];

    // Notify customer that their invoice is due today via email
    wp_mail(
        $customer->email,
        sprintf('Payment Due Today for %s', $reminder['order_ref']),
        sprintf(
            "Your payment of %s for order %s is due today.\n\nPay now: %s",
            number_format($reminder['due_amount'] / 100, 2),
            $reminder['order_ref'],
            $reminder['payment_link']
        )
    );
}, 10, 1);
```

---

## Subscription Upgrades & Early Payments (Pro)

### `early_payment_completed` (Pro)
`fluent_cart/subscription/early_payment_completed` — Fires when an early installment payment is completed

* **When it runs:** This action fires when a customer makes an early installment payment on their subscription, paying for one or more future billing cycles ahead of schedule.
* **Source:** `fluent-cart-pro/app/Hooks/Handlers/EarlyInstallmentPaymentHandler.php` (line 279)

#### Parameters:
`$data` *(array)*: Early payment completion data
```php
$data = [
    'subscription'      => $subscription,     // \FluentCart\App\Models\Subscription
    'order'             => $order,             // \FluentCart\App\Models\Order
    'installment_count' => $installmentCount,  // int — number of installments paid early
];
```

#### Usage Example:
```php
// Hook when an early installment payment is completed (Pro extension)
add_action('fluent_cart/subscription/early_payment_completed', function ($data) {
    // Extract subscription, order, and installment count details
    $subscription     = $data['subscription'];
    $order            = $data['order'];
    $installmentCount = $data['installment_count'];

    // Log early installment payment event
    fluent_cart_add_log(
        'Early Payment Completed',
        sprintf('Subscription #%d received %d early installment(s) via order #%d', $subscription->id, $installmentCount, $order->id),
        'info'
    );
}, 10, 1);
```

---

### `order_upgraded` (Pro)
`fluent_cart/order/upgraded` — Fires when a plan upgrade is completed

* **When it runs:** This action fires when a customer completes a plan upgrade, transitioning from one product variant to another. The upgrade creates a new order and transaction record.
* **Source:** `fluent-cart-pro/app/Hooks/Handlers/UpgradeHandler.php` (line 242)

#### Parameters:
`$data` *(array)*: Upgrade completion data
```php
$data = [
    'order'           => $newOrder,         // \FluentCart\App\Models\Order — the new upgrade order
    'from_order'      => $upgradeFromOrder, // \FluentCart\App\Models\Order — the original order
    'cart'            => $cartModel,        // \FluentCart\App\Models\Cart — the cart used for the upgrade
    'from_variant_id' => $fromVariantId,    // int — ID of the original product variant
    'transaction'     => $transaction,      // \FluentCart\App\Models\OrderTransaction — the upgrade payment transaction
];
```

#### Usage Example:
```php
// Hook when a plan upgrade is completed (Pro extension)
add_action('fluent_cart/order/upgraded', function ($data) {
    // Extract upgraded order models and payment transaction
    $order          = $data['order'];
    $fromOrder      = $data['from_order'];
    $fromVariantId  = $data['from_variant_id'];
    $transaction    = $data['transaction'];

    // Log plan upgrade event
    fluent_cart_add_log(
        'Plan Upgraded',
        sprintf(
            'Order #%d upgraded from order #%d (variant %d). Transaction: %s',
            $order->id,
            $fromOrder->id,
            $fromVariantId,
            $transaction->charge_id
        ),
        'info'
    );
}, 10, 1);
```
