# Hooks

FluentCart provides a comprehensive hook system that allows you to extend and customize the plugin's functionality without modifying core files.

## Hook Types

### [Actions](/hooks/actions.md)

Actions allow you to execute custom code at specific points in the plugin's execution flow.

### [Filters](/hooks/filters.md)

Filters allow you to modify data before it's processed or displayed.

## Getting Started

To use hooks in your custom code, you can add them to your theme's `functions.php` file or in a custom plugin.

```
// Example of using an action hook
add_action('fluent_cart/cart_completed', function($data) {
    // Your custom code here
});

// Example of using a filter hook
add_filter('fluent_cart/checkout_address_fields', function($fields, $data) {
    // Add a custom address field
    $fields['company'] = [
        'label' => 'Company Name',
        'type' => 'text',
        'required' => false
    ];
    return $fields;
}, 10, 2);
```
